#ifdef __cplusplus
extern "C" {
#endif

#define FLT 0
#define DBL 1
#ifdef USEFLOATS
#define DATATYPE float
#define DATAFLAG FLT
#else
#define DATATYPE double
#define DATAFLAG DBL
#endif

#ifndef __COMPLEX__
typedef struct{
  DATATYPE  re;        /* Real part */
  DATATYPE  im;        /* Imaginary part */
} COMPLEX;
#define __COMPLEX__
#endif

#ifndef FIL_FFT_H

typedef struct {
  int N;                        /* length of *THIS* FFT */
  char direction; 
  int dims;
  char engine;
  void *fftcfg;
  void *dataptr;
#ifdef OOURA
  int    *fft_ip;
  DATATYPE *fft_w;
  short  init;
  DATATYPE **fft_p;
#endif
} fft_mngr_obj;


typedef struct {
  int id;
  int num;                      /* max number of fft mngr objs to be used */
  fft_mngr_obj **objs;          /* array of pointers to fft objects */
} fil_fft_mngr;

typedef struct {
  char direction;
  COMPLEX *data;
  int n;
  COMPLEX *buf;
  int center;
  fil_fft_mngr *mngr;
} fft1d_args;


/* FFT-related functions */
extern void     fftx( short ncoils, short Nf, int Nyz, short Nx, 
                      char dir, fil_fft_mngr *mngr, 
                      short center, COMPLEX *data );
extern void     ffty( short ncoils, short nf, short nz, short ny, short nx, 
                      char direction, fil_fft_mngr *mngr, 
                      short center, COMPLEX *data );
extern void     fftz( short ncoils, short nf, short nz, short ny, short nx,
                      char direction, fil_fft_mngr *mngr, 
                      short center, COMPLEX *data_in, COMPLEX *data_out );
extern int      fft1d( void *args );

extern void     fft_t(short ncoils, short nf, short nz, short ny, short nx,
                      char direction, fil_fft_mngr *mngr,  
                      short center, COMPLEX *data_in, COMPLEX *data_out);
extern void     ffty_and_crop(short ncoils, short nf, short nz, short ny1,
                              short ny2, short first_line, short nx, 
                              fil_fft_mngr *mngr,
                              COMPLEX *data_k, COMPLEX *data);

extern int fft_mngr_init ( fil_fft_mngr *mngr );
extern int fft_mngr_quit ( fil_fft_mngr *mngr );

extern int fil_fft ( fil_fft_mngr *mngr, int N, COMPLEX *data, char dir, int stride );
extern int fil_2dfft ( fil_fft_mngr *mngr, int M, int N, COMPLEX *data, char dir );

extern void fil_fft_shift( COMPLEX *data, int Nx, int Ny );

#define FIL_FFT_H

#endif

#ifdef __cplusplus
}
#endif


/*

Copyright 2009, National Center for Image Guided Therapy (NCIGT)

Written by W. Scott Hoge (shoge.harvard.edu) 

All rights reserved. Licensed according to the terms of a BSD-style 
licence covering the Fast Imaging Library 
(see http://www.ncigt.org/pages/Downloads "Imaging Toolbox")


*/
