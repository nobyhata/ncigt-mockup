#ifndef PHASE_ALIGN_H
#define PHASE_ALIGN_H 1

int align_image_phase( COMPLEX *P, /**< image associated with pos readout data */
                       COMPLEX *N, /**< image associated with neg readout data */
                       int nz,     /**< number of input image dimensions */
                       int *sz,    /**< array of sizes for each dimension.
                                      Note, P and N need to be identical in size */
                       float   **phzL, /**< */
                       COMPLEX **phzC, /**< */
		       int tmax, /**< maximum number of threads */
                       short int mode /**< if mode=0, the phase shift is split equally to both P and N.
                                       if mode=1, the phase shift is applied only to N */
                       );

int unwrap_phase( double *b,    /**< input vector of phase (angle) values */
                  float *mask,  /**< optional binary weighting vector  */
                  int N         /**< length of input vectors */
                  );

void fit_line_to_phase( COMPLEX *v,  /**< the input vector */
                        float *mask, /**< a windowing vector of the same length, 
                                        to provide a weighted LMS fit if needed.  */
                        int N,       /**< length of v */
                        float *ramp  /**< the estimate of the line slope. */
                        );


#ifndef PHASE_CORR_ARGS
typedef struct{
  COMPLEX *A;                   /* input 1 */
  COMPLEX *B;                   /* input 2 */
  int Nx;                       /* number of rows in A,B */
  int Ny;                       /* number of cols in A,B */
  COMPLEX *C;                   /* output */
  short int mode;               /* Mode of phase correction. 1: correct B only; otherwise, split correction 
                                   between A and B */
} Phase_Correlation_Args;
#define PHASE_CORR_ARGS
#endif

int calc_phase_correlation( Phase_Correlation_Args *arg );

int compute_mask( COMPLEX *C,
                  float *mask,
                  int Nx, 
                  int Ny,
                  float thresh,
                  COMPLEX *tbuf /**< optional working memory buffer.  Set to
                                   NULL if not preallocated. */
                  );

#endif

/*

Copyright 2009, National Center for Image Guided Therapy (NCIGT)

All rights reserved. Licensed according to the terms of a BSD-style 
licence covering the Fast Imaging Library 
(see http://www.ncigt.org/pages/Downloads "Imaging Toolbox")

*/
