/* a matrix-vector tool-kit for the parallel MRI library                   *
 *                                                                         */

#ifdef USE_PTHREADS
#include "pthread.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif

#define FLT 0
#define DBL 1
#ifdef USEFLOATS
#define DATATYPE float
#define DATAFLAG FLT
#else
#define DATATYPE double
#define DATAFLAG DBL
#endif

#ifndef __COMPLEX__
typedef struct{
   DATATYPE  re;                   /* Real part */
   DATATYPE  im;                   /* Imaginary part */
} COMPLEX;
#define __COMPLEX__
#endif


/*  inner_product - calculate the inner product of two complex vectors
 *                  res = sum( conj(a) .* b ) == (a' * b)
 */
#ifndef _COMPLEX_H
COMPLEX inner_product( COMPLEX *a, COMPLEX *b, int n );
#else
complex inner_product( COMPLEX *a, COMPLEX *b, int n );
#endif

void complex_conj( COMPLEX *a, int m );

void complex_vector_add( COMPLEX *a, COMPLEX *b, int n );

 void complex_schur_product( COMPLEX *a, COMPLEX *b, int n );

/* complex_vector_update: a = alpha * a + beta * b      
 *                        where both a and b are of length n     */
#ifndef _COMPLEX_H
void complex_vector_update( COMPLEX alpha, COMPLEX *a, 
                            COMPLEX beta,  COMPLEX *b, int n );
#else
void complex_vector_update( complex alpha, complex *a, 
                            complex beta, complex *b, int n );
#endif

#ifndef MATVECTK
void complex_vector_neg( COMPLEX *a, int n ) ;

/* complex_product - compute a (scalar) complex product */
COMPLEX complex_product( COMPLEX a, COMPLEX b );
COMPLEX complex_division( COMPLEX a, COMPLEX b );

void matrix_transpose( COMPLEX *A, int m, int n );
void dump_matrix( COMPLEX *A, int m, int n );

/* matrix_vector_product 
 *      A: a pointer to the complex matrix (m rows, n columns)
 *      b: a pointer to the complex vector (n entrys)
 *    res: a pointer to result is a complex vector, x = A b (m entrys)
 */
void matrix_vector_product( COMPLEX *A, COMPLEX *b, int m, int n,
                            COMPLEX *res );
void matrix_vector_product_threaded( COMPLEX *A, COMPLEX *b, int m, int n,
                                     COMPLEX *res, int num_thread );

/* complex_add - add to complex values */
COMPLEX complex_add( COMPLEX a, COMPLEX b );

typedef struct {
  COMPLEX *A;                   /* matrix */
  COMPLEX *b;                   /* vector */
  int m;                        /* number of rows in A  */
  int n;                        /* number of columns in A */
  COMPLEX *res;                 /* result, vector of length m */
  int tid;                      /* thread id */
#ifdef USE_PTHREADS
  pthread_mutex_t *mutex;
#endif
} MatVecARG;

void *matrix_vector_product_threads( void *args );

int test_vector_float( float *a, float *b, int m, float eps );
int test_vector_complex( COMPLEX *a, COMPLEX *b, int m, double eps );
#endif

#define MATVECTK 1

#ifdef __cplusplus
}
#endif
/*

Copyright 2009, National Center for Image Guided Therapy (NCIGT)

Written 2003-2009,  W. Scott Hoge (shoge@bwh.harvard.edu)

All rights reserved. Licensed according to the terms of a BSD-style 
licence covering the Fast Imaging Library 
(see http://www.ncigt.org/pages/Downloads "Imaging Toolbox")


*/
