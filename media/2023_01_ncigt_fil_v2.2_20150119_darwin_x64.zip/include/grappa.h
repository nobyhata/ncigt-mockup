#ifdef __cplusplus
extern "C" {
#endif

#ifndef MALLOC_ERROR
#define MALLOC_ERROR -1
#endif

#ifndef GRAPPA_H
/*! \ingroup pi */

#include "nd_data.h"

/*! \typedef struct dataheader

\brief The data header used in GRAPPA reconstructions

*/

typedef struct{
  int xres;                     /* the number of frequency encode samples (along the readout) */
  int yres;                     /* the number of phase encodes acquired */
  int Ncoils;
  int Nvertical;                /* the full space of kspace along the phase encode dimension.  */
} dataheader;

#ifndef IGT_FIL_H
typedef struct{
   float  ky;        /* Coordinate along ky axis */
   float  kz;        /* Coordinate along kz axis */
} KCOORD;
#endif

#ifndef GRAPPAOBJDEF
typedef struct {
  char    *pattern;
  int      nacs;
  int     *acs_lines;
  COMPLEX *N;
  char     direction;
  short    np;
  COMPLEX *eig_d;
  COMPLEX *eig_v;
  COMPLEX *eig_vi;
} GRAPPA_OBJ;
#define GRAPPAOBJDEF
#endif

#ifndef GRAPPAPARMDEF
typedef struct {
  int      ndk;
  int     *dks;                 /* array of (\Delta k) to calibrate/reconstruct */
  int      YKS;
  int      XKS;
  int      ncoil;
  GRAPPA_OBJ **parray;          /* 1st index: delta k, 2nd index: pattern */
  short    init;
  short    grog;
  float    ref_angle;
} GRAPPA_PARMS;
#define GRAPPAPARMDEF
#endif

/*! \typedef ReconPointsARG */

typedef struct{
  int coil;                     /**< index of coil to reconstruct */
  int kypt;                     /**< index of ky line to reconstruct */
  COMPLEX *O;                /**< the input k-space data */
  dataheader *hdr;              /**< header associated with input data */
  COMPLEX *N;                /**< the GRAPPA recon parameters */
  int YKS;                      /**< length of indx0 */
  int *indx0;                   /**< the ky kernel offsets */
  int XKS;                      /**< length of indx3 */
  int *indx3;                   /**< the kx kernel offsets */
  float radius;                 /**< radius of line recon. range 0 - 1 */
  int tid;                      /**< thread id */
#ifdef USE_PTHREADS
  pthread_mutex_t *mutex;       /**< thread mutex pointer  */
#endif
} ReconPointsARG;


/*! \typedef CalcParmsARG */

typedef struct{
  COMPLEX *O;                /**< input data */
  dataheader *hdr;           /**< header associated with input data */
  int  nacs;
  int *acsl;
  int  kxnum;
  COMPLEX *AH;
  COMPLEX *X;
  COMPLEX *N;
  int  XKS;                      /**< GRAPPA kernel size along readout direction */
  int  YKS;                      /**< GRAPPA kernel size along phase-encode direction */
  int  coil;
  int  xoffset;                  /* parameter to compute GROG offsets along kx */
  int  yoffset;                  /* parameter to compute GROG offsets along ky */
  int  tid;                      /* thread id */
#ifdef USE_PTHREADS
  pthread_mutex_t *mutex;
#endif
} CalcParmsARG;


/* GRAPPA functions */
int grappa( COMPLEX *I,      /**< input data */
            int *PhaseLines,    /**< input phase index list */
            dataheader *hdr,    /**< header associated with input data */
            COMPLEX *O,      /**< output data */
            int *Nlines,        /**< number of non-zero output lines */
            int **OutPhaseLines, /**< list of output non-zero lines */
            int YKS,            /**< grappa-kernel size, y-dim (2 or 4)*/
            int XKS,            /**< grappa-kernel size, x-dim (must be odd)*/
            float radius,       /**< size of reconstruction radius along
                                   freq-encode dimension.  In some cases
                                   (e.g. coil sensitivity estimation) the full
                                   read-out length is not needed */
            int ndk,            /**< number of Delta k's to compute.  If zero,
                                   then the dks list is computed
                                   automatically. */
            int *dks_in         /**< the list of dk's to compute. */
            );

int grappa_for_cine( short Nx,       /**< Size of input dataset, along kx (readout) */
                     short N_acq,    /**< k locs acquired / frame (in ky-kz plane) */
                     short Ny,       /**< Size of input dataset, along ky (phase) */
                     int   Ny_proc,  /**< Ny used for processing, in vdsense */
                     short Nz_proc,  /**< Nz used for processing */
                     short Nf,       /**< number of frames (either time or phase) */
                     short ncoils,   /**< Number of coils  */
                     short fill_fac, /**< fill factor, to accomodate non-int samp pts */
                     short fr1,      /**< whether 1st frame considered
                                        even (0) or odd (1) */
                     int   first_line, /**< First y line kept, when cropping recon FOV */
                     float pF,        /**< partial-Fourier (1=fully sampled,
                                         0.5=50% sampled) */

                     KCOORD *kline_c, /**< array of acquired phase encode lines */
                     float *samp_dens,
                     float *weight_pF,
                     COMPLEX *buf2,
                     COMPLEX *gparm, /**< pointer to GRAPPA reconstruction coefficients */
                     COMPLEX *data,  /**< pointer to input data */
                     COMPLEX *full   /**< pointer to reconstructed data */
                     );

int rlsgrappa( COMPLEX *I,      /**< input data */
               int *PhaseLines,    /**< input phase index list */
               dataheader *hdr,    /**< header associated with input data */
               COMPLEX *O,      /**< buffer to hold output data. This should
                                   be Nvertical x xres x Ncoils, i.e. zero padded */
               int *Nlines,        /**< number of non-zero output lines */
               int **OutPhaseLines, /**< list of output non-zero lines (will be malloced) */
               int YKS,            /**< grappa-kernel size, y-dim (2 or 4)*/

               float radius,       /**< size of reconstruction radius along
                                      freq-encode dimension.  In some cases
                                      (e.g. coil sensitivity estimation) the full
                                      read-out length is not needed */
               int ndk,            /**< number of Delta k's to compute.  If zero,
                                      then the dks list is computed
                                      automatically. */
               int *dks_in,        /**< the list of Delta k's to compute.  Set to
                                      NULL if ndk = 0.  */
               float lambda        /**< the rls forgetting factor */
               );


int grappa_apply_recon_coef( COMPLEX *O,      /**< zero-padded input data, sized to
                                                 be xres x Nvertical x Ncoils */
                             int *PhaseLines,    /**< input phase index list [yres in length] */
                             dataheader *hdr,    /**< header associated with input data */
                             int *Nlines,        /**< number of non-zero output lines */
                             int **OutPhaseLines, /**< list of output non-zero lines (will be malloced) */
                             float radius,       /**< size of reconstruction radius along
                                                    freq-encode dimension.  In some cases
                                                    (e.g. coil sensitivity estimation) the full
                                                    read-out length is not needed */
                             GRAPPA_PARMS *gparm
                             );

int grappa_calc_recon_coef( COMPLEX *O,       /**< buffer holding zero-padded input data. This should
                                                   be Nvertical x xres x Ncoils */
                            int *PhaseLines,  /**< input list of phase index showing which lines of
                                                 O have data. */
                            dataheader *hdr,  /**< header associated with input data */
                            GRAPPA_PARMS *gparm,
                            float radius      /**< width, (0.0 .. 1.0], of readout lines to use in calibration */
                            );

int grappa_clear_parms( GRAPPA_PARMS *gparms );

int grappa_calc_parms( dataheader *hdr, /**< header associated with input data */
                       COMPLEX *O,   /**< zero-padded k-space data */
                       int YKS, /**< size of kernel along phase encode direction (length of indx0) */
                       int *indx0, /**< phase encode offsets for kernel  */
                       int XKS, /**< size of kernel along read-out direction (length of indx3) */
                       int *indx3, /**< sample offsets along readout */
                       int nacs, /**< number of ACS lines */
                       int *acsl, /**< array of ACS line indices  */
                       int kxnum, /**< number of readout (k_x) points used for calibration */
                       COMPLEX **gparm,   /**< the output GRAPPA parameters */
                       int fullsqr,
                       int direction
                       );

int grappa_recon( dataheader *hdr, /**< structure describing the data  */
                  COMPLEX *O, /**< the (zero-padded) input data */
                  int YKS,    /**< size of kernel along phase encode direction */
                  int *indx0, /**< phase encode offsets for kernel  */
                  int XKS,    /**< size of kernel along read-out direction  */
                  int *indx3, /**< sample offsets along readout */
                  int *bins,    /**< an array dscribing the data along the
                                   phase encoding dimension. 0 : empty ; 1 :
                                   raw data ; 2 : ACS line  */
                  COMPLEX *gparm, /**< pointer to the GRAPPA reconstruction
                                        parameters */
                  float radius   /**< size of reconstruction radius along
                                  freq-encode dimension */
                  );


int grappa_recon__all_slices( DATA_OBJ *data_frame,  /**< The input k-space data:
                                                       ndim should equal '4', sized: kx-ky-z-coil  type: double-complex ('dblc')
                                                    */
                             int      *phase_list,   /**< List of phase encode locations */
                             int      *nphz,         /**< number of phase encode locations */
                             GRAPPA_PARMS **gparm_all /**< An initialized memory buffer object */
                              );


void init_gparm( GRAPPA_PARMS *gparm );
int  export_grappa_coef( GRAPPA_PARMS **gparm, DATA_OBJ *gexport, int ncoil, int nslc);
int  import_grappa_coef( GRAPPA_PARMS ***gparm_out, DATA_OBJ *gimport );

void extrapolate_pattern( char* pattern, int* indx0, int YKS, int dk );

#define GRAPPA_H

#endif

#ifdef __cplusplus
}
#endif

/*

Copyright 2009, National Center for Image Guided Therapy (NCIGT)

Written by W. Scott Hoge (shoge.harvard.edu)

All rights reserved. Licensed according to the terms of a BSD-style
licence covering the Fast Imaging Library
(see http://www.ncigt.org/pages/Downloads "Imaging Toolbox")


*/
