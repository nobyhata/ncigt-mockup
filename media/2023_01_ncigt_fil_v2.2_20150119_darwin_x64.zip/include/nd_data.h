/* header file for C routines to pass data back and forth between Matlab.  *
 *                                                                         */

#ifdef __cplusplus
extern "C" {
#endif

#ifndef __DATA_OBJ__
typedef struct {
  long unsigned int  init;
  int  ndim;
  int  sz[8];
  char type[5];
  char *data;
  long unsigned int  metalength;
  char *metadata;
} DATA_OBJ;
#define __DATA_OBJ__
#endif

#ifndef ND_DATA_H
  int read_nd_data2( char *filename, DATA_OBJ *dat );
  int write_nd_data2( char *filename, DATA_OBJ *dat );

  int read_nd_data( char *filename, char **ptr, char *frmt, int *ndim, int *sz );
  int write_nd_data( char *filename, void *bin, char *frmt, int  ndim, int *sz );

  short nd_data_type_size( char* type );
  void init_data_obj( DATA_OBJ *dat );
  void free_data_obj( DATA_OBJ *dat );
  void copy_data_obj( DATA_OBJ *dest, DATA_OBJ *src );
#define ND_DATA_H 1
#endif

#ifdef __cplusplus
}
#endif
/*

Copyright 2009, 2013, National Center for Image Guided Therapy (NCIGT)


Written 2003-2013,  W. Scott Hoge (shoge@bwh.harvard.edu)

All rights reserved. Licensed according to the terms of a BSD-style 
licence covering the Fast Imaging Library 
(see http://www.ncigt.org/pages/Downloads "Imaging Toolbox")

*/
