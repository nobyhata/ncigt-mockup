#ifdef __cplusplus
extern "C" {
#endif

#ifndef GESTE_H

#define GESTE_H

#ifndef __DATA_OBJ__
#include "nd_data.h"
#endif

typedef struct {
  short init;
  fil_fft_mngr fft_mngr;
  COMPLEX *C_odd;
  COMPLEX *C_even;
  COMPLEX *O_odd;
  COMPLEX *O_even;
  int ndim;
  int *sz;
  int nslices;
  GRAPPA_PARMS **gparm;
  int ndk;
} GESTE_MEM;

void geste_init( GESTE_MEM *mem, DATA_OBJ *data_frame );
void geste_quit( GESTE_MEM *mem );

int pull_readout_data( int ndim,         /**< number of dimensions in data set */
                       int *sz,          /**< size array, describing each dimension  */
                       COMPLEX *P,       /**< the source data  */
                       int indx_in,      /**< the first index of source data to read */
                       COMPLEX *Pfull,   /**< the destination buffer  */
                       int indx_out      /**< the first index for the data destination  */
                       );

int geste_interleave_frames( DATA_OBJ* even_frame, /**< frame1: even lines are positive readout k-space */
                             DATA_OBJ* odd_frame,  /**< frame2: odd lines are positive readout k-space  */
                             DATA_OBJ* combo, /**< combined data */
                             int mode, /**< 0: FFT the output before returning */
                             GESTE_MEM *mem
                             );

int geste_calibrate__all_slices( DATA_OBJ *combo,
                                 float    *phase_list,
                                 GESTE_MEM *mem );

int geste_recon__all_slices( DATA_OBJ *data_frame,
                             float    *phase_list,
                             DATA_OBJ *img,
                             GESTE_MEM *mem,
                             int polarity
                             );


int run_geste( DATA_OBJ *even_frame,
               DATA_OBJ *odd_frame,
               DATA_OBJ *raw_frame,
               float *phase_list,
               DATA_OBJ *img,
               GESTE_MEM *mem
               );

#endif

#ifdef __cplusplus
}
#endif

/*

Copyright 2009, National Center for Image Guided Therapy (NCIGT)

Written by W. Scott Hoge (shoge.harvard.edu)

All rights reserved. Licensed according to the terms of a BSD-style
licence covering the Fast Imaging Library
(see http://www.ncigt.org/pages/Downloads "Imaging Toolbox")

*/
