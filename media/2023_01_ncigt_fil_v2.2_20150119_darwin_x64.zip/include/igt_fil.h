/********************************************************
* A Library of functions for fast MR imaging            *
* reconstructions.                                      *
*                                                       *
* Written by Bruno Madore and Scott Hoge, Harvard       *
* Medical school, 2005-2007.                            *
*                                                       *
********************************************************/

#ifndef IGT_FIL_H

#define  IGT_FIL_H 1

/*
 * All the most common include
 */
#include <math.h>
#include <memory.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#ifdef __cplusplus
extern "C" {
#endif


#include "fil_fft.h"

/*
 * Define a few epic-related parameters (CoreSelect.e).
 */
#define IRPREP          8	/* 2^3 */
#define FASTCARD        32	/* 2^5 */
#define FASTCARD_MP     128	/* 2^7 */
#define ECHOTRAIN       65536	/* 2^16 */
#define FASTCINE        131072	/* 2^17 */
#define FIESTA          524288	/* 2^19 */

#ifndef PI
#define PI              3.141592654
#endif

/* the _V_erbose flag.  Default to OFF.*/
/*
// #ifndef V
// short V=0;
// #endif
*/

#ifndef RINT
#define RINT(x) (int) floor( x + 0.5 )
#endif

/*
 * Define structures.
 */

#define FLT 0
#define DBL 1
#ifdef USEFLOATS
#define DATATYPE float
#define DATAFLAG FLT
#else
#define DATATYPE double
#define DATAFLAG DBL
#endif

#ifndef __COMPLEX__
typedef struct{
   DATATYPE  re;        /* Real part */
   DATATYPE  im;        /* Imaginary part */
} COMPLEX;
#define __COMPLEX__
#endif

#include "nd_data.h"

/* Coordinates in a ky-kz and a y-z plane */
typedef struct{
   float  ky;        /* Coordinate along ky axis */
   float  kz;        /* Coordinate along kz axis */
} KCOORD;
typedef struct{
   float  y;         /* Coordinate along y axis */
   float  z;         /* Coordinate along z axis */
} XCOORD;
/* x, y, & z gradient unwarped_loc*/
typedef struct {
   float x;
   float y;
   float z;
} UNW_LOC;
/* Structure to hold one entry from a DICOM header */
typedef struct node{
   unsigned short tag[2];     /* Tag that identifies a specific entry */
   char  vr[2];      /* 2 letters specifying the data type */
   int   length;     /* Length, in bytes, of the value field */
   int   offset;     /* Offset where the value field is found, in bytes */
   short len_len;    /* Length of the length field, in bytes (2 or 4) */
   short num;        /* Entry number, in a list of entries */
} LIST_NODE;
/* Structure for scan info (typically, obtained from the header of P
   files, or in a text file written by the psd, or from the command line). */
typedef struct{
   /* From P file header */
   float  rev;       /* Revision number (7.0 for LX, 8.0 for excite 1
                        (10.0), and 9.0 for excite 2 (11.0)) */
   int    exam_no;   /* Exam number */
   int    series_no; /* Series number */
   int    hdrsize;   /* Size of header, in bytes */
   short  matx;      /* requested output image size, along x (imatrix_X) */
   short  maty;      /* requested output image size, along y (imatrix_Y) */
   short  frame_size;  /* length of readout data */
   short  Nx;        /* Size of input dataset, along kx */
   short  Ny;        /* Size of input dataset, along ky */
   short  Nz;        /* Size of input dataset, along kz */
   int    Nsl;       /* # of slices in prescription (>=Nz) */
   float  slthick;   /* Slice thickness (mm) */
   float  scanspacing;/* Spacing between slices (mm) */
   short  Nt;        /* Number of time points */
   short  nph;       /* Number of cardiac phases */
   short  ncoils;    /* Number receiver coils */
   float  fov_fr;    /* x FOV */
   float  fov_ph;    /* y FOV */
   short  rotated;   /* 0/1 if freq. dir is hor/ver */
   float  tlc[3];    /* Coord. top left corner */
   float  trc[3];    /* Coord. top right corner */
   float  brc[3];    /* Coord. bottom right corner */
   float  blc[3];    /* Coord. bottom left corner */
   int    tr;        /* Pulse repetition time (us) */
   int    te;        /* Echo time (us) */
   int    pos;       /* Patient position (1 supine, 2 prone,
                        4 left decub, 8 right decub */
   int    entry;     /* Patient entry (1 head first, 2 feet first) */
   float  loc0;      /* Location of first slice */
   char   ras0;      /* Axis for value loc0 */
   float  user14;    /* Variable opuser 14 */
   float  user15;    /* Variable opuser 15 */
   float  user16;    /* Variable opuser 16 */
   float  user17;    /* Variable opuser 17 */
   float  user18;    /* Variable opuser 18 */
   float  user19;    /* Variable opuser 19 */
   float  user20;    /* Variable opuser 20 */
   float  user21;    /* Variable opuser 21 */
   float  user22;    /* Variable opuser 22 */
   float  user23;    /* Variable opuser 23 */
   float  user24;    /* Variable opuser 24 */
   float  user25;    /* Variable opuser 25 */
   float  user26;    /* Variable opuser 26 */
   float  user27;    /* Variable opuser 27 */
   float  user28;    /* Variable opuser 28 */
   float  user29;    /* Variable opuser 29 */
   char   coil[17];  /* Name of imaging coil */
   char   seq[33];   /* Name of pulse sequence */
   int    gw;        /* flag (0 or 1) to do grad warp */
   /* From info file written by psd, or command line */
   int    rotmat[3][3]; /* Rotation matrix */
   int    length_wr; /* Number of lines in info file */
   int    ecg_entries; /* Number of entries in ecg info file */
   float  n;         /* Total acceleration */
   int    n_o;       /* Acceleration, in outer k-space regions */
   int    n_s;       /* Acceleration, in outer k-space regions */
   float  n_c;       /* Acceleration near k-space center */
   int    opetl;     /* Echo train length */
   int    Nf_intrp;  /* # of (interpolated) frames to recon */
   int    opvps;     /* Number of views per segment */
   int    locs_brth; /* Number of slices per breathold */
   float  nex;       /* Number of averages (<1 for partial-Fourier) */
   int    hrate;     /* Heart rate, in beats per minute */
   int    dgy1_dky;  /* gy1 for 1 ky line, interleaved EPI*/
   int    dgyb_dky;  /* gy1 for 1 ky line, interleaved EPI*/
   int    delta_ky;  /* Distance between k lines */
   float  off_phdir; /* Shift wrt isocenter along phase-enc. */
   float  tloc0, tloc1; /* rsp_info[sl].rsptloc, slices 0, 1 */
   int    recon_alg; /* Parallel im. alg. (1=SENSE, 2=SPACERIP) */
   float  recon_filt;/* Width of UNFOLD filter, in frac of bw */
   int    unfold;    /* User-set flag for UNFOLD artifact supp. */
   float  b1snr_thr; /* SNR threshold for sensitivity maps */
   float  pisnr_thr; /* SNR threshold in par im recon */
   int    feature_flag; /* From psd, determines the core executed */
   int    dump_b1maps;  /* User-set flag for displaying b1 maps */
   short  N_acq;     /* k locs acquired per frame (in ky-kz plane) */
   short  z_req;     /* Requested z location to recon (command line) */
   short  z_first;   /* Slice number of 1st z in input data */
   /* Calculated or deduced from parameters above (specific to vdsense) */
   int    fill_fac;  /* Interpolation factor, to make k numbers integer */
   int    first_line;/* First y line kept, when cropping recon FOV */
   int    n_c_proc;  /* n_s used for processing, in vdsense*/
   int    n_s_proc;  /* n_s used for processing, in vdsense*/
   int    n_o_proc;  /* n_s used for processing, in vdsense*/
   short  N_P;       /* Number of k lines per frame, in P files */
   int    Nk_total;  /* Total number of k-space lines acquired */
   short  Ny_proc;   /* Ny used for processing, in vdsense */
   short  rfchop;    /* Flag for RF chopping */
   float  n_c_b1;    /* Acceleration near k center, for B1 calcs */
   float  sigmak;    /* Standard deviation of noise on k-space data */
   /* Calculated or deduced from parameters above (specific to unfold) */
   short  Nf_proc;   /* Nf used for processing, in unfold */
   int    n_dc;      /* Acceleration required near w=0 */
   short  fr1;       /* Whether 1st frame considered even (0) or odd (1) */
   /* Calculated or deduced from parameters above (others) */
   float  pF;        /* Partial-Fourier (1=fully sampled, 0.5=50% sampled) */
   short  Nf;        /* Number of frames (either time or phase) */
   short  endian;    /* Flag to swap (1) or not (0) the input data. The
                        scanner used big-endian format for versions 8 or
                        less, and little-endian for 9 or above. Bytes may
                        have to be swapped depending if recon is run on a
                        PC (little-endian), or a Sun/SGI (big-endian). */
   short  Nz_proc;   /* Nz used for processing */
   short  Ny_ratio;  /* To keep P files more compact, some applications
                        involve using a phase FOV smaller than the 'truth' */
   char   application[50];/* Description of the MR application */
   /* Others */
   short  Npfiles;   /* Number of P files to reconstruct */
   short  N_runs;    /* Number of times "start" button pressed */
   short  z_start;   /* Starting z location to reconstruct */
   short  z_stop;    /* Last z location  to reconstruct */

   int    user_params[40];
   short *slice_order;
} SCAN_INFO;

#ifndef __GWARP_PARMS__
typedef struct {
  double scx3; /* = -4.278387e-04;  */   /*gw_coils*/
  double scx5; /* = -2.693236e-08;  */
  double scy3; /* = -3.798880e-04;  */
  double scy5; /* = -5.643789e-08;  */
  double scz3; /* = -0.599797e-04;  */
  double scz5; /* = -0.294917e-07;  */
  double xcal; /* = 1.0;            */
  double ycal; /* = 1.0;            */
  double zcal; /* = 1.0;            */
} GWARP_PARMS;
#define __GWARP_PARMS__
#endif


/*
 * List of individual functions, in the parallel-imaging library.
 */
/* I/O functions */
extern void     display_params(SCAN_INFO hdr);
extern void     read_command_line1(char **argv, int argc, short *V_ptr,
                short *U_ptr, short *GW_ptr, short *SL_ptr,
                short *next_token_ptr, SCAN_INFO *hdr_ptr);
extern void     read_command_line2(char **argv, int argc, short *next_token_ptr,
                short Npfiles, char **Pnames, char **infofile, char **imfile, short
                *next_im_ptr);
extern short    read_hdr_ge(char *Pname, SCAN_INFO *hdr_ptr);
extern short    read_hdr_measdat(char *datafile, SCAN_INFO *hdr_ptr);

extern void     read_info1(char **infofile, SCAN_INFO *hdr_ptr);
extern void     read_info2(char **infofile, KCOORD *kline, KCOORD *kline_o,
                KCOORD *kline_e, KCOORD *kline_c, SCAN_INFO hdr);
extern void     swap_two(short *input, int length);
extern void     swap_four(int *input, int length);
extern int      slice_number(int isl, int nsl, int slice, char *application);
extern short    read_data_ge(char **Pnames, int isl, SCAN_INFO hdr, KCOORD *kline,
                             KCOORD *kline_o, KCOORD *kline_e, COMPLEX *kspace_data);
extern void     correct_fcard(SCAN_INFO hdr, COMPLEX *kspace_data);
extern int      imnum_out(short next_im, short z_anat, short Nf, short ncoils,
                short dump_b1maps);
extern void     dump_out(char *name, int nc_out, int nf_out, int nz_out, int ny_out,
                int nx_out, short endian, COMPLEX *bin);
extern void     orientation(float x_tl, float y_tl, float z_tl, float x_tr,
                float y_tr, float z_tr, float x_br, float y_br, float z_br,
                int *rot1, int *rot2, int p_pos, int p_entry, short *flip_h_ptr,
                short *flip_v_ptr, short *rot_90_ptr);
extern short    rot_and_flip_data_obj( short rot_90, short flip_h, short flip_v, DATA_OBJ *obj );


extern short    write_ima(SCAN_INFO hdr, short flip_h, short flip_v, short rot_90,
                char **imfile, int imnum, int z_anat, COMPLEX *buf, COMPLEX *result,
                char *path_out);

extern int read_data_from_Pfile( SCAN_INFO *hdr,
                                 DATA_OBJ *rawframe,
                                 DATA_OBJ *vrgf,
                                 FILE *fid,
                                 char *buf,
                                 char *buf2,
                                 int  slice,
                                 int  vol,
                                 int  nbaselines
                                 );

extern int read_data_from_measdat( SCAN_INFO *hdr,
                                   DATA_OBJ *rawframe,
                                   DATA_OBJ *vrgf, 
                                   FILE *fid,
                                   char *buf,
                                   char *buf2,
                                   int  slice,
                                   int  vol,  
                                   int  ngc_flag
                                   );


/* Function related to grad warping */
extern void     gwarp_prep(float tl[], float tr[], float bl[], float br[], int N_h,
                int N_v, float hpixs[], float vpixs[], float d[], float u[]);
extern void     spline(float *x, float *y, int n, float yp1, float ypn, float *y2);
extern void     splint(float *, float *, float *, int, float, float *);
extern void     gwarp_calc(float *,float *,float *,float *,int, int, float *, float *,
                           float *, float *, float *, float *, float *, char * );
extern void     gwarp_apply2(float *, float *, float *, float *, float *, int, int,
                float *);
extern void     gwarp_epsilon(float *, float *, GWARP_PARMS * );
/* Functions for fast imaging schemes (parallel-imaging, unfold, partial-Fourier) */
extern void     vdsense(short Nx, short N_acq, short Ny, short Ny_proc, short Nz_proc,
                short Nf, short ncoils, short fill_fac, short fr1, short first_line,
                float pF, fil_fft_mngr *mngr, KCOORD *kline_o, KCOORD *kline_e,
                float *samp_dens, float *weight_pF, COMPLEX *buf, DATATYPE *Uarray,
                COMPLEX *data, COMPLEX *vdsen_ima);

extern int      inv_sens_matrix(short ncoils,
                    short npts,
                    float thresh,
                    double **a,
                    double *w,
                    double **v,
                    double *wgt_roe,
                    double *wgt,
                    double **S,
                    double **S_buf,
                    double **S_inv,
                    double **S_inv_buf
                                );


extern void     vdsense_prep(short Nx, short Ny, short Nz, short ncoils, float thresh,
                int accel, XCOORD *alias, COMPLEX *b1, DATATYPE *Uarray);
extern void     vdsense_apply(short Nx, short Ny, short Nz, short Nf, short ncoils,
                COMPLEX *sen_before, DATATYPE *Uarray, COMPLEX *sen_after);


void self_ref_b1_basic( COMPLEX *kspace_data,
                        float  b1snr_thr,
                        short  Ny,
                        short  Nx,
                        short  Nz,
                        short  ncoils,
                        short  Nf,
                        fil_fft_mngr *mngr,
                        COMPLEX *b1
                        );

extern void self_ref_b1_for_cine( COMPLEX *kspace_data, /**< Re-ordered data of size
                                           (Nx, N_acq, Nz, nph, ncoils). */
                  float  sigmak,	/**< Noise level in kspace_data. */
                  float  b1snr_thr,	/**< SNR threshold for sensitivity maps. */
                  short  N_acq,		/**< Number of sampled lines per frame. */
                  short  Nx,		/**< Dimension along the x/kx direction. */
                  short  Ny,		/**< Dimension along the y/ky direction. */
                  short  Ny_proc,	/**< > Ny if sampling density > 1 at ky~=0. */
                  short  Nz_proc,	/**< Dimension along the z/kz direction. */
                  short  ncoils,	/**< Number of coil elements in array. */
                  short  Nf,		/**< Number of frames in kspace_data. */
                  short  fr1,		/**< 1st frame considered even (0) or odd (1) */
                  short  fill_fac,	/**< Factor to make ky lines integer. */
                  short  first_line,	/**< First line for cropping (0 = off). */
                  float *filt_b1,       /**< Filter to select ky-kz region
                                           for B1 sensitivity mapping. */
                  KCOORD *kline_o,      /**< Sampling function, odd frames.  */
                  KCOORD *kline_e,      /**< Sampling function, even frames. */
                  float *samp_dens,     /**< Sampling density, in ky-kz plane.	*/
                  fil_fft_mngr *mngr,	/**< FFT manager */
                  COMPLEX *bufsp,       /**< Memory space, to work in.  */
                  COMPLEX *b1           /**< B1 sensitivity maps. */
                                  );


extern void     generate_b1_filter(int fill_fac, short Ny, short Nz_proc, float *samp_dens, float *filt_b1);
extern int      set_fill_fac(float n_c_b1);
extern float    set_ncb1(SCAN_INFO hdr, KCOORD *kline_o, KCOORD *kline_e);
extern int      set_nsproc(int n_s, float n_c_b1);
extern int      set_nyproc(short Ny, float n_c_b1, int n_s_proc);
extern int      set_firstline(short Ny, int fill_fac, int Ny_proc);
extern int      set_nfproc(short Nf, short flag);
extern int      spacerip_for_cine( short Nx,        /**< Size of input dataset, along kx (readout) */
                                   short N_o,       /**< k locs acquired in odd ky-kz frames */
                                   short N_e,       /**< k locs acquired in even ky-kz frames */
                                   short N_c,       /**< k locs acquired in combined frames */
                                   short Ny,        /**< Full matrix size along ky (phase) */
                                   int   Ny_proc,   /**< Ny used for processing, in vdsense */
                                   short Nz_proc,   /**< Nz used for processing */
                                   short Nf,        /**< number of frames (either time or phase) */
                                   short ncoils,    /**< Number of coils  */
                                   float pF,        /**< partial-Fourier (1=fully sampled,
                                                       0.5=50% sampled) */
                                   KCOORD *kline_o, /**< lines acquired on 'odd' frames  */
                                   KCOORD *kline_e, /**< lines acquired on 'even' frames */
                                   KCOORD *kline_c, /**< lines acquired on combined frames */
                                   COMPLEX *b1,     /**< pointer to sensitivity map data */
                                   COMPLEX *buf,    /**< pointer to available memory block */
                                   COMPLEX *data,   /**< pointer to input data */
                                   COMPLEX *spacerip,       /**< pointer to reconstructed data */
                                   short recon_flag /**< 0 for low t freqs, 1 for high t freqs */
                                   );

extern void     prep_unfold_dc(short Nx, short N_acq, short Nf, short ncoils,
                               fil_fft_mngr *mngr,
                               KCOORD *kline_o, KCOORD *kline_e, short fr1,
                               COMPLEX *data, COMPLEX *buf_lg,
                               COMPLEX *buf_sm, float *filter_dc,
                               float *filter_dckept, short *near_dc,
                               short filt_w, short Nf_proc,
                               KCOORD *kline_c, COMPLEX *data_dc);
extern void     unfold_recombine(short Nx, short Ny_proc, short Nz_proc, short Nf_proc,
                short *near_dc, short filt_w, COMPLEX *dc, COMPLEX *full);
extern void     setup_unfold(SCAN_INFO *hdr_ptr, int Nt, float *filter_dc,
                float *filter_ny, float *filter_dckept, float *filter_dcny,
                short *near_dc, short *filt_w);
extern void     unfold_filter(short ncoils, short Nf, short Nz, short Ny,
                short Nx, float *filter, COMPLEX *data);
extern void     synth_frames(short ncoils, short Nf, short Nz, short Ny, short Nx,
                COMPLEX *data_in, short Nf_proc, COMPLEX *data_out);
extern void     transfer_dc(short dir, short ncoils, short Nf, short Nz, short Ny,
                short Nx, short filt_w, short *near_dc, float *filter,
                COMPLEX *lg_array, COMPLEX *sm_array);
extern void     setup_pF(SCAN_INFO *hdr_ptr, float *samp_dens, float *filt_pF,
                float *weight_pF, short filter_type );
extern void     homodyne_kcentral(short ncoils, short Nf, short N_acq, short Nx,
                float *filt_pF, KCOORD *kline_o, KCOORD *kline_e, short fr1, int fill_fac,
                short Ny, COMPLEX *data, short Nz_proc, short Ny_proc, COMPLEX *data_pF);
extern void     apply_pF(short Nx, short Ny, short Nz, short Nf, COMPLEX *phase_ref,
                COMPLEX *result);
/* Utility functions */
extern void     calc_samp_dens(KCOORD *kline_o, KCOORD *kline_e, short N_acq,
                short Nz_proc, int fill_fac, short Ny, float *samp_dens);
extern float    eval_knoise(SCAN_INFO hdr, COMPLEX *kspace_data, KCOORD *kline_o,
                COMPLEX *bufspace);
extern void     kstretch(short Nx, short Ny, short Nz_proc, short N_acq,
                short fill_fac, short ifr, short fr1, KCOORD *kline_o,
                KCOORD *kline_e, COMPLEX *data, COMPLEX *data_str);
extern void     weigh_kykz(short ncoils, short nf, short nz, short ny, short nx,
                float *weight, COMPLEX *data);
extern void     fermi(short N, float trw, float *f);
extern void     apodization(SCAN_INFO hdr, int Nx, float *fx, int Ny,
                float *fy, int Nz, float *fz, KCOORD *kline_o, KCOORD *kline_e,
                COMPLEX *data);
extern void     select_kcenter(short firsty, short lasty, short Ny, short firstz,
                short lastz, short Nz, float *filt);
extern float    pythag(float a, float b);
extern void     apply_ramp(COMPLEX *data, short Nx, short Ny, short nph,
                short ncoils, float rampx, float rampy);
extern void     extract_ksubset(short ncoils, short nf, short nx, KCOORD *kline_full,
                KCOORD *kline_sub, short nl_full, short nl_sub, COMPLEX *fullmat,
                COMPLEX *submat);

/* For reading/writing DICOM headers (functions coded by Greg Kirk, modified by BM) */
extern void     get_dicom_info(char *filename, LIST_NODE *list, short Nmax);
extern void     print_list(LIST_NODE *list, char *filename);
extern LIST_NODE find_tag(LIST_NODE *list, short tag0, short tag1);
extern int      is_dicom(char *filename);
extern void     eval_dicom(LIST_NODE *list, short tag0, short tag1, char *filename,
                char *value, char *value_type, short max_length);
extern void     edit_dicom(LIST_NODE *list, short tag0, short tag1, char *filename,
                char *im_hdr, int *hdrsize_ptr, void *newvalue, short newvalue_length);

/* For a retrospectively-gated cardiac cine application */
extern  void    read_command_line_cine(char **argv, int argc, short *V_ptr,
                short *U_ptr, short *GW_ptr, short *SL_ptr, SCAN_INFO *hdr_ptr,
                char **rawfile, char **phdrfile, char **infofile, char **imfile,
                char **ecgfile, short *next_im_ptr);
extern void     read_ecg_info(char **ecgfile, SCAN_INFO *hdr_ptr, int *trig_rr,
                int *trig_seg, int *trig_slice, int pass);
extern void     puzzleout_cineacq(int *trig_rr, int *trig_seg, int *trig_slice,
                SCAN_INFO *hdr_ptr, KCOORD *kline_o, KCOORD *kline_e, int *hb_length,
                float *acq_timing);
extern void     nonlin_cphase(SCAN_INFO hdr, int *hb_length, float *acq_timing,
                float systole_thr);
extern void     sort_rds_data(short *rawdata, int z, SCAN_INFO hdr, float *acq_timing,
                COMPLEX *kspace_data);
extern void     eval_cine_info(short Ny, short N_acq, int Nk_total, int z,
                KCOORD *kline_o, KCOORD *kline_e, int Nf, float *acq_timing,
                float *cph_record, int *acq_record);
extern float    eval_knoise_cine(SCAN_INFO hdr, COMPLEX *kspace_data, KCOORD *kline_o,
                COMPLEX *bufspace);
extern void     calc_DC_for_b1(short Nx, short N_acq, short Ny, short Nf, short fr1,
		short ncoils, KCOORD *kline_c, int *acq_record, COMPLEX *xkykz,
		COMPLEX *DC_xkykz);
extern void     synth_frames_cine(short ncoils, short Nf_full, short fr1, short Nf,
                short N_acq, short Nx, short ky, KCOORD *kline_o, KCOORD *kline_e,
                COMPLEX *data_in, short Nf_proc, COMPLEX *data_out);
extern void     retrosp_gating_interp(short ncoils, short Nf_intrp, short Nf,
                short N_lines, short Ny, short Nx, short k, short ky, float *cph_record,
                float *ph_recon, COMPLEX *current_line, COMPLEX *kcine);

/*extern void     self_ref_b1_cine(SCAN_INFO hdr, COMPLEX *kspace_data, float *filt_b1,
                KCOORD *kline_o, KCOORD *kline_e, float *samp_dens, float *cph_record,
                fftw_plan pyb, fftw_plan pzb, COMPLEX *bufsp, COMPLEX *b1);
extern void     prep_unfold_cine(short Nx, short N_acq, short Nf, short Nf_intrp,
                short ncoils, KCOORD *kline_o, KCOORD *kline_e, short fr1, COMPLEX *data,
                short Nf_proc, KCOORD *kline_c, COMPLEX *data_oe);*/

typedef struct {
  int n;                        /* temporal filter length */
  int x;                        /* row dimension */
  int y;                        /* column dimension */
  int c;                        /* number of coils */
  COMPLEX *taps;                /* memory for previous samples */
  double *a;                    /* feedback coefficients */
  double *b;                    /* feedforward coefficients */
  int t;                        /* time point */
} filter_t_obj;

extern int filter_t_init( int n, int x, int y, int c,
                          double *a, double *b, filter_t_obj *obj );

extern int filter_t_quit( filter_t_obj *obj );

extern int filter_t_step( filter_t_obj *obj, COMPLEX *dataI, COMPLEX *dataO );


extern void sprip_cgsr_recon( float *phz_encode_list,
                 int P,
                 int N,
                 int M,
                 int L,
                 COMPLEX *W,
                 COMPLEX *Sk,
                 double tau,
                 int maxits,
                 COMPLEX *rho,
                                  int tmax );

extern void sprip_cgsr_init( int nph,
                             int N,
                             int L,
                             int threadnum
                             );

extern void sprip_cgsr_post();

extern void sprip_lsqr_recon(  float *phz_encode_list,
                               int P,
                               int N,
                               int M,
                               int L,
                               COMPLEX *W,
                               COMPLEX *Sk,
                               float *lams,
                               int numlams,
                               COMPLEX *D,
                               int maxits,
                               COMPLEX **rho,
                               double *xout,
                               double *rout,
                               int tmax,
                               float *usedlams
                               );

extern void sprip_lsqr_init( int nph,
                             int N,
                             int L,
                             int threadnum,
                             int lamsize,
                             int maxits
                             );

extern void sprip_lsqr_post();


extern void sprip3d_lsqr_init( int nph,
                               int M,
                               int N,
                               int L
                               );
extern void sprip3d_lsqr_post();

extern void sprip3d_lsqrsolv( int *Y,
                              int nph,
                              int m,
                              int n,
                              int L,
                              COMPLEX *W,
                              COMPLEX *Sk,
                              COMPLEX **I,
                              float *lams,
                              int lamsize,
                              int maxits,
                              double *xnormout,
                              double *Rout,
                              int tid
                              );


#include "matvectk.h"
#include "grappa.h"
#include "phase_align.h"

/* ** renamed from 'est_b1_via_geyser' */
extern int self_ref_b1_via_geyser( COMPLEX *ptrI,
                              dataheader *hdrKS,
                              int *PhaseLines,
                              COMPLEX *ptrW,
                              fil_fft_mngr *mngr,
                              int mask
                              );

void compute_b1_mask( DATATYPE *a, int Nx, int Ny, int Nz,
                      double thrs, char *mask );


/*** EPI Specific Functions ***/
int read_vrgf_ge( char* fname, int Nx,
                  char endian, DATA_OBJ *H );

int correct_rampsamp( DATA_OBJ *k,
                      DATA_OBJ *vrgf,
                      void     *scratchbuf
                      );

int parse_vrgf_siemens( char* fname, 
                        DATA_OBJ *H );


int read_refdat_ge( char *fname,
                    DATA_OBJ *refdat, /**< input data to correct (output */
                    int yres,
                    int ncoils
                    );

int apply_epi_phase_ge( COMPLEX *k, /**< input data to correct, of size [ xres yres ncoils ] */
                        int xres,   /**< number of points along readout  */
                        int yres,   /**< number of points along phase-encode
                                       direction */
                        int ncoils, /**< number of frames/coils */
                        DATA_OBJ *refdat, /**< the ref.dat file, held in a data object. */
                        int expidir /**< the direction of the applied shift.
                                       Choices are limited to +1 or -1. */
                        );


#ifndef NGC_MEM_OBJ
typedef struct{
  short int init;
  Phase_Correlation_Args phzcorarg;
  float   *mask;
  COMPLEX *ngc_tbuf;
  COMPLEX *P;
  COMPLEX *N;
} NGC_MEM;
#define NGC_MEM_OBJ
#endif

int ngc_mem_init( int *sz, int nEl, NGC_MEM *ngc_mem );
int ngc_mem_quit( NGC_MEM *ngc_mem );
int ngc_compute_phase_shift( DATA_OBJ *ngc_even, 
                             DATA_OBJ *ngc_odd, 
                             DATA_OBJ *ramp,
                             fil_fft_mngr *mngr,
                             NGC_MEM *ngc_mem
                             );
int ngc_apply_phase_shift( DATA_OBJ *k, DATA_OBJ *ramp, fil_fft_mngr *mngr, NGC_MEM *ngc_mem );




int calc_vrgf_data_matrix( DATA_OBJ *vrgf, /*<< the output regridding matrix */
                           int input_res,  /*<< number of input data on readout */
                           int output_res, /*<< number of data points on the readout line after gridding */
                           float time_attack, /*<< the 'ramp up' time for the gradient   (in msec) */
                           float time_flat,   /*<< the 'flat top' time for the gradient  (in msec) */
                           float time_decay,  /*<< the 'ramp down' time for the gradient (in msec) */
                           float time_sample_delay, /*<< the time (in msec) between the start of the readout
                                                    gradient and the start of the sampling window */
                           float time_sampling_window /*<< length of time (in msec) the sampling window is 'on' */
                           );


int rank_one_est( COMPLEX *C,   /**< input data */
                  float *mask,
                  int Nx,       /**< number of rows in input data  */
                  int Ny,       /**< number of columns in input data  */
                  double *d,    /**< the largest signular value. (Set to NULL
                                   if undesired) */
                  COMPLEX *u,   /**< the right singular vector associated with
                                   the largest singular value. (Set to NULL if
                                   undesired) */
                  COMPLEX *v,   /**< the left signular vector associated with
                                   the largest singular value. (Set to NULL if
                                   undesired) */
                  int tid       /**< thread id for the Lanczos algorithm code.
                                   Set to zero is not using threads. */
                  );


int compute_svd_complex( COMPLEX *A,
                         int m,
                         int n,
                         int dim,
                         double *d,
                         COMPLEX *u,
                         COMPLEX *v,
                         int thread_id
                         );

void cgsolv( COMPLEX *A,     /**< system matrix, must be complex-conjugate symmetric */
             int n,          /**< length of data vector */
             COMPLEX *b,     /**< objective vector */
             COMPLEX *x,     /**< solution */
             int k_max,      /**< maximum number of iterations */
             double thresh   /**< residual error threshold */
             );

int lsv( COMPLEX *A,            /**< the input matrix. */
         int m,                 /**< number of rows in input matrix. */
         int n,                 /**< number of columns in input matrix.
                                   Note, it is assumed that m>>n
                                 */
         COMPLEX *x0,           /**< the output vector. size: m x 1
                                   (needs to be pre-allocated)
                                 */
         double *sigma,
         COMPLEX *v,
         float thresh           /**< [opt] convergent threshold
                                   (default=1e-4) */
         );

int compute_virtual_body_coil( DATA_OBJ *input,  /**< the input coil sensitivity estimates [x-y-c] or [x-y-z-c] */
                               DATA_OBJ *output,  /**< the output virtual body coil.  If NULL, memory will be allocated. */
                               DATA_OBJ *vbc_parms /**< the returned VBC coil combination parameters, sized [c-z].  */
                               );

int apply_vbc_coefs( DATA_OBJ *input,  /**< the input mulit-coil data, sized [x-y-c] or [x-y-z-c] */
                     DATA_OBJ *output,
                     DATA_OBJ *vbc_parms /**< the VBC coil combination parameters, sized [c-z].  */
                     );

int compute_root_sum_of_squares( DATA_OBJ *input,
                                 DATA_OBJ *output,
                                 double *max
                                 );

void fil_version();

#ifdef __cplusplus
}
#endif

#endif

/*

Copyright 2009, National Center for Image Guided Therapy (NCIGT)

All rights reserved. Licensed according to the terms of a BSD-style
licence covering the Fast Imaging Library
(see http://www.ncigt.org/pages/Downloads "Imaging Toolbox")

*/
