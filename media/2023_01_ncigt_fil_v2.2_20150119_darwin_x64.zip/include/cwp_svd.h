#define size_t int

#if DATAFLAG == FLT
#define DATATYPE float
#else
#define DATATYPE double
#endif

double **alloc2d(size_t n1, size_t n2);
double *alloc1d(size_t n1);

double **alloc2double(size_t n1, size_t n2);
double *alloc1double(size_t n1);

void free2double(double **p);
void free1double(double *p);


void compute_pinv(double **u, double w[], double **v, short n,
                  short m, double **S_inv);

int  compute_svd(double **a, int n, int m, double w[], double **v);
void svd_sort(double **u, double *w, double **v, int m, int n);
void svd_backsubstitute(double **u, double w[], double **v, int n, int m, double b[], double x[]);
