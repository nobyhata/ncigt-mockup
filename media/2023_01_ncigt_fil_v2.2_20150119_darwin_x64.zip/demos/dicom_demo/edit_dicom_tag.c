/*

  An example of how to use the NCIGT Fast Imaging Library to read,
  edit, and write a DICOM file for the purpose of modifying a 
  DICOM tag

  Created Mar 2009, W. Scott Hoge (shoge at bwh dot harvard dot edu)
  
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "igt_fil.h"

#include <getopt.h>

#include <nd_mosaic.c>


typedef struct {
  double re;
  double im;
} dblcmplx;

typedef struct {
  float re;
  float im;
} fltcmplx;

typedef struct {
  short int re;
  short int im;
} intcmplx;

int nd_mag2short ( DATA_OBJ *in_data, DATA_OBJ *outdata, float scale )
{
  int cnt;
  double  mxdbl,mndbl,tdbl;

  dblcmplx *data = NULL;
  double   *data1 = NULL;
  fltcmplx *data2 = NULL;
  float    *data3 = NULL;
  intcmplx *data4 = NULL;
  short int *data5 = NULL;
  unsigned char *data6 = NULL;

  char *dtype = in_data->type;
  int n = 1;

  void *tmpp = in_data->data;
  unsigned short *tmps;
  
  for (cnt=0; cnt< in_data->ndim; cnt++) {
    n *= in_data->sz[cnt];
  }

  outdata->ndim = 2;
  outdata->sz[0] = n;
  outdata->sz[1] = 1;
  strcpy( outdata->type, "intr");
  outdata->data = malloc( n * nd_data_type_size( outdata->type ) );
  outdata->init = n * nd_data_type_size( outdata->type );
  tmps = (unsigned short *) outdata->data;

  tdbl = 0;

  if ( strcmp(dtype,"dblc")==0 ) {
    data =  (dblcmplx *) tmpp;
  } else if ( strcmp(dtype,"dblr")==0 ) {
    data1 = (double *) tmpp;
  } else if ( strcmp(dtype,"fltc")==0 ) {
    data2 = (fltcmplx *) tmpp;
  } else if ( strcmp(dtype,"fltr")==0 ) {
    data3 = (float *) tmpp; 
  } else if ( strcmp(dtype,"intc")==0 ) {
    data4 = (intcmplx *) tmpp;
  } else if ( strcmp(dtype,"intr")==0 ) {
    data5 = (short int *) tmpp;
  } else if ( strcmp(dtype,"char")==0 ) {
    data6 = (unsigned char *) tmpp;
  } else {
    fprintf(stderr,"Error: unknown data type (%s)\n",dtype);
    return(-1);
 }

  /* find the maximum value */
  mxdbl = 0.0; mndbl = 32768.0;
  for( cnt=0; cnt < n; cnt++ ){
    if ( strcmp(dtype,"dblc")==0 ) {
      tdbl = sqrt( data[cnt].re*data[cnt].re + data[cnt].im * data[cnt].im );
    } else if ( strcmp(dtype,"fltc")==0 ) {
      tdbl = sqrt( (double)data2[cnt].re*(double)data2[cnt].re
                   + (double)data2[cnt].im * (double)data2[cnt].im );
    } else if ( strcmp(dtype,"intc")==0 ) {
      tdbl = sqrt( (double)data4[cnt].re*(double)data4[cnt].re
                   + (double)data4[cnt].im * (double)data4[cnt].im );
    } else if ( strcmp(dtype,"dblr")==0 ) {
      tdbl = data1[cnt];
    } else if ( strcmp(dtype,"fltr")==0 ) {
      tdbl = (double)data3[cnt];
    } else if ( strcmp(dtype,"intr")==0 ) {
      tdbl = (double)data5[cnt];
    } else if ( strcmp(dtype,"char")==0 ) {
      tdbl = (double)data6[cnt];
    } else {
      fprintf(stderr,"Error: unknown data type (%s)\n",dtype);
      return(-1);
    }
    mndbl = ( tdbl < mndbl ) ? tdbl : mndbl;
    mxdbl = ( tdbl > mxdbl ) ? tdbl : mxdbl;
  }
  printf("max val = %e  min val = %e\n",mxdbl,mndbl);

  if (scale == 0) {
    scale = (float) (255.0 / (mxdbl-mndbl) );
    printf("autoscale = %e\n", scale );
  }

  for( cnt=0; cnt < n; cnt++ ){

    if ( strcmp(dtype,"dblc")==0 ) {
      tdbl = sqrt( data[cnt].re*data[cnt].re + data[cnt].im * data[cnt].im ) * (double)scale - 1;
    } else if ( strcmp(dtype,"fltc")==0 ) {
      tdbl = sqrt( (double)data2[cnt].re*(double)data2[cnt].re
                    + (double)data2[cnt].im * (double)data2[cnt].im ) * (double) scale - 1;
    } else if ( strcmp(dtype,"intc")==0 ) {
      tdbl = sqrt( (double)data4[cnt].re*(double)data4[cnt].re
                    + (double)data4[cnt].im * (double)data4[cnt].im ) * (double) scale - 1;
    } else if ( strcmp(dtype,"dblr")==0 ) {
      tdbl = ( data1[cnt] - mndbl ) * (double)scale;
    } else if ( strcmp(dtype,"fltr")==0 ) {
      tdbl = ((double)data3[cnt] - mndbl) * (double)scale;
    } else if ( strcmp(dtype,"intr")==0 ) {
      tdbl = ((double)data5[cnt] - mndbl) * (double)scale;
    } else if ( strcmp(dtype,"char")==0 ) {
      tdbl = ((double)data6[cnt] - mndbl) * (double)scale;
    }
    tdbl = (tdbl < 0)? 0 : tdbl;

    // if ( tdbl > mxdbl ) mxdbl = tdbl;
    // if ( tdbl < mndbl ) mndbl = tdbl;

    tmps[cnt] = (unsigned short) tdbl;

  }
  // printf("max tdbl = %e  min tdbl = %e\n",mxdbl,mndbl);  

  return(0);
}



// short get_hdr(char *im_name, int im_hdrsize, char *im_hdr){
// 
//    FILE  *fid;                  /* Pointer to file */
//    int   bytes_r;               /* Number of bytes read */
// 
//    /* Open the image file */
//    if (!(fid = fopen(im_name, "rb"))){ /* read-only, binary mode in win32 */
//       fprintf(stderr, "Error: cannot open image file %s\n", im_name);
//       return(-1);
//    }
//    /* Read the actual header, store in the char array im_hdr, and close file. */
//    bytes_r = fread(im_hdr, 1, im_hdrsize, fid);
//    if (bytes_r != im_hdrsize){
//       fprintf(stderr, "Error reading the image file %s\n", im_name);
//       return(-1);
//    }
//    fclose(fid);
//    return(0);
// }
// 

int main( int argc, char** argv ){
  
  int Nmax_dicom = 1000;       /* maximum number of list tags to consider */
  
  char  *im_hdr;               /* Contains dicom image header data */
  int   im_hdrsize;            /* Size of image header */
  LIST_NODE *dicom_list =NULL; /* List of DICOM entries */
  LIST_NODE dicom_entry;       /* One specific entry from list */

  char  *name_in;
  char  name_out[100];         /* Image name to write to */
  char parm[20];
  char  image_in[100];          /* file to read new image data from */

  DATA_OBJ img, outdata;

  unsigned short rows,cols;
  char val[20];
  int  lngth = 0;
  char *type = NULL, *vr = NULL;

  float scl = 0.0;

  FILE  *fin;                  /* Pointer to file */
  FILE  *fout;                 /* pointer to file */
  int   n;
  char  *tmpb, *endptr;

  unsigned long tag1 = 0x10E0, tag0 = 0x0019;
  int nopt, optind, cnt;
  char *short_options = "o:v:r:p:s:i:h";

  init_data_obj( &img );
  init_data_obj( &outdata );

  memset(name_out,0,100*sizeof(char));
  memset(image_in,0,100*sizeof(char));
  memset(parm,0,20*sizeof(char));
  memset(val,0,20*sizeof(char));


  optind = 0;
  do {
    nopt = getopt(argc, argv, short_options);
    optind++;
    switch (nopt) {
    case 'v':
      tag0 = strtol( argv[++optind], &endptr, 16 );
      break;
    case 'r':
      tag1 = strtol( argv[++optind], &endptr, 16 );
      break;
    case 's':
      scl = strtof( argv[++optind], &endptr );
      break;
    case 'p':
      strcpy( parm, argv[++optind] );
      break;
    case 'o':
      strcpy( name_out, argv[++optind] );
      break;
    case 'i':
      strcpy( image_in, argv[++optind] );
      break;
    case 'h':
      printf(" options: v = tag0, r = tag1, p = parm value, o = output file\n");
      return(0);
    }
  } while ( nopt != -1 );

  if (optind == argc) {
    fprintf(stderr,"Last argument in list needs to be the input filename.\n");
    return(-1);
  }
  name_in = argv[optind];

  /* construct the default output filename */
  if ( name_out[0] == 0 ) {
    (void) sprintf( name_out, "%s%s", "new_", name_in );
  }

  printf( "Inputs:: v: 0x%04x  r: 0x%04x p: %s in: %s out: %s\n",
          tag0, tag1, parm, name_in, name_out );

  dicom_list = (LIST_NODE *) malloc(Nmax_dicom*sizeof(LIST_NODE));
  /* Get a list of all DICOM entries in the header of the image file */
  (void) get_dicom_info(name_in, dicom_list, Nmax_dicom);
  /* Get the size of the header, in bytes. (0x7fe0,0x0010) tags pixel data */
  dicom_entry = find_tag(dicom_list, 0x7fe0, 0x0010);

  im_hdrsize = dicom_entry.offset;  /* offset to data = header size */
  fprintf(stdout, "\tImage header size = %d\n", im_hdrsize);

  // print_list( dicom_list, name_in );

  eval_dicom( dicom_list, 0x0028, 0x0010, name_in, (char*)&rows, "ushort", 2);
  eval_dicom( dicom_list, 0x0028, 0x0011, name_in, (char*)&cols, "ushort", 2);
  printf(" Rows: %d Cols: %d\n",rows,cols);

  if ( image_in[0] != 0 ) {
    read_nd_data2( image_in, &img );
    printf(" image_in: %s [", img.type);
    for (cnt=0; cnt<img.ndim; cnt++) {
      printf(" %d",img.sz[cnt]);
    }
    printf(" ]\n");
    
    nd_mosaic_all_slices( &img );
    printf(" image_in mosaic: %s [", img.type);
    for (cnt=0; cnt<img.ndim; cnt++) {
      printf(" %d",img.sz[cnt]);
    }
    printf(" ]\n");

  }

  /* ** fetch the current requested field ** */
  
  /* first, confirm the tag exists and fetch its properties */
  dicom_entry = find_tag( dicom_list, tag0, tag1 );
  vr = dicom_entry.vr;
  if ( ((vr[0] == 'U') && (vr[1] == 'T')) ||
       ((vr[0] == 'U') && (vr[1] == 'N')) ||
       ((vr[0] == 'U') && (vr[1] == 'I')) ||
       ((vr[0] == 'T') && (vr[1] == 'M')) ||
       ((vr[0] == 'P') && (vr[1] == 'N')) ||
       ((vr[0] == 'O') && (vr[1] == 'W')) ||
       ((vr[0] == 'O') && (vr[1] == 'F')) ||
       ((vr[0] == 'O') && (vr[1] == 'B')) ||
       ((vr[0] == 'L') && (vr[1] == 'T')) ||
       ((vr[0] == 'L') && (vr[1] == 'O')) ||
       ((vr[0] == 'I') && (vr[1] == 'S')) ||
       ((vr[0] == 'D') && (vr[1] == 'T')) ||
       ((vr[0] == 'D') && (vr[1] == 'S')) ||
       ((vr[0] == 'D') && (vr[1] == 'A')) ||
       ((vr[0] == 'C') && (vr[1] == 'S')) ||
       ((vr[0] == 'A') && (vr[1] == 'T')) ||
       ((vr[0] == 'A') && (vr[1] == 'S')) ||
       ((vr[0] == 'A') && (vr[1] == 'E')) ||
       ((vr[0] == 'S') && (vr[1] == 'H')) ) {
    type = "char";
  } else if (((vr[0] == 'F') && (vr[1] == 'L'))){
    type = "float";
  } else if (((vr[0] == 'F') && (vr[1] == 'D'))){
    type = "double";
  } else if (((vr[0] == 'S') && (vr[1] == 'L'))){
    type = "long";
  } else if (((vr[0] == 'U') && (vr[1] == 'L'))){
    type = "ulong";
  } else if (((vr[0] == 'S') && (vr[1] == 'S'))){
    type = "short";
  } else if (((vr[0] == 'U') && (vr[1] == 'S'))){
    type = "ushort";
  } else {
    printf("The requested DICOM field format is not recognized,\n"
          "so the process will exit now.");
    return(-1);
  }
  lngth = dicom_entry.length;

  /* next, get the field value */
  eval_dicom( dicom_list, tag0, tag1, name_in, val, type, lngth);
  printf("Cur Val: %s\n",val);

  /* Read the entire dicom header data, and store it in the char array
     im_hdr. As the header gets modified, it may get longer, so an extra 100
     bytes are allocated, just in case. */
  im_hdr = (char *) malloc((im_hdrsize+100)*sizeof(char));
  get_hdr(name_in, im_hdrsize, im_hdr);

  fin = fopen(name_in,"r+b");
  fseek(fin,0,SEEK_END);
  n = ftell(fin) - im_hdrsize;

  tmpb = (char *)malloc(n*sizeof(char));

  fseek(fin,im_hdrsize,SEEK_SET);
  fread(tmpb,n,sizeof(char),fin);
  fclose(fin);
  

  // sprintf(val,"%f",(float)272);
  /* last, replace the parameter in the list with the new value */
  printf("val in: %s\n", parm);
  edit_dicom( dicom_list, tag0, tag1, name_in, im_hdr, &im_hdrsize, 
              parm, lngth );

  /* Open the file */
  if (!(fout = fopen(name_out,"w+b"))){
    fprintf(stderr, "Error: cannot open image file %s\n",
            name_out);
    return(-1);
  }
  /* Write the header data */
  if (fwrite((char *) im_hdr, im_hdrsize*sizeof(char), 1, fout)!=1) {
    (void) fprintf(stderr,"Error: file write failed on %s\n",
                   name_out);
    (void) fclose(fout);
    return(-1);
  }
  
  /*
   * copy the image data, 
   */
  if ( image_in[0] == 0 ) {
    /* if no image data is specified, then just copy the data from the input file */
    if (fwrite((char *) tmpb, n, sizeof(char),fout)!=1) {
      (void) fprintf(stderr,"Error: file write failed on %s\n",
                     name_out);
      (void) fclose(fout);
      return(-1);
    }
  } else {
    rot_and_flip_data_obj( -1, 1, 0, &img );

    nd_mag2short( &img, &outdata, scl );
    if (fwrite((char *) outdata.data, n, sizeof(char),fout)!=1) {
      (void) fprintf(stderr,"Error: file write failed on %s\n",
                     name_out);
      (void) fclose(fout);
      return(-1);
    }
  }
  (void) fclose(fout);

  /* confirm the change */
  (void) get_dicom_info( name_out, dicom_list, Nmax_dicom );
  eval_dicom( dicom_list, tag0, tag1, name_out, val, "char", 8);
  printf("New val: %f\n",atof(val));

  // print_list( dicom_list, name_out );
  free(tmpb);
  free(im_hdr);
  free(dicom_list);

  return(0);
}

