typedef struct {
  double re;
  double im;
} dblcmplx;

typedef struct {
  float re;
  float im;
} fltcmplx;

typedef struct {
  short int re;
  short int im;
} intcmplx;

int nd_phase2rgb ( char *dtype, void *tmpp, unsigned char *RGBdata, int n);
int nd_mag2rgb ( char *dtype, void *tmpp, unsigned char *RGBdata, int n, float scale );
