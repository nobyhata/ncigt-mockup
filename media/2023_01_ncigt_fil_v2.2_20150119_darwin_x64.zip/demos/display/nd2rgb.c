#include "math.h"
#include "stdio.h"
#include "string.h"

#include "goptable.h"

#include "nd2rgb.h"

#ifndef M_PI
#define M_PI 3.141592654
#endif

int nd_phase2rgb ( char *dtype, void *tmpp, unsigned char *RGBdata, int n) // , int table )
{
  int cnt;
  double  tdbl;

  dblcmplx *data = NULL;
  double   *data1 = NULL;
  fltcmplx *data2 = NULL;
  float    *data3 = NULL;
  intcmplx *data4 = NULL;
  short int *data5 = NULL;

  if ( strcmp(dtype,"dblc")==0 ) {
    data =  (dblcmplx *) tmpp;
  } else if ( strcmp(dtype,"dblr")==0 ) {
    data1 = (double *) tmpp;
  } else if ( strcmp(dtype,"fltc")==0 ) {
    data2 = (fltcmplx *) tmpp;
  } else if ( strcmp(dtype,"fltr")==0 ) {
    data3 = (float *) tmpp;
  } else if ( strcmp(dtype,"intc")==0 ) {
    data4 = (intcmplx *) tmpp;
  } else if ( strcmp(dtype,"intr")==0 ) {
    data5 = (short int *) tmpp;
  } else {
    fprintf(stderr,"Error: unknown data type (%s)\n",dtype);
    return(-1);
  }

  /* compute the image phase */
  for( cnt=0; cnt < n; cnt++ ){

    if ( strcmp(dtype,"dblc")==0 ) {
      tdbl = ( atan2( data[cnt].im, data[cnt].re ) + M_PI ) * 128 / M_PI;

    } else if ( strcmp(dtype,"fltc")==0 ) {
      tdbl = (double)( atan2( (double)data2[cnt].im, (double)data2[cnt].re ) + M_PI ) * 128 / M_PI;

    } else if ( strcmp(dtype,"intc")==0 ) {
      tdbl = (double)( atan2( (double)data4[cnt].im, (double)data4[cnt].re ) + M_PI ) * 128 / M_PI;

    } else if ( strcmp(dtype,"dblr")==0 ) {
      tdbl = 0;
    } else if ( strcmp(dtype,"fltr")==0 ) {
      tdbl = 0;
    } else if ( strcmp(dtype,"intr")==0 ) {
      tdbl = 0;
    } else {
      fprintf(stderr,"Error: unknown data type (%s)\n",dtype);
      return(-1);
    }
    tdbl = (tdbl < 0)? 0 : tdbl;
    tdbl = (tdbl > 255)? 255 : tdbl;

    RGBdata[3*(cnt)+0] = (unsigned char) GOPTAB[(short)tdbl][0];
    RGBdata[3*(cnt)+1] = (unsigned char) GOPTAB[(short)tdbl][1];
    RGBdata[3*(cnt)+2] = (unsigned char) GOPTAB[(short)tdbl][2];

  }
  return(0);
}

int nd_mag2rgb ( char *dtype, void *tmpp, unsigned char *RGBdata, int n, float scale )
{
  int cnt;
  double  mxdbl,mndbl,tdbl;

  dblcmplx *data = NULL;
  double   *data1 = NULL;
  fltcmplx *data2 = NULL;
  float    *data3 = NULL;
  intcmplx *data4 = NULL;
  short int *data5 = NULL;
  unsigned char *data6 = NULL;

  tdbl = 0;

  if ( strcmp(dtype,"dblc")==0 ) {
    data =  (dblcmplx *) tmpp;
  } else if ( strcmp(dtype,"dblr")==0 ) {
    data1 = (double *) tmpp;
  } else if ( strcmp(dtype,"fltc")==0 ) {
    data2 = (fltcmplx *) tmpp;
  } else if ( strcmp(dtype,"fltr")==0 ) {
    data3 = (float *) tmpp; 
  } else if ( strcmp(dtype,"intc")==0 ) {
    data4 = (intcmplx *) tmpp;
  } else if ( strcmp(dtype,"intr")==0 ) {
    data5 = (short int *) tmpp;
  } else if ( strcmp(dtype,"char")==0 ) {
    data6 = (unsigned char *) tmpp;
  } else {
    fprintf(stderr,"Error: unknown data type (%s)\n",dtype);
    return(-1);
 }

  /* find the maximum value */
  mxdbl = 0.0; mndbl = 255.0;
  for( cnt=0; cnt < n; cnt++ ){
    if ( strcmp(dtype,"dblc")==0 ) {
      tdbl = sqrt( data[cnt].re*data[cnt].re + data[cnt].im * data[cnt].im );
    } else if ( strcmp(dtype,"fltc")==0 ) {
      tdbl = sqrt( (double)data2[cnt].re*(double)data2[cnt].re
                   + (double)data2[cnt].im * (double)data2[cnt].im );
    } else if ( strcmp(dtype,"intc")==0 ) {
      tdbl = sqrt( (double)data4[cnt].re*(double)data4[cnt].re
                   + (double)data4[cnt].im * (double)data4[cnt].im );
    } else if ( strcmp(dtype,"dblr")==0 ) {
      tdbl = data1[cnt];
    } else if ( strcmp(dtype,"fltr")==0 ) {
      tdbl = (double)data3[cnt];
    } else if ( strcmp(dtype,"intr")==0 ) {
      tdbl = (double)data5[cnt];
    } else if ( strcmp(dtype,"char")==0 ) {
      tdbl = (double)data6[cnt];
    } else {
      fprintf(stderr,"Error: unknown data type (%s)\n",dtype);
      return(-1);
    }
    mndbl = ( tdbl < mndbl ) ? tdbl : mndbl;
    mxdbl = ( tdbl > mxdbl ) ? tdbl : mxdbl;
  }
  printf("max val = %e  min val = %e\n",mxdbl,mndbl);

  if (scale == 0) {
    scale = (float) (255.0 / (mxdbl-mndbl) );
    printf("autoscale = %e\n", scale );
  }

  for( cnt=0; cnt < n; cnt++ ){

    if ( strcmp(dtype,"dblc")==0 ) {
      tdbl = sqrt( data[cnt].re*data[cnt].re + data[cnt].im * data[cnt].im ) * (double)scale - 1;
    } else if ( strcmp(dtype,"fltc")==0 ) {
      tdbl = sqrt( (double)data2[cnt].re*(double)data2[cnt].re
                    + (double)data2[cnt].im * (double)data2[cnt].im ) * (double) scale - 1;
    } else if ( strcmp(dtype,"intc")==0 ) {
      tdbl = sqrt( (double)data4[cnt].re*(double)data4[cnt].re
                    + (double)data4[cnt].im * (double)data4[cnt].im ) * (double) scale - 1;
    } else if ( strcmp(dtype,"dblr")==0 ) {
      tdbl = ( data1[cnt] - mndbl ) * (double)scale;
    } else if ( strcmp(dtype,"fltr")==0 ) {
      tdbl = ((double)data3[cnt] - mndbl) * (double)scale;
    } else if ( strcmp(dtype,"intr")==0 ) {
      tdbl = ((double)data5[cnt] - mndbl) * (double)scale;
    } else if ( strcmp(dtype,"char")==0 ) {
      tdbl = ((double)data6[cnt] - mndbl) * (double)scale;
    }
    tdbl = (tdbl < 0)? 0 : tdbl;

    // if ( tdbl > mxdbl ) mxdbl = tdbl;
    // if ( tdbl < mndbl ) mndbl = tdbl;

    RGBdata[3*(cnt)+0] = (unsigned char) tdbl;
    RGBdata[3*(cnt)+1] = (unsigned char) tdbl;
    RGBdata[3*(cnt)+2] = (unsigned char) tdbl;

  }
  // printf("max tdbl = %e  min tdbl = %e\n",mxdbl,mndbl);  

  return(0);
}
