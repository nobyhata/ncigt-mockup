/*

  A set of wrapper functions to convert N-dimensional data into an RGB format
  and display the data in an Xwindow using the ImLib library.

  This code draws liberally from the example included with ImLib.

  Created Jun 2008, W. Scott Hoge (shoge at bwh dot harvard dot edu)

  Updated to use imshow.h in Feb 2009,  W. Scott Hoge

 */

#include <igt_fil.h>
#include <imshow.h>

#include "nd2rgb.h"

// #define SHOW_TIMING

#ifdef SHOW_TIMING
#include <sys/time.h>
#endif

void usage( char *pname ){
  printf("%s:\n\t show contents of .nd files in an X window\n",pname);
  printf("Usage:\n\t %s [ -p <or> -s f ] image_file\n",pname);
  printf("Options:\n"
         "\t -p   : show signal/image phase"
         " (magnitude shown by default)\n"
         "\t -s f : give a floating point number to fix the scaling for all images.\n"
         "\t        (scaling is determined automatically by default).\n");
  printf(" \t -m   : mosaic mode.  combines data in third dimension to display all slices in a single mage.\n");
  printf("\n\ncompiled using "); fflush(stdout);
  fil_version();
  exit(1);
}

#include "nd_mosaic.c"

int main(int argc, char **argv)
{
  char *tmpp;
  int   n, sz[4]={1,1,1,1},dsz;
  char  dtype[5] = {0,0,0,0,0};
  int   cnt,cnt2,cntF,nfrm=1,indx=1;
  int   phase_mode=0;
  int   mosaic_mode=0;
  float scale=0;

  DATA_OBJ ndobj;

  char ttl[20];
  char *RGBdata;
  ImLibParms imlib;

#ifdef SHOW_TIMING
  struct timeval tv;
  struct timezone tz;
  double prevtime;
  double tmptime;
#endif

  int nopt, optind;
  char *short_options = "s:b:vpm";

  if (argc<=1) {
    usage(argv[0]);
  }

  optind = 1;
  while ( (nopt=getopt(argc, argv, short_options)) != -1) {

    optind++;
    switch (nopt) {
    case 'p':
      phase_mode = 1;           /* output phase images instead of magnitude */
      break;
    case 'm':
      mosaic_mode = 1;           /* output all slices as a single image */
      break;
    case 's':
      scale = (float) atof(argv[optind++]);
      break;
    case 'h':
    default:
      usage(argv[0]);
    }
  }

  /* initialize the ImLib display handles */
  imlib_init( &imlib );

#ifdef SHOW_TIMING
  gettimeofday(&tv,&tz);
  prevtime = tv.tv_sec*1000+tv.tv_usec/1000;
#endif

  init_data_obj( &ndobj );

  /* Load the data specified in the argument list */
  for ( cntF=optind;cntF<argc;cntF++) {
    // if (read_nd_data( argv[cntF], &tmpp, dtype, &n, sz ) != 0) {
    if (read_nd_data2( argv[cntF], &ndobj ) ) {
      fprintf(stderr,"Data read from %s failed. Exiting.\n",argv[cntF]);
      return(-1);
    }

    dsz = nd_data_type_size( ndobj.type );
    if (dsz < 0) {
      fprintf(stderr,".nd data format (%d) not recognized. exiting now.\n", ndobj.type);
      return(-1);
    }

    printf("read_nd_data read an %s %d-dimensional array of size", ndobj.type,ndobj.ndim);
    if (mosaic_mode) {
      nd_mosaic_all_slices( &ndobj );
      // sprintf(ttl,"%s_mosaic",argv[cntF]);
      // write_nd_data2(ttl,&ndobj);
      printf(" (after converting to mosaic) ");
    }

    nfrm =1;
    for ( cnt=0; cnt< ndobj.ndim; cnt++ ) {
      printf(" %d", ndobj.sz[cnt]);
      if(cnt>1)
        nfrm=nfrm*ndobj.sz[cnt];
    }
    printf(" from %s.\n",argv[cntF]);


    RGBdata = (char *) malloc( ndobj.sz[0]*ndobj.sz[1]*3*sizeof(char) );

    tmpp = (char *) ndobj.data;
    for (cnt2=0;cnt2<nfrm;cnt2++) {

      /* convert the data into a format suitable for display */
      if (phase_mode) {
        nd_phase2rgb( ndobj.type, tmpp + (ndobj.sz[0]*ndobj.sz[1]*cnt2*dsz), RGBdata, ndobj.sz[0]*ndobj.sz[1] );
      } else {
        nd_mag2rgb( ndobj.type, tmpp + (ndobj.sz[0]*ndobj.sz[1]*cnt2*dsz), RGBdata, ndobj.sz[0]*ndobj.sz[1], scale );
      }

      /* send the data off for visualization */
      sprintf( ttl, "%19s", argv[cntF] );
      imlib_display( &imlib, RGBdata, ndobj.sz, 2, ttl );

      printf(".");fflush(stdout);
      sleep(1);
    }

    free(RGBdata);
    // free(tmpp);
    free_data_obj( &ndobj );
    printf("Done.\n");
  }

#ifdef SHOW_TIMING
      gettimeofday(&tv,&tz);
      tmptime = tv.tv_sec*1000+tv.tv_usec/1000;
      printf("  total elapsed time: %f sec\n",(tmptime-prevtime)/1000 );
      prevtime=tmptime;
#endif


}
