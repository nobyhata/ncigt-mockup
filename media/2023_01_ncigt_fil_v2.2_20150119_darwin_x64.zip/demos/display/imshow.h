/*

  A set of wrapper functions to convert N-dimensional data into an RGB format
  and display the data in an Xwindow using the ImLib library.

  Created Feb 2009, W. Scott Hoge (shoge at bwh dot harvard dot edu)
  
 */

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/extensions/shape.h>
#include <Imlib.h>

#include <math.h>

typedef struct{
  Display *disp;
  XSetWindowAttributes attr;
  Window win;
  ImlibData *id;
  ImlibImage *im;
  Pixmap p;
  Pixmap m;
} ImLibParms;

void imlib_init( ImLibParms *parm );
void imlib_display( ImLibParms *parms, char *RGBdata, int *sz, int scale, char *ttl );
