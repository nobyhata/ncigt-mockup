#include <stdio.h>
#include <stdlib.h>
#include <wand/MagickWand.h>

#include <math.h>
#include <igt_fil.h>

typedef struct {
  double re;
  double im;
} dblcmplx;

typedef struct {
  float re;
  float im;
} fltcmplx;

/*
void apply_2dfft( fil_fft_mngr *mngr, char *dtype, int *sz, char* data, char dir )
{
  COMPLEX* cdata;
  int M,N;
  int cnt;
  int sz2[2];
  int dsz;
  COMPLEX* pntr;

  M=sz[0]; N=sz[1];
  cdata = (COMPLEX *) calloc( M*N, sizeof(COMPLEX) );
  
  if ( strcmp(dtype,"dblc")==0 ) {
    dsz = 2*sizeof(double);
  } else if ( strcmp(dtype,"dblr")==0 ) {
    dsz = sizeof(double);
  } else if ( strcmp(dtype,"fltc")==0 ) {
    dsz = 2*sizeof(float);
  } else if ( strcmp(dtype,"fltr")==0 ) {
    dsz = sizeof(float);
  }

  for (cnt=0; cnt<M*N; cnt++) {
    pntr = (COMPLEX*)(data + (2*cnt+0)*dsz);

    cdata[cnt].re = (double) pntr[0];
    cdata[cnt].im = (double) pntr[1];
  }

  fil_2dfft( mngr, M, N, cdata, 'b' );
  
  sz[0] = M; sz[1] = N;
  write_nd_data( "fftout.nd", (void*)cdata, "dblc", 2, sz2 );

  free(cdata);
  
}
*/

void map_nd_to_flt ( void *tmpp, float *pixdat, char *dtype, int n )
{
  int cnt;
  double  mxdbl,mndbl,tdbl;

  dblcmplx *data;
  double   *data1;
  fltcmplx *data2;
  float    *data3;

#define MAXVAL 1

  if ( strcmp(dtype,"dblc")==0 ) {
    data =  (dblcmplx *) tmpp;
  } else if ( strcmp(dtype,"dblr")==0 ) {
    data1 = (double *) tmpp;
  } else if ( strcmp(dtype,"fltc")==0 ) {
    data2 = (fltcmplx *) tmpp;
  } else if ( strcmp(dtype,"fltr")==0 ) {
    data3 = (float *) tmpp;
  }
  
  /* find the maximum value */
  mxdbl = 0; mndbl=1e8;
  for( cnt=0; cnt < n; cnt++ ){
    if ( strcmp(dtype,"dblc")==0 ) {
      tdbl = sqrt( data[cnt].re*data[cnt].re + data[cnt].im * data[cnt].im );
    } else if ( strcmp(dtype,"fltc")==0 ) {
      tdbl = sqrt( (double)data2[cnt].re*(double)data2[cnt].re 
                   + (double)data2[cnt].im * (double)data2[cnt].im );
    } else if ( strcmp(dtype,"dblr")==0 ) {
      tdbl = data1[cnt];
      mndbl = ( tdbl < mndbl ) ? tdbl : mndbl;
    } else if ( strcmp(dtype,"fltr")==0 ) {
      tdbl = (double)data3[cnt];
    }
    mndbl = ( tdbl < mndbl ) ? tdbl : mndbl;
    mxdbl = ( tdbl > mxdbl ) ? tdbl : mxdbl;
  }
  // printf("max val = %e, min val = %e\n",mxdbl,mndbl);
  
  for( cnt=0; cnt < n; cnt++ ){
    
    if ( strcmp(dtype,"dblc")==0 ) {
      tdbl = (sqrt( fabs(data[cnt].re*data[cnt].re) + fabs(data[cnt].im * data[cnt].im) ) * MAXVAL) / mxdbl;
    } else if ( strcmp(dtype,"fltc")==0 ) {
      tdbl = (sqrt( (double)( data2[cnt].re*data2[cnt].re) 
                    + data2[cnt].im*data2[cnt].im) ) * MAXVAL / mxdbl;
    } else if ( strcmp(dtype,"dblr")==0 ) {
      tdbl = ( data1[cnt] - mndbl ) * MAXVAL / (mxdbl-mndbl);
    } else if ( strcmp(dtype,"fltr")==0 ) {
      tdbl = ((double)data3[cnt] - mndbl) * MAXVAL / (mxdbl-mndbl);
    }
    tdbl = (tdbl < 0)? 0 : tdbl;
    
    pixdat[cnt] = (float) (tdbl);
  }
}

void ThrowWandException(MagickWand *wand) 
{ 
  char *description;

  ExceptionType 
    severity; 

  description=MagickGetException(wand,&severity); 
  (void) fprintf(stderr,"%s %s %lu %s\n",GetMagickModule(),description); 
  description=(char *) MagickRelinquishMemory(description); 
  exit(-1); 
}

/*
MagickDisplayImage() requires an X Window server.  For Windows, try
using MagickWriteImage() with a filename of win:.  Note, the colon is
part of the filename.
*/


int main(int argc,char **argv)
{

  char *tmpp, *pntr;
  int   n, sz[4]={1,1,1,1};
  char  dtype[5] = {0,0,0,0,0};
  int   cnt,cntF,dsz,nfrm=1;

  float *pixdat;

  MagickBooleanType status;

  MagickWand *magick_wand;

  fil_fft_mngr mngr;

  if (argc != 3)
    {
      (void) fprintf(stdout,"Usage: %s ND-data-file output_image\n",argv[0]);
      exit(0);
    }
  /*
    Read an image.
  */


  /* Load the data specified in the argument list */
  //  for ( cntF=1;cntF<argc;cntF++) {

  cntF=1;

    if (read_nd_data( argv[cntF], &tmpp, dtype, &n, sz ) != 0) {
      fprintf(stderr,"Data read from %s failed. Exiting.\n",argv[cntF]);
      return(-1);
    }
    
    if ( strcmp(dtype,"dblc")==0 ) {
      dsz = 2*sizeof(double);
    } else if ( strcmp(dtype,"dblr")==0 ) {
      dsz = sizeof(double);
    } else if ( strcmp(dtype,"fltc")==0 ) {
      dsz = 2*sizeof(float);
    } else if ( strcmp(dtype,"fltr")==0 ) {
      dsz = sizeof(float);
    }

    printf("read_nd_data read an %s %d-dimensional array of size",dtype,n);
    nfrm =1;
    for ( cnt=0; cnt<n; cnt++ ) { 
      printf(" %d",sz[cnt]); 
      if(cnt>1)
        nfrm=nfrm*sz[cnt];
    }
    printf(" from %s.\n",argv[cntF]);

    pixdat = (float*) calloc( sz[0]*sz[1], sizeof(float) );

    MagickWandGenesis();
    magick_wand=NewMagickWand();  

    fft_mngr_init( &mngr );
      
    for (cnt=0;cnt<nfrm;cnt++) {

      pntr = tmpp+sz[0]*sz[1]*cnt*dsz;

      map_nd_to_flt( pntr, pixdat, dtype, sz[0]*sz[1] );

      /* write_nd_data( "test.nd", (void *)pixdat, "fltr", 2, sz ); */

      status = MagickConstituteImage( magick_wand,
                                      (unsigned long)(sz[0]), (unsigned long)(sz[1]), 
                                    "I", FloatPixel, (void *)pixdat );
      
      status = MagickTransposeImage(magick_wand);
      
      
    }
    free(pixdat);

    MagickDisplayImages( magick_wand, ":0.0" ); 
    
    status = MagickWriteImages(magick_wand,"test_%03d.jpg",MagickTrue);

    if (status == MagickFalse)
      ThrowWandException(magick_wand);
    magick_wand = DestroyMagickWand(magick_wand);

    MagickWandTerminus();

    fft_mngr_quit( &mngr );
    
    return(0);
}

