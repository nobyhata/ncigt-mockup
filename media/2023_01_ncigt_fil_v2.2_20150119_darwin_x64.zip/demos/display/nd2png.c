/* derived from makePNG.c, http://www.labbookpages.co.uk/software/imgProc/libPNG.html */

/* To build: gcc -lm -lpng -o makePNG makePNG.c
   Usage:    ./makePNG output.png
*/

#include <stdio.h>
#include <math.h>
#include <malloc.h>
#include <png.h>

#include "stdlib.h"
#include "math.h"

#include "nd_data.h"

#include "nd2rgb.h"

// This function actually writes out the PNG image file. The string 'title' is
// also written into the image file as a comment
int outputPNGimage(char* filename, int width, int height, char *buffer, char* title);

#include "nd_mosaic.c"

int main(int argc, char *argv[])
{
  int cnt,cnt2,nfrm,dsz;

  DATA_OBJ ndobj;

  char fname[60];
  char comment[64];
  char *basename = "img_";
  int  width,height,result;
  float scale=0;
  int  phase_mode=0;
  int  mosaic_mode=0;

  char *RGBdata = NULL;

  int nopt, optind;
  char *short_options = "s:b:vpm";

  optind = 1;
  while ( (nopt=getopt(argc, argv, short_options)) != -1) {

    optind++;
    switch (nopt) {
    case 'b':
      basename = argv[optind++];
      break;
    case 'p':
      phase_mode = 1;           /* output phase images instead of magnitude */
      break;
    case 'm':
      mosaic_mode = 1;           /* output all slices as a single image */
      break;
    case 's':
      scale = (float) atof(argv[optind++]);
      break;
    case 'h':
    default:
      printf("\n Usage: %s [options] <list of input .nd files>\n\n",argv[0]);
      printf(" \t -b s : string to set the basename of output .png files \n");
      printf(" \t -m   : mosaic mode.  combines data in third dimension to display all slices in a single mage.\n");
      printf("\n\ncompiled using "); fflush(stdout);
      fil_version();
      printf("\n");
      return(0);
    }
  }

  init_data_obj( &ndobj );
  for (cnt=optind; cnt<argc; cnt++) {

    printf("reading data from %s\n",argv[cnt]);
    read_nd_data2( argv[cnt], &ndobj );

    if (mosaic_mode) {
      nd_mosaic_all_slices( &ndobj );
      sprintf(fname,"%s_mosaic",argv[cnt]);
      write_nd_data2(fname,&ndobj);
    }

    nfrm =1;
    printf("\t data is sized: ");
    for (cnt2=0;cnt2<ndobj.ndim;cnt2++) {
      printf(" %d ", ndobj.sz[cnt2]);
      if (cnt2<(ndobj.ndim-1))
        printf("x");
      if(cnt2>1)
        nfrm = nfrm * ndobj.sz[cnt2];
    }
    printf("  [%s]\n",ndobj.type);

    dsz = nd_data_type_size( ndobj.type );

    RGBdata = (char *) malloc( ndobj.sz[0]*ndobj.sz[1]*3*sizeof(char) );

    for (cnt2=0;cnt2<nfrm;cnt2++) {

      /* convert the data into a format suitable for display */
      if (phase_mode) {
        nd_phase2rgb( ndobj.type, ndobj.data + (ndobj.sz[0]*ndobj.sz[1]*cnt2*dsz), RGBdata, ndobj.sz[0]*ndobj.sz[1] );
      } else {
        nd_mag2rgb( ndobj.type, ndobj.data + (ndobj.sz[0]*ndobj.sz[1]*cnt2*dsz), RGBdata, ndobj.sz[0]*ndobj.sz[1], scale );
      }

      width  = ndobj.sz[0];
      height = ndobj.sz[1];

      // Save the image to a PNG file
      sprintf(fname,"%s_%03d.png",argv[cnt],cnt2);
      // The 'comment' string is stored as comment in the PNG file
      sprintf(comment,"%s frame num: %d",argv[cnt],cnt2);
      result = outputPNGimage(fname, width, height, RGBdata, comment );
      if (result!=0){
        printf("Error writing PNG file\n",result);
        exit(-1);
      }

    }

    // if (ndobj.data != NULL) { free( ndobj.data ); }
  }
  // Free up the memorty used to store the image
  if (RGBdata != NULL) { free(RGBdata);}

  free_data_obj( &ndobj );

  return result;
}

int outputPNGimage(char* filename, int width, int height, char *buffer, char* title)
{
	int code = 0;
	FILE *fp;
	png_structp png_ptr;
	png_infop info_ptr;
	png_bytep row = NULL;

	int y;

        // printf("width: %d height: %d\n",width,height);

	// Open file for writing (binary mode)
	fp = fopen(filename, "wb");
	if (fp == NULL) {
		fprintf(stderr, "Could not open file %s for writing\n", filename);
		code = 1;
		goto finalise;
	}

	// Initialize write structure
	png_ptr = png_create_write_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
	if (png_ptr == NULL) {
		fprintf(stderr, "Could not allocate write struct\n");
		code = 1;
		goto finalise;
	}

	// Initialize info structure
	info_ptr = png_create_info_struct(png_ptr);
	if (info_ptr == NULL) {
		fprintf(stderr, "Could not allocate info struct\n");
		code = 1;
		goto finalise;
	}

	// Setup Exception handling
	if (setjmp(png_jmpbuf(png_ptr))) {
		fprintf(stderr, "Error during png creation\n");
		code = 1;
		goto finalise;
	}

	png_init_io(png_ptr, fp);

	// Write header (8 bit colour depth)
	png_set_IHDR(png_ptr, info_ptr, width, height,
			8, PNG_COLOR_TYPE_RGB, PNG_INTERLACE_NONE,
			PNG_COMPRESSION_TYPE_BASE, PNG_FILTER_TYPE_BASE);

	// Set title
	if (title != NULL) {
		png_text title_text;
		title_text.compression = PNG_TEXT_COMPRESSION_NONE;
		title_text.key = "Comment";
		title_text.text = title;
		png_set_text(png_ptr, info_ptr, &title_text, 1);
	}

	png_write_info(png_ptr, info_ptr);

	// Write image data
	for (y=0 ; y<height ; y++) {
          row = buffer + y*width*3;
          png_write_row(png_ptr, row);
	}

	// End write
	png_write_end(png_ptr, NULL);

	finalise:
	if (fp != NULL) fclose(fp);
	if (info_ptr != NULL) {
          png_free_data(png_ptr, info_ptr, PNG_FREE_ALL, -1);
          free(info_ptr);
        }
	if (png_ptr != NULL) {
          png_destroy_write_struct(&png_ptr, (png_infopp)NULL);
          free(png_ptr);
        }

	return code;
}

