/*

  A set of wrapper functions to convert N-dimensional data into an RGB format
  and display the data in an Xwindow using the ImLib library.

  This code draws liberally from the example included with ImLib.

  Created Feb 2009, W. Scott Hoge (shoge at bwh dot harvard dot edu)

 */

#include "imshow.h"

#ifdef _32b_
void imlib_init( ImLibParms *parm ) {
  /* Connect to the default Xserver */
  parm->disp=XOpenDisplay(NULL);
   /* Immediately afterwards Intitialise Imlib */
  parm->id=Imlib_init(parm->disp);
  parm->win=0;
}
#else
void imlib_init( ImLibParms *parm ) {

  ImlibInitParams par;

  par.flags = ( PARAMS_REMAP | PARAMS_VISUALID | PARAMS_SHAREDMEM | PARAMS_SHAREDPIXMAPS |
                 PARAMS_FASTRENDER | PARAMS_HIQUALITY | PARAMS_DITHER |
                 PARAMS_IMAGECACHESIZE | PARAMS_PIXMAPCACHESIZE );

  // Visual* defaultvis = DefaultVisual( getX11Display(), x11Info().screen());

  par.paletteoverride = 0;
  par.remap           = 0;
  par.fastrender      = 0;
  par.hiquality       = 0;
  par.dither          = 0;
  par.sharedmem       = 1;
  par.sharedpixmaps   = 1;
  // par.visualid        = defaultvis->visualid;
  uint maxcache       = 0; // idata->maxCache;

  // 0 == no cache                                                                                                                      
  par.imagecachesize  = maxcache * 1024;
  par.pixmapcachesize = maxcache * 1024;



  /* Connect to the default Xserver */
  parm->disp=XOpenDisplay(NULL);
  /* Immediately afterwards Intitialise Imlib */
  // parm->id=Imlib_init(parm->disp);
  parm->id=Imlib_init_with_params(parm->disp,&par);

  parm->win=0;
}
#endif

void imlib_display( ImLibParms *parms, char *RGBdata, int *sz, int scale, char *ttl ) {

  int h,w;
  XSetWindowAttributes attr;
  Pixmap p=0,m=0;

  int blk;

  if (parms->disp == NULL) {
    fprintf(stderr,"ImLib display window is not defined.  Exiting.\n");
    return;
  }
  parms->im = Imlib_create_image_from_data( parms->id, RGBdata, NULL, sz[0], sz[1] );

  h=scale*sz[0];
  w=scale*sz[1];

  Imlib_rotate_image(parms->id, parms->im, 0);

  /* Create a Window to display in */
  if (parms->win == 0) {
    

    /*
    parms->win=XCreateWindow( parms->disp,
                              DefaultRootWindow(parms->disp),
                              0,0,
                              w,h,
                              0,
                              parms->id->x.depth,
                              CopyFromParent,
                              parms->id->x.visual,
                              0,
                              &attr );
    */
    
    blk = BlackPixel( parms->disp, DefaultScreen(parms->disp ) );
    parms->win=XCreateSimpleWindow( parms->disp, DefaultRootWindow(parms->disp),
                                    0,0,
                                    w,h,
                                    0,
                                    blk, blk );

    // XSelectInput( parms->disp, parms->win, ButtonPressMask|StructureNotifyMask );

    /* Render the original 24-bit Image data into a pixmap of size w * h */
    if ( !Imlib_render(parms->id,parms->im,w,h) ) {
      fprintf(stderr,"Imlib rendering error\n");
      exit(127);
    }

    if (p!=0)
      Imlib_free_pixmap(parms->id,p);

    /* Extract the Image and mask pixmaps from the Image */
    p=Imlib_move_image(parms->id,parms->im);
    // printf( "p: %d\n",p);

    /* The mask will be 0 if the image has no transparency */
    // m=Imlib_move_mask(parms->id,parms->im);

    /* If there was a mask to the image, set the Image's mask to it */
    // if (m) XShapeCombineMask(parms->disp,parms->win,ShapeBounding,0,0,m,ShapeSet);

  } else {

    /* Render the original 24-bit Image data into a pixmap of size w * h */
    if ( !Imlib_render(parms->id,parms->im,w,h) ) {
      fprintf(stderr,"Imlib rendering error\n");
      exit(127);
    }
    if (p!=0)
      Imlib_free_pixmap(parms->id,p);

    p=Imlib_move_image(parms->id,parms->im);
    // printf( "p: %d\n",p);

    /* The mask will be 0 if the image has no transparency */
    m=Imlib_move_mask(parms->id,parms->im);
    /* Put the Image pixmap in the background of the window */
    XSetWindowBackgroundPixmap(parms->disp,parms->win,p);
    /* If there was a mask to the image, set the Image's mask to it */
    // if (m) XShapeCombineMask(parms->disp,parms->win,ShapeBounding,0,0,m,ShapeSet);
    /* Clear the window to update the background change */
    XClearWindow(parms->disp,parms->win);
  }

  if (ttl!=NULL)
    XStoreName( parms->disp, parms->win, ttl );

  /* Put the Image pixmap in the background of the window */
  if (p!=0)
    XSetWindowBackgroundPixmap(parms->disp,parms->win,p);
  /* Actually display the window */
  XMapWindow(parms->disp,parms->win);
  /* Synchronise with the Xserver */
  XSync(parms->disp,False);


}
