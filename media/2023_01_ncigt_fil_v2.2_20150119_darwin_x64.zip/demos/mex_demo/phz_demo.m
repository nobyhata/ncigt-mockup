echo on
% a demo of the phase-alignment function for removing Nyquist ghosts via phase labelling

if ~exist('pos_neg_add')
  mexpath
end;

% read image data acquired on positive readoutsa
P = readnd('Pf.dat'); 

% read image data acquired on negative readouts
N = readnd('Nf.dat');  % 

% phase-align and combine the two images
C = pos_neg_add(P,N);  % 

% display the composite image
im(C);                 % 

echo off;