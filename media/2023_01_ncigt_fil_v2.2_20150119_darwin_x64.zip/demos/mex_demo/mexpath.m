
% this script assumes that the build tree is structured as:
%  <ncigt fil path>/matlab/mex
%  <ncigt fil path>/demos/mex_demo
%
% If that is not true, then the ncigt fil matlab script and mex paths
% will need to be added separately.

curpath = pwd;

if strcmp(computer,'PCWIN')
    indx = findstr('demos\mex_demo',pwd)-1;
else
    indx = findstr('demos/mex_demo',pwd)-1;
end;

addpath([ curpath(1:indx) 'source_code/matlab' ]);
addpath([ curpath(1:indx) 'source_code/matlab/mex' ]);