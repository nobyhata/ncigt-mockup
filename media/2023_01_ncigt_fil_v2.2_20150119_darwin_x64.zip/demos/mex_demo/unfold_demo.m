if ~exist('readnd')
  addpath('../../source_code/matlab');
end;
if ~exist('unfold')
  addpath('../../source_code/matlab/mex');
end;

echo on

% load a temporal image series with tagged sampling artifacts
I = readnd('zoomed.dat');   

% run the unfold filters (in the frequency domain) along the temporal dimension to suppress the artifacts
O = unfold(I);

% figure shows a comparison between the before and after UNFOLD images
im([ I squeeze(O)]);

echo off

