echo on
% a demo of the Partial Fourier reconstruction function 
% in the NCIGT Fast Imaging Library

k = readnd('phantom.dat');

N = 256;

Y = 1:146;     % set the synthetic sampling function

% apply a homodyne correction to the partially sampled k-space data
k0 = correct_pF( k(:,Y,1), [ 256 256 ], 1 );

% display the result
im(fftshift(k0));

echo off


