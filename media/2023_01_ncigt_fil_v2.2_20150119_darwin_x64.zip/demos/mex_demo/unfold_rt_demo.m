
if ~exist('readnd')
  addpath('../../source_code/matlab');
end;
if ~exist('unfold')
  addpath('../../source_code/matlab/mex');
end;

echo on;

% load the UNFOLD demo data
I = readnd('zoomed.dat');

% compute the unfold filter coefficients
% 
% [b,a]=ellip(3,0.1,40,0.9);  % coefficients computed using an elliptical
%                             % filter design
%
b = [ ...
   7.8649577867e-01 ...
   2.3546646007e+00 ...
   2.3546646007e+00 ...
   7.8649577867e-01 ...
    ];
a = [ ...
   1.0000000000e+00 ...
   2.5185200471e+00 ...
   2.1485444932e+00 ...
   6.1525621843e-01 ...
    ];

%  run the data through the time-domain UNFOLD filtering routine
O = unfold_rt( I, b, a );

%  images before (left) and after (right) filter are  shown in the figure
im([ I squeeze(O) ]);

echo off;


