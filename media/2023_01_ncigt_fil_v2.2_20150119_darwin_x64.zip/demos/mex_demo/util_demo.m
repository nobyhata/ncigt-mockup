echo on

%% This is just a simple demo to introduce some of the matlab and mex functions.
%% It loads a sample data file, sub-samples and zero-pads it, and then plots it
%% column-by-column with the original data.

k = readnd('phantom.dat');

% the phase encode list, ordered by N_acq -by- 2.
% each row has [ ky(i) kz(i) ]
Yo = [ vec(1:2:256) ones(128,1) ];

ko = kstretch( Yo, squeeze(k(:,Yo(:,1),1)), [256 256 1] );

% 'ko' should now be a zero-padded version of the subsampled 'k' data
pltcmplx( k(:,:,1), ko(:,:,1) );

echo off
