/*

  This file demonstrates the use of the ND file format.  The NCIGT
  library includes functions to read and write this data format in
  both Matlab and C, providing an easy way to pass data between the two
  formats.

  This demo performs the following in turn:
  * reads the input .nd file
  * copies (if necessary) the data to a COMPLEX array
  * performs a 2D inverse FFT on the input data
  * writes the result to a file, ex_out.nd

 */

#include <stdio.h>
#include <string.h>

#include "igt_fil.h"

int main ( int argc, char* argv[]) {
  
  char *fname;                  // a pointer to the input file name

  COMPLEX *data = NULL;         // a pointer to the complex-valued input data
  float *data_in = NULL;        // a pointer to 
  int   *intd_in = NULL;
  
  /* parameters needed by the read_nd_data function */
  char *tmpp;                   // a temporary pointer
  int n, cnt, sz[4];            // variables to store the data size
                                // and number of dimensions
  char dtype[5] = {0,0,0,0,0};  // a char array to report the data type

  fil_fft_mngr mngr;            // a manager for the FFT operations

  /* copy the first input argument into the filename pointer */
  fname = argv[1];

  printf("%s\n",fname);

  /* read in the nd data file */
  read_nd_data( fname, &tmpp, dtype, &n, sz );

  if ( strcmp(dtype,"dblc")==0 ) {
    /* if the input data is double complex, just need to copy the pointer */
    data = (COMPLEX *) tmpp;
  } else {
    /* otherwise, need to copy the data to a double-complex buffer */
    data = (COMPLEX *) malloc(sz[0]*sz[1]*sz[2]*sizeof(COMPLEX));
    
    if ( strcmp(dtype,"fltc")==0 ) {
      /* if the input data is single-precision float, complex ... */
      data_in = (float *) tmpp;
      for (cnt=0;cnt<sz[0]*sz[1]*sz[2];cnt++) {
        data[cnt].re = (double) data_in[2*cnt  ];
        data[cnt].im = (double) data_in[2*cnt+1];
      } 
    } else if ( strcmp(dtype,"intr")==0 ) {
      /* if the input data is in short int complex format... */
      intd_in = (int *) tmpp;
      for (cnt=0;cnt<sz[0]*sz[1]*sz[2];cnt++) {
        data[cnt].re = (double) intd_in[cnt];
        data[cnt].im = 0; 
      } 
    }

  }
  
  printf("read_nd_data read an %s %d-dimensional array of size ",dtype,n);
  for ( cnt=0; cnt<n; cnt++ ) { 
    printf(" %d",sz[cnt]);
  } 
  printf(".\n");

  if (data == NULL) {
    printf("Somethings wrong.  Data buffer is empty.\n");
    return(-1);
  }

  printf("Performing FFT:\n");
  fft_mngr_init( &mngr );       // initialize an FFT manager
  for ( cnt=0; cnt<sz[2]; cnt++ ) { 
    printf("%d\n",cnt);
    // perform the 2D IFFT
    fil_2dfft( &mngr, sz[0], sz[1], (data+cnt*sz[0]*sz[1]), 'b' );
  }
  fft_mngr_quit( &mngr );       // clear the FFT manager

  // output the data to a file.  This can then be read in Matlab
  // using 'readnd.m'
  write_nd_data( "ex_out.nd", data, "dblc", 3, sz );


  return(0);
}

/* 

  Created Dec 2008, W. Scott Hoge (shoge at bwh dot harvard dot edu)
  
 */
