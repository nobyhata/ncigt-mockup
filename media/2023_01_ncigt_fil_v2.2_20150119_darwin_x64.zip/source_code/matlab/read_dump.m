% Read a file dumped by C code.
%
clear data

% Get the file name to read
fname = input('Name of file to read [./file_out]):  ','s');
if isempty(fname)
   fname = './file_out';
end
fname_txt = [fname '_dims'];

% Open the files
%fid = fopen(Pfile, 'r', 'b');
fid = fopen(fname, 'r', 'l');
fid_txt = fopen(fname_txt, 'r');

% Read the dimensions of the dataset
S = fscanf(fid_txt,'%d%d%d%d%d%d')
ncoils=S(1); Nf=S(2); Nz=S(3); Ny=S(4); Nx=S(5);

% Read the data
k_size = 2*Ny*Nx;         % in 'float' units
temp = zeros(2, Ny*Nx);
real_part = zeros(Nx, Ny); 
imag_part = zeros(Nx, Ny); 
fseek(fid, 0, 'bof');
for icoil = 1:ncoils
   for ifr = 1:Nf
      [buf, count] = fread(fid, k_size, 'double');
      if count ~= k_size
         error(['Only ' num2str(count) ' of ' num2str(k_size) ...
         ' bytes were read for coil #' num2str(icoil) ', phase #' ...
         num2str(ifr)]);
      end
      temp(:) = buf(:);
      real_part(:) = temp(1,:);
      imag_part(:) = temp(2,:);
      data(:,:,1,icoil,ifr) = (real_part' + 1i*imag_part');
   end
end
fclose(fid);
fclose(fid_txt);


