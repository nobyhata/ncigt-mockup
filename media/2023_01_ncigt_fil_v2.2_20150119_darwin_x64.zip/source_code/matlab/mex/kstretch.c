/*

This is a MEX example to call the FIL k-space zero-padding routine

k1 = kstretch( Y, k, [sz] );


To compile, in Matlab call

  mex -I../../../include -L../../../lib -ligt_fil kstretch.c

*/

#include <math.h>
#include "mex.h"
#include "stdio.h"

#include "igt_fil.h"


/* Input Arguments */
#define	Y_IN	prhs[0]
#define	K_IN	prhs[1]
#define SZ_IN	prhs[2]
#define mask_IN prhs[3]

/* Output Arguments */
#define	K_OUT	plhs[0]

void mexFunction( int nlhs, mxArray *plhs[], 
		  int nrhs, const mxArray*prhs[] )
     
{
  int n,m,cnt;
  COMPLEX *data_in, *data_out;
  KCOORD *kline_o, *kline_e;
  int N_acq=0;
  
  short Nx=0, Ny=0, Ny_proc=0, Nz_proc=0, ifr=0, fr1=0, fill_fac=1;

  double  *tmpR,*tmpI;
  int szK, szY, szW;
  const int *dimK, *dimY, *dimW;
  int sz[4];


  if (nrhs < 3) { 
    mexPrintf("At least 3 input arguments are required. (k:measured k-space, Y: associated list of acquired phase encode lines, sz: size of output array)"); 
    return;
  } else if (nlhs > 1) {
    mexPrintf("Too many output arguments."); 
    return;
  } 

  tmpR = mxGetPr(Y_IN);
  szY = mxGetNumberOfDimensions(Y_IN);
  dimY = mxGetDimensions(Y_IN);
  if ( !mxIsDouble(Y_IN) || mxIsComplex(Y_IN) ) {
    mexPrintf( "error with 1st input: Need to declare a real N_acq-by-2"
               " array for the output data size\n" );
    return;
  } else {
    N_acq = (int) dimY[0];
    mexPrintf("input Y lines:\n");
    kline_o = (KCOORD*) malloc( N_acq * sizeof(KCOORD) );

    for (cnt=0;cnt<N_acq;cnt++) {
      /* NOTE: C-code indices start from 0.  So when mapping from Matlab to C,
       be certain to subtract 1 */
      kline_o[cnt].ky = (float) tmpR[cnt] - 1;
      kline_o[cnt].kz = (float) tmpR[cnt + N_acq] - 1;
      mexPrintf(" (%6.2f,%6.2f)",kline_o[cnt].ky,kline_o[cnt].kz); 
    }
    mexPrintf("\n");
  }
  

  tmpR = mxGetPr(K_IN);
  tmpI = mxGetPi(K_IN);
  szK  = mxGetNumberOfDimensions(K_IN);
  dimK = mxGetDimensions(K_IN);
  if ( !mxIsDouble(K_IN) || (dimK[1] != N_acq) ) {
    mexPrintf( "error with 2nd input: Need to declare a complex Nx-by-N_acq"
               " array for the input data.\n" );
    mexPrintf( "\t (in:[ %d %d ]) != (expected:[ ?? %d ]) \n",
               dimK[0],dimK[1],
               N_acq );
    return;
  } else {
    Nx = (int) dimK[0];
    N_acq = (int) dimK[1];

    data_in = (COMPLEX *) malloc( Nx * N_acq * sizeof(COMPLEX) );
    for ( cnt=0; cnt< Nx * N_acq; cnt++ ) {
      data_in[cnt].re = (float) tmpR[cnt];
      data_in[cnt].im = (float) tmpI[cnt];
    } 
    printf("\n");
  }


  if (nrhs > 2) { 
    tmpR = mxGetPr(SZ_IN);
    szW = mxGetNumberOfDimensions(SZ_IN);
    dimW = mxGetDimensions(SZ_IN);
    
    if ( !mxIsDouble(SZ_IN) || (szW != 2) ) {
      mexPrintf( "error with 3rd input: Need to declare a 1-by-3"
                 " array for the final size of the coil sensitivity data.\n" );
      return;
    } else {
      Nx = (int) tmpR[0];
      Ny = (int) tmpR[1];
      Nz_proc = (int) tmpR[2];
    }
  }


  data_out = (COMPLEX *) malloc( Nz_proc * fill_fac * Ny * Nx *
                                 sizeof(COMPLEX) );

  /*
  sz[0] = Nx;  sz[1] = N_acq;
  write_nd_data("k_in.nd",data_in,"fltc",2,sz);
  */

  kstretch( Nx, Ny, Nz_proc, N_acq, fill_fac,
            ifr, fr1, kline_o, kline_o,
            data_in, data_out );

  /*
  sz[0] = Nx; sz[1] = Ny;  sz[2] = Nz_proc;
  write_nd_data("k_out.nd",data_out,"fltc",3,sz);
  */
  
  if (nlhs>0) {

    sz[0] = (int) Nx; 
    sz[1] = (int) Ny; 
    sz[2] = (int) Nz_proc;
  
    K_OUT = mxCreateNumericArray( 3, sz, 
                                  mxDOUBLE_CLASS,
                                  mxCOMPLEX); 
    
    tmpR = mxGetPr(K_OUT);
    tmpI = mxGetPi(K_OUT);
    
    for (cnt=0; cnt < Nx*Ny*Nz_proc; cnt++) {
      tmpR[cnt] = (double) data_out[cnt].re;
      tmpI[cnt] = (double) data_out[cnt].im;
    }
  }

  /*
  free(data_in);
  free(data_out);
  */

  return;
  
}
/*

Copyright 2009, National Center for Image Guided Therapy (NCIGT)

Written by W. Scott Hoge (shoge.harvard.edu) 

All rights reserved. Licensed according to the terms of a BSD-style 
licence covering the Fast Imaging Library 
(see http://www.ncigt.org/pages/Downloads "Imaging Toolbox")


*/
