/*

This is a MEX example to call the FIL Nyquist ghost correction routine
based on 3-line navigators.

Send two data sets in, the raw k-space and a set of reference lines, and 
and ghost correction set of k-space will be returned.

[kc,phz] = ngc_3nav( k, kref );

k:     measure EPI data, sized [ kx ky ... ]
kref:  the associated 3-navigator echoes data [ 3 ky ... ]

the number of dimensions of each should be identical


To compile, in Matlab call

  mex -I../../../include -L../../../lib -ligt_fil ngc_3nav.c

 */

#include <math.h>
#include "mex.h"
#include "stdio.h"

#include "igt_fil.h"

/* Input Arguments */
#define	K_IN	prhs[0]
#define	R_IN	prhs[1]

/* Output Arguments */
#define	K_OUT	plhs[0]
#define	P_OUT	plhs[1]

/* #define DEBUG_NGC3  */

short  V=0;               /* 0 for verbose off */

#define TNUM  8                 /* number of process threads to use */

void mexFunction( int nlhs, mxArray *plhs[], 
		  int nrhs, const mxArray*prhs[] )
     
{

  double  *tmpR,*tmpI;
  int szK, chn_num, line_num;
  const int *dimK;
  int sz[4];

  char strout[20];

  DATA_OBJ k_raw; /**< raw input EPI data frame.  */
  DATA_OBJ k_ref; /**< raw EPI reference data. Should be [ 3lines x ncoils ] */

  DATA_OBJ k_out; /**< corrected kspace data */

  DATA_OBJ ngc_even; 
  DATA_OBJ ngc_odd;  
  DATA_OBJ ngc_phz;  

  fil_fft_mngr mngr;
  NGC_MEM ngc_mem;

  COMPLEX *tmpc;
  COMPLEX *oddp, *evenp;
  int     ecnt, ocnt;

  float *fltR;
  float *phz;
  float  phzdir;

  int npattern, nslices, ncoils; 

  GRAPPA_OBJ  **gobj_array;
  const char *fieldnames[] = {"dk","pattern","coef"};
  int dk_field, pattern_field, coef_field;
  mxArray *field_value;
  int cnt,pcnt,cnt1,cnt2,iindx,oindx;
  dataheader hdr;

#ifdef DEBUG_NGC3
  char fname[20];
#endif

  int nEl;

  if (nrhs < 2) { 
    mexPrintf("At least 2 input arguments are required. (k:measured k-space, r: ngc reference data)");
    return;
  } else if (nlhs > 3) {
    mexPrintf("Too many output arguments."); 
    return;
  } 

  /**********************************************************************/
  /* initialize the input data objects */

  tmpR = mxGetPr(K_IN);
  tmpI = mxGetPi(K_IN);
  szK  = mxGetNumberOfDimensions(K_IN);
  dimK = mxGetDimensions(K_IN);
  if ( !mxIsDouble(K_IN) || !mxIsComplex(K_IN) || (szK < 2) ) {
    mexPrintf( "error with 1st input: Need to declare a double complex M-by-N-by-..."
               " array for the input data.\n" );
    mexPrintf( "\t (in:[ %d %d ... ]) ndim: %d \n", dimK[0], dimK[1], szK );
    return;
  } else {
    init_data_obj( &k_raw );

    k_raw.ndim = 3;
    k_raw.sz[0] = dimK[0];
    k_raw.sz[1] = dimK[1];
    k_raw.sz[2] = 1;
    for (cnt=2;cnt<szK;cnt++) {
      /* fprintf(stderr,"dimK[%d] = %d\n",cnt,dimK[cnt]); */
      k_raw.sz[2] *= dimK[cnt];
    }
    /* fprintf(stderr,"k_raw.sz = [ %d %d %d]\n",k_raw.sz[0],k_raw.sz[1],k_raw.sz[2]); */
    nEl = k_raw.sz[0]*k_raw.sz[1]*k_raw.sz[2];
    
    k_raw.data = malloc( nEl * sizeof(COMPLEX) );
    tmpc = (COMPLEX *) k_raw.data;
    for (cnt=0;cnt<nEl; cnt++) {
      tmpc[cnt].re = (double) tmpR[cnt];
      tmpc[cnt].im = (double) tmpI[cnt];
    }
    k_raw.init = nEl;
    strcpy( k_raw.type, "dblc" );

  }
  /* write_nd_data2("k.nd",&k_raw); */

  tmpR = mxGetPr(R_IN);
  tmpI = mxGetPi(R_IN);
  szK  = mxGetNumberOfDimensions(R_IN);
  dimK = mxGetDimensions(R_IN);
  if ( !mxIsComplex(R_IN) ||  !mxIsDouble(R_IN) || (szK < 2) ) {
    mexPrintf( "error with 2nd input: Need to declare a double complex M-by-K-by-..."
               " array for the input data.\n" );
    mexPrintf( "\t (in:[ %d %d ... ]) \n", dimK[0], dimK[1] );
    return;
  } else {
    init_data_obj( &k_ref );

    k_ref.ndim = 3;
    k_ref.sz[0] = dimK[0];
    k_ref.sz[1] = dimK[1];
    k_ref.sz[2] = 1;
    for (cnt=2;cnt<(szK);cnt++) {
      /* fprintf(stderr,"dimR[%d] = %d\n",cnt,dimK[cnt]); */
      k_ref.sz[2] *= dimK[cnt];
    }
    nEl = k_ref.sz[0]*k_ref.sz[1]*k_ref.sz[2];
    
    k_ref.data = malloc( nEl * sizeof(COMPLEX) );
    tmpc = (COMPLEX *) k_ref.data;
    for (cnt=0; cnt<nEl; cnt++) {
      tmpc[cnt].re = (double) tmpR[cnt];
      tmpc[cnt].im = (double) tmpI[cnt];
    }
    k_ref.init = 1;
    strcpy( k_ref.type, "dblc" );
  }
  /* write_nd_data2("ref.nd",&k_ref); */

  sprintf(strout,"[ .. .. ");
  for (cnt=2;cnt<k_ref.ndim;cnt++) {
    if ( k_raw.sz[cnt] != k_ref.sz[cnt] ){
      mexPrintf("Error: input matrix size mismatch - A: [ %s %d ... ] vs B: [ %s %d ... ]\n", strout, k_raw.sz[cnt], strout, k_ref.sz[cnt]);
      return;

    }
    sprintf(strout,"%s %d ",strout,k_ref.sz[cnt]);
  }
#ifdef DEBUG_NGC3
  sprintf(strout,"%s ]",strout);
  mexPrintf("sz: %s\n",strout);
#endif

  /** setup NGC processing memory **/
  init_data_obj( &ngc_even );
  ngc_even.data = (char *) calloc( k_ref.sz[0] * k_ref.sz[2], sizeof(COMPLEX) );
  ngc_even.ndim = 2;
  ngc_even.sz[0] = k_ref.sz[0];
  ngc_even.sz[1] = k_ref.sz[2];
  strcpy( ngc_even.type, "dblc" );
  
  init_data_obj( &ngc_odd );
  ngc_odd.data  = (char *) calloc( k_ref.sz[0] * k_ref.sz[2], sizeof(COMPLEX) );
  ngc_odd.ndim = 2;
  ngc_odd.sz[0] = k_ref.sz[0];
  ngc_odd.sz[1] = k_ref.sz[2];
  strcpy( ngc_odd.type, "dblc" );

  init_data_obj( &ngc_phz );
  ngc_phz.data = (char *) calloc( k_ref.sz[2], sizeof(float) );
  ngc_phz.ndim = 1;
  ngc_phz.sz[0] = k_ref.sz[2];
  strcpy( ngc_phz.type, "fltr" );

  fft_mngr_init( &mngr );
  ngc_mem_init( ngc_odd.sz, k_raw.sz[0] * k_raw.sz[1] * k_raw.sz[2], &ngc_mem );
  /** ********************* **/

  /** average the input reference lines **/
  for ( chn_num=0; chn_num < k_ref.sz[2]; chn_num++ ) {
    oddp  = (COMPLEX *) ( ngc_odd.data  + chn_num*k_ref.sz[0]*sizeof(COMPLEX) );
    evenp = (COMPLEX *) ( ngc_even.data + chn_num*k_ref.sz[0]*sizeof(COMPLEX) );

    ocnt=0; ecnt=0;
    for ( line_num=0; line_num < k_ref.sz[1]; line_num++ ) {
      tmpc = (COMPLEX *) ( k_ref.data  + (line_num*k_ref.sz[0] + chn_num * k_ref.sz[0] * k_ref.sz[1] )*sizeof(COMPLEX));
      if ( line_num % 2 ) {
        /* fprintf(stderr,"odd "); */
        for ( cnt=0; cnt < k_ref.sz[0]; cnt++ ) {
          oddp[ cnt ].re += tmpc[ cnt].re;
          oddp[ cnt ].im += tmpc[ cnt].im;
        }
        ocnt++;
      } else {
        /* fprintf(stderr,"even "); */
        for ( cnt=0; cnt < k_ref.sz[0]; cnt++ ) {
          evenp[ cnt ].re += tmpc[ cnt].re;
          evenp[ cnt ].im += tmpc[ cnt].im;
        }
        ecnt++;
      }
    }
    /* fprintf(stderr,"\n o:%d e:%d\n",ocnt,ecnt); */
    for ( cnt=0; cnt < k_ref.sz[0]; cnt++ ) {
      evenp[ cnt ].re  /= (double)ecnt;
      evenp[ cnt ].im  /= (double)ecnt;
      oddp[ cnt ].re   /= (double)ocnt;
      oddp[ cnt ].im   /= (double)ocnt;
    }

  }
  /*
  write_nd_data2("ngc_even.nd",&ngc_even);
  write_nd_data2("ngc_odd.nd",&ngc_odd);
  */


  /** the actual processing calls **/
  ngc_compute_phase_shift( &ngc_even, &ngc_odd, &ngc_phz, &mngr, &ngc_mem );

  ngc_apply_phase_shift( &k_raw, &ngc_phz, &mngr, &ngc_mem );

  /*  write_nd_data2("k_out.nd",&k_raw); */


  /** copy the output data to the matlab object(s) **/
  if (nlhs > 0) {

    szK = mxGetNumberOfDimensions(K_IN);
    dimK = mxGetDimensions(K_IN);
    K_OUT = mxCreateNumericArray( szK, dimK, 
                                  mxDOUBLE_CLASS,
                                  mxCOMPLEX); 
    tmpR = mxGetPr(K_OUT);
    tmpI = mxGetPi(K_OUT);

    nEl = k_raw.sz[0]*k_raw.sz[1]*k_raw.sz[2];

    tmpc = (COMPLEX *) k_raw.data;
    for ( cnt=0; cnt < nEl; cnt++ ) {
        tmpR[ cnt ] = tmpc[ cnt ].re;
        tmpI[ cnt ] = tmpc[ cnt ].im;
    }
  }
  if (nlhs > 1) {

    P_OUT = mxCreateNumericArray( ngc_phz.ndim, 
                                  ngc_phz.sz,
                                  mxDOUBLE_CLASS,
                                  mxREAL); 
    tmpR = mxGetPr(P_OUT);

    phz = (float *) ngc_phz.data;
    for ( cnt=0; cnt < ngc_phz.sz[0]; cnt++ ) {
      tmpR[ cnt ] = (double)phz[ cnt ];
    }
  }


  free(k_raw.data);
  free(k_ref.data);
  free(ngc_phz.data);
  free(ngc_odd.data);
  free(ngc_even.data);

  fft_mngr_quit( &mngr );
  ngc_mem_quit( &ngc_mem );

  return;
}
/*

Copyright 2012, National Center for Image Guided Therapy (NCIGT)

Written by W. Scott Hoge (shoge -at- bwh.harvard.edu) 

All rights reserved. Licensed according to the terms of a BSD-style 
licence covering the Fast Imaging Library 
(see http://www.ncigt.org/pages/Downloads "Imaging Toolbox")

*/
