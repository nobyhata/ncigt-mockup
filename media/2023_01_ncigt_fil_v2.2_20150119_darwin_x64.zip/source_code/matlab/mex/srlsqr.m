% [ I, x, r ] = srlsqr( W, k, Y, [ lams, maxits ] );
%
% LSQR-Hybrid reconstruction of data in the hybrid domain.
%
% Inputs:
% W - coil sensitivity estimates, size: [ m -by- n -by- l ]
% k - subsampled data, size: [ p -by- n -by- l ]
%     needs to be in the hybrid domain, e.g. ky,x,c
% Y - column array of phase-encode indices, size: [ p -by- 1 ]
%
% Outputs:
% I = reconstructed images, size [ m -by- n -by- numlams ]
% x = estimated norm of the solution for each lambda
% r = estimated residual error for each lambda
%
% Note: If only one output argument is declared, then the algorihtm
% will select a single image from the set and return only that image.xs
%

% Copyright 2009, National Center for Image Guided Therapy (NCIGT)
% 
% Written by W. Scott Hoge (shoge.harvard.edu) 
% 
% All rights reserved. Licensed according to the terms of a BSD-style 
% licence covering the Fast Imaging Library 
% (see http://www.ncigt.org/pages/Downloads "Imaging Toolbox")
% 
% 
% 