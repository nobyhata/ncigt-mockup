/*

This is a MEX example to call the FIL coil sensitivity estimation routine
based on GEYSER.

W = geyser( k, Y, sz );


To compile, in Matlab call

  mex -I../../../include -L../../../lib -ligt_fil geyser.c

*/

#include <math.h>
#include "mex.h"
#include "stdio.h"

#include "igt_fil.h"
#include "grappa.h"


/* Input Arguments */
#define	K_IN	prhs[0]
#define	Y_IN	prhs[1]
#define SZ_IN	prhs[2]
#define mask_IN prhs[3]

/* Output Arguments */
#define	W_OUT	plhs[0]

short  V=0;               /* 0 for verbose off */

void mexFunction( int nlhs, mxArray *plhs[], 
		  int nrhs, const mxArray*prhs[] )
     
{
  int n,m,cnt;
  COMPLEX *W,*K;
  int *PhaseLines;
  int Nlines, use_mask=0;
  dataheader hdr;

  double  *tmpR,*tmpI;
  int szK, szY, szW;
  const int *dimK, *dimY, *dimW;
  int sz[4];

  fil_fft_mngr mngr;


  if (nrhs < 3) { 
    mexPrintf("At least 3 input arguments are required. (k:measured k-space, Y: associated list of acquired phase encode lines, sz: size of output coil maps)"); 
    return;
  } else if (nlhs > 1) {
    mexPrintf("Too many output arguments."); 
    return;
  } 

  tmpR = mxGetPr(Y_IN);
  szY = mxGetNumberOfDimensions(Y_IN);
  dimY = mxGetDimensions(Y_IN);
  if ( !mxIsDouble(Y_IN) || (dimY[1] != 1) ||
       mxIsComplex(Y_IN) ) {
    mexPrintf( "error with 2rd input: Need to declare a real M-by-1"
               " array for the output data size\n" );
    return;
  } else {
    hdr.yres = (int) dimY[0];
    mexPrintf("input Y lines:\n");
    PhaseLines = (int*) malloc( (int)hdr.yres * sizeof(int) );
    for (cnt=0;cnt<hdr.yres;cnt++) {
      /* convert indices from matlab (1 based) to C (0 based) */
      PhaseLines[cnt] = (int) tmpR[cnt] - 1;
      mexPrintf(" %3d",PhaseLines[cnt]); 
    }
    mexPrintf("\n");
  }
  
  if (nrhs > 2) { 
    tmpR = mxGetPr(SZ_IN);
    szW = mxGetNumberOfDimensions(SZ_IN);
    dimW = mxGetDimensions(SZ_IN);
    
    if ( !mxIsDouble(SZ_IN) || (szW != 2) ) {
      mexPrintf( "error with 3rd input: Need to declare a 1-by-3"
                 " array for the final size of the coil sensitivity data.\n" );
      return;
    } else {
      hdr.Nvertical = (int) tmpR[0];
    }
  } else {
    hdr.Nvertical = (int) PhaseLines[hdr.yres-1];
  }

  tmpR = mxGetPr(K_IN);
  tmpI = mxGetPi(K_IN);
  szK  = mxGetNumberOfDimensions(K_IN);
  dimK = mxGetDimensions(K_IN);
  if ( !mxIsDouble(K_IN) || (dimK[0] != hdr.yres) || (szK != 3) ) {
    mexPrintf( "error with 1st input: Need to declare a complex M-by-N-by-L"
               " array for the input data.\n" );
    mexPrintf( "\t (in:[ %d %d %d ]) != (expected:[ %d ?? ?? ]) \n",
               dimK[0],dimK[1],dimK[2],
               hdr.yres );
    return;
  } else {
    hdr.yres = (int) dimK[0];
    hdr.xres = (int) dimK[1];
    hdr.Ncoils = (int) dimK[2];

    K = (COMPLEX *) malloc( hdr.yres * 
                               hdr.xres * 
                               hdr.Ncoils * sizeof(COMPLEX) );
    for (cnt=0;cnt<hdr.yres * hdr.xres * hdr.Ncoils; cnt++) {
      K[cnt].re = (double) tmpR[cnt];
      K[cnt].im = (double) tmpI[cnt];
    } 
    printf("\n");
  }


  if (nrhs > 3) { 
    tmpR = mxGetPr(mask_IN);
    szW = mxGetNumberOfDimensions(mask_IN);
    dimW = mxGetDimensions(mask_IN);
    
    if ( !mxIsDouble(mask_IN) || (szW != 2) ) {
      mexPrintf( "error with 4th input: Need to declare a 1-by-1"
                 " array to flag masking on (1) or off (0).\n");
      return;
    } else {
      use_mask = (int) tmpR[0];
    }
  } else {
    use_mask = 0;
  }


  /*
    sz[0] = hdr.yres;  sz[1] = hdr.xres;  sz[2] = hdr.Ncoils;
    write_nd_data("k_in.nd",K,"dblc",3,sz);
  */

  W =  (COMPLEX *) malloc( hdr.Nvertical * 
                              hdr.xres * 
                              hdr.Ncoils * sizeof(COMPLEX) );

  fft_mngr_init( &mngr );

  self_ref_b1_via_geyser( K, &hdr, PhaseLines, W, &mngr, use_mask );

  fft_mngr_quit( &mngr );
  
  /*
    sz[0] = hdr.Nvertical;  sz[1] = hdr.xres;  sz[2] = hdr.Ncoils;
    write_nd_data("w_out.nd",W,"dblc",3,sz);
  */
  
  if (nlhs>0) {

    sz[0] = (int) hdr.Nvertical; 
    sz[1] = (int) hdr.xres; 
    sz[2] = (int) hdr.Ncoils;
  
    W_OUT = mxCreateNumericArray( 3, sz, 
                                  mxDOUBLE_CLASS,
                                  mxCOMPLEX); 
    
    tmpR = mxGetPr(W_OUT);
    tmpI = mxGetPi(W_OUT);
    
    for (cnt=0; cnt < hdr.Nvertical*hdr.xres*hdr.Ncoils; cnt++) {
      tmpR[cnt] = W[cnt].re;
      tmpI[cnt] = W[cnt].im;
    }
  }


  free(W);
  free(K);
  free(PhaseLines);

  return;
  
}
/*

Copyright 2009, National Center for Image Guided Therapy (NCIGT)

Written by W. Scott Hoge (shoge.harvard.edu) 

All rights reserved. Licensed according to the terms of a BSD-style 
licence covering the Fast Imaging Library 
(see http://www.ncigt.org/pages/Downloads "Imaging Toolbox")


*/
