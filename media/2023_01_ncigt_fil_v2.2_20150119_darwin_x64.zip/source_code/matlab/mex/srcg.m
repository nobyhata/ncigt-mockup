%
% I = srcg( W, k, Y, [ tau, maxits ] );
%
% CG reconstruction of pMRI data in the hybrid domain.
%
% Inputs:
% W - coil sensitivity estimates, size: [ m -by- n -by- l ]
% k - subsampled data, size: [ p -by- n -by- l ]
%     needs to be in the hybrid domain, e.g. ky,x,c
% Y - column array of phase-encode indices, size: [ p -by- 1 ]
%
% Outputs:
% I = reconstructed image, size [ m -by- n ]
%

% Copyright 2009, National Center for Image Guided Therapy (NCIGT)
% 
% Written by W. Scott Hoge (shoge.harvard.edu) 
% 
% All rights reserved. Licensed according to the terms of a BSD-style 
% licence covering the Fast Imaging Library 
% (see http://www.ncigt.org/pages/Downloads "Imaging Toolbox")
% 
% 
% 