% This is a MEX example to call the FIL UNFOLD temporal artifact suppression
% code.
% 
% Usage:
% 
% [k,ny]=unfold( k_in, [ filt, width ] );
% 
% Inputs:
%     k_in: k-space data, ky-kx-t or ky-kx-z-t or kx-ky-z-t-l
%     filt: (optional) selects which fiilter to use in processing
%        'high' : high-freq notch filter to suppress signals at
%                 Nyquist rate (default)
%        'midp' : mid-freq bandpass filter to suppress signals at Nyquist
%                 and DC 
%        'lowp' : low-freq bandpass filter to keep signals only at DC
%     width: (optional) fractional width of the filter passband/stopband
% 
% Outputs:
%     k:    filtered k-space data
%     ny:   filter coefficients used during the alias suppression
% 

% Copyright 2009, National Center for Image Guided Therapy (NCIGT)
% 
% Written by W. Scott Hoge (shoge.harvard.edu) 
% 
% All rights reserved. Licensed according to the terms of a BSD-style 
% licence covering the Fast Imaging Library 
% (see http://www.ncigt.org/pages/Downloads "Imaging Toolbox")
% 
% 
% 