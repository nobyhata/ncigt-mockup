% This is a MEX file to call the FIL coil sensitivity estimation routine
% based on GEYSER.
% 
% W = geyser( k, Y, sz, [mask] );
% 
% k  - input k-space data, of size [ p n l ]
% Y  - list of k-space line indices, vector of size [ p 1 ]
% sz - the size of the output coils sensitivity estimate, of size [ 1 3 ]
% mask - an optional mask to use in the calculations
%
% W  - the output coil sensitivity estimate
%

% Copyright 2009, National Center for Image Guided Therapy (NCIGT)
% 
% Written by W. Scott Hoge (shoge.harvard.edu) 
% 
% All rights reserved. Licensed according to the terms of a BSD-style 
% licence covering the Fast Imaging Library 
% (see http://www.ncigt.org/pages/Downloads "Imaging Toolbox")
% 
% 
% 