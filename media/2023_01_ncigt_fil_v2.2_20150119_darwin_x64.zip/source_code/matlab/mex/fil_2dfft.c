/*

This is a MEX example to call the FIL 2D FFT function.  

K = fil_2dfft( k, dir );

dir: an optional character to specify direction, 'f' or 'b'

To compile, in Matlab call

  mex -I../../../include -L../../../lib -ligt_fil fil_2dfft.c

*/

#include <math.h>
#include "mex.h"
#include "stdio.h"

#include "igt_fil.h"

/* Input Arguments */
#define	K_IN	prhs[0]
#define D_IN    prhs[1]

/* Output Arguments */
#define	I_OUT	plhs[0]

short  V=0;               /* 0 for verbose off */


void mexFunction( int nlhs, mxArray *plhs[], 
		  int nrhs, const mxArray*prhs[] )
     
{
  int  n,m,cnt,cnt1;
  COMPLEX *K, *data;
  int  N,M,L;
  char dir = 'f';

  double  *tmpR,*tmpI,scl;
  int szK;
  const int *dimK;
  int status;
  int sz[4];

  fil_fft_mngr mngr;

  tmpR = mxGetPr(K_IN);
  tmpI = mxGetPi(K_IN);
  szK  = mxGetNumberOfDimensions(K_IN);
  dimK = mxGetDimensions(K_IN);
  if ( !mxIsDouble(K_IN) ) {
    mexPrintf( "error with 1st input: Need to declare a complex M-by-N-by-L"
               " array for the input data.\n" );
    return;
  } else {
    M = (int) dimK[0];
    N = (int) dimK[1];
    L = (int) dimK[2];

    K = (COMPLEX *) malloc( M*N*L* sizeof(COMPLEX) );
    for (cnt=0;cnt< M*N*L; cnt++) {
      K[cnt].re = (DATATYPE) tmpR[cnt];
      K[cnt].im = (DATATYPE) tmpI[cnt];
    } 
    printf("\n");
  }

  if (nrhs>1) {
    tmpR = mxGetPr(D_IN);
    tmpI = mxGetPi(D_IN);
    szK  = mxGetNumberOfDimensions(D_IN);
    dimK = mxGetDimensions(D_IN);
    if ( !mxIsChar(D_IN) ) {
      mexPrintf( "error with 2nd input: Need to declare string, 'f' or 'b' \n");
      return;
    } else {
      status = mxGetString(D_IN,&dir,0);
      if(status != 0) {
        mexWarnMsgTxt("Error in copying FFT direction argument.");
        fprintf(stderr,"Status: %d\n",status);
      }
    }
  }
  /*
  sz[0] = M;  sz[1] = N;  sz[2] = L;
  write_nd_data("k_in.nd",K,"dblc",3,sz);
  */

  fft_mngr_init( &mngr );

  /* fprintf(stderr,"Dir: %c (%d)\n",dir,dir); */
  for (cnt=0;cnt<L;cnt++) {
    fil_2dfft( &mngr, M, N, ( K + cnt*M*N ), dir );

    /* to match Matlab's ifft2 call, need to scale by M*N */
    if (dir == 'b') {
      data = K + cnt*M*N;
      scl = M*N;
      for (cnt1=0;cnt1<M*N;cnt1++) {
        data[cnt1].re = data[cnt1].re / scl;
        data[cnt1].im = data[cnt1].im / scl;
      }
    }

  }

  fft_mngr_quit( &mngr );

  /*
    sz[0] = M;  sz[1] = N;  sz[2] = L;
    write_nd_data("w_out.nd",K,"dblc",3,sz);
  */
  
  if (nlhs>0) {

    sz[0] = (int) M;
    sz[1] = (int) N;
    sz[2] = (int) L;
  
    I_OUT = mxCreateNumericArray( 3, sz, 
                                  mxDOUBLE_CLASS,
                                  mxCOMPLEX); 
    
    tmpR = mxGetPr(I_OUT);
    tmpI = mxGetPi(I_OUT);
    
    for (cnt=0; cnt < M*N*L; cnt++) {
      tmpR[cnt] = K[cnt].re;
      tmpI[cnt] = K[cnt].im;
    }
  }

  free(K);

  return;
  
}
/*

Copyright 2009, National Center for Image Guided Therapy (NCIGT)

Written by W. Scott Hoge (shoge.harvard.edu) 

All rights reserved. Licensed according to the terms of a BSD-style 
licence covering the Fast Imaging Library 
(see http://www.ncigt.org/pages/Downloads "Imaging Toolbox")


*/
