%
% This is a MEX example to call the FIL coil sensitivity estimation routine
% based on the view sharing approach, SHRUG.
% 
% W = self_ref_b1( k );
% 
% The input, k, is assumed to be zero-padded (stretched) and of size
% Nx-Ny-Nz-Ncoil-Nt
%

% Copyright 2009, National Center for Image Guided Therapy (NCIGT)
% 
% Written by W. Scott Hoge (shoge.harvard.edu) 
% 
% All rights reserved. Licensed according to the terms of a BSD-style 
% licence covering the Fast Imaging Library 
% (see http://www.ncigt.org/pages/Downloads "Imaging Toolbox")
% 
% 
% 