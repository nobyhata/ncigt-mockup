/*

This is a MEX example to call the FIL UNFOLD temporal artifact suppression
code.  The version employs a temporal domain filter (aka real-time filter)
instead of the original frequency domain operation.

To compile, in Matlab call

  mex -I../../../include -L../../../lib -ligt_fil unfold_rt.c

Usage:

[k]=unfold_rt( k_in, b, a );

k_in: k-space data, ky-kx-t or ky-kx-z-t or kx-ky-z-l-t
b:    feed-forward filter coefficients
a:    feed-backward filter coefficients
k:    filtered data

*/

#include <math.h>
#include "mex.h"
#include "stdio.h"
#include "string.h"

#include "igt_fil.h"


/* Input Arguments */
#define	K_IN  prhs[0]
#define B_IN  prhs[1]
#define A_IN  prhs[2]

/* Output Arguments */
#define	K_OUT	plhs[0]

short  V=0;               /* 0 for verbose off */


void mexFunction( int nlhs, mxArray *plhs[], 
		  int nrhs, const mxArray*prhs[] )
     
{
  int cnt,cntZ;
  COMPLEX *data_in,*full;
  int Nx, Ny, Nz=1, Nf, Nc, Nf_proc, ncoils = 1;
  char *str;
  char mode = 'h';

  fil_fft_mngr mngr;

  double  *tmpR,*tmpI,scl;
  int szK,prd;
  const int *dimK, *dimB;
  int sz[6];
  int n, na, nb, indx;
  double *B, *A;

  filter_t_obj filt_obj;

  if (nrhs < 3) { 
    mexPrintf("At least 3 input arguments are required."); 
    return;
  } else if (nlhs > 2) {
    mexPrintf("Too many output arguments."); 
    return;
  } 

  tmpR = mxGetPr(K_IN);
  tmpI = mxGetPi(K_IN);
  szK = mxGetNumberOfDimensions(K_IN);
  dimK = mxGetDimensions(K_IN);

  if ( !mxIsDouble(K_IN) || !mxIsComplex(K_IN) ) {
    mexPrintf( "1st input: Need to declare a complex "
               " array for the input k-space data\n" );
    return;
  } else {
    /* header variables that need to be populated */
    Nx = dimK[0];
    Ny = dimK[1];
    Nf = dimK[2];
    Nc = 1; /* dimK[3]; */
    Nf_proc = set_nfproc(Nf, 0);

    /*
    printf("sz = ");
    for (cnt=0;cnt<szK;cnt++) {
      printf("%d ",dimK[cnt]);
    }
    printf("\n");
    */

    prd = Nf * Ny * Nx * Nc;
    data_in = (COMPLEX *) malloc( prd * sizeof(COMPLEX) );

    /* mexPrintf("prd = %d\n",prd); */

    for (cnt=0;cnt<prd;cnt++) {
      data_in[cnt].re = tmpR[cnt];
      data_in[cnt].im = tmpI[cnt];
    }

  }
  
    
  if ( !mxIsDouble(B_IN) || mxIsComplex(B_IN) || 
       ( mxGetNumberOfDimensions(B_IN) > 2 ) ) {
    mexPrintf( "2nd input: Need to declare an (n-by-1) array of "
               "feed-forward filter coefficient values \n" );
    return;
  }
  if ( !mxIsDouble(A_IN) || mxIsComplex(A_IN) || 
       ( mxGetNumberOfDimensions(A_IN) > 2 ) ) {
    mexPrintf( "3rd input: Need to declare an (n-by-1) array of "
               "feed-forward filter coefficient values \n" );
    return;

  } 

  /* copy over the filter coefficients */
  dimB = mxGetDimensions(B_IN);
  nb = ( dimB[0] > dimB[1] ) ? dimB[0] : dimB[1];

  dimK = mxGetDimensions(A_IN);
  na = ( dimK[0] > dimK[1] ) ? dimK[0] : dimK[1];
  
  n = (na > nb) ? na : nb;

  B = (double *) malloc( n * sizeof(double) );
  A = (double *) malloc( n * sizeof(double) );
  memset( B, 0, n * sizeof(double) );
  memset( A, 0, n * sizeof(double) );

  tmpR = mxGetPr(B_IN);
  for (cnt=0;cnt<nb;cnt++) {
    B[cnt] = tmpR[cnt];
  }

  tmpI = mxGetPr(A_IN);
  for (cnt=0;cnt<na;cnt++) {
    A[cnt] = tmpI[cnt];
  }

  /* Create plans for a 1D FFT along the time (or frequency) axis */
  fft_mngr_init( &mngr );

  full = (COMPLEX *) malloc( Nf_proc * Ny * Nx 
                             * ncoils * sizeof(COMPLEX) );

  filter_t_init( n, Nx, Ny, Nc, A, B, &filt_obj );

  /*
  fprintf(stderr,"obj.n=%d\n",filt_obj.n);
  for (cnt=0;cnt<n;cnt++) {
    printf(" a[%2d]=%f  b[%2d]=%f\n",cnt,A[cnt],cnt,B[cnt]);
  }
  */

  for (cnt=0;cnt<Nf;cnt++) {
    indx = cnt*Nx*Ny;
    filter_t_step( &filt_obj, (data_in + indx), (full + indx) );
  }
  filter_t_quit( &filt_obj );

  /*
  sz[0] = Nx;
  sz[1] = Ny;
  sz[2] = Nf;
  write_nd_data( "unf_out.nd", full, "dblc", 3, sz );
  */

  if (nlhs>0) {

    sz[0] = Nx;
    sz[1] = Ny;

    szK = mxGetNumberOfDimensions(K_IN);
    if (szK == 3) {
      scl = 3;
      sz[2] = Nf;
    } else if (szK == 4) {
      scl = 4;
      sz[2] = Nz;
      sz[3] = Nf;
    } else if (szK == 5) {
      scl = 5;
      sz[2] = Nz;
      sz[3] = Nf;
      sz[4] = ncoils;
    }
    K_OUT = mxCreateNumericArray( scl, sz, 
                                  mxDOUBLE_CLASS,
                                  mxCOMPLEX); 
    tmpR = mxGetPr(K_OUT);
    tmpI = mxGetPi(K_OUT);
    
    prd = Nz * Ny * Nx ;

    for (cntZ=0;cntZ<ncoils;cntZ++) {
      for (cnt=0;cnt<prd*Nf; cnt++) {
        tmpR[ cnt + cntZ*Nf*prd ] = 
          full[ cnt + cntZ*Nf_proc*prd ].re;
        tmpI[ cnt + cntZ*Nf*prd ] = 
          full[ cnt + cntZ*Nf_proc*prd ].im;
      }
    }

  }

  /*
  free(full);
  free(data_in);
  */

  return;
  
}
/*

Copyright 2009, National Center for Image Guided Therapy (NCIGT)

Written by W. Scott Hoge (shoge.harvard.edu) 

All rights reserved. Licensed according to the terms of a BSD-style 
licence covering the Fast Imaging Library 
(see http://www.ncigt.org/pages/Downloads "Imaging Toolbox")


*/
