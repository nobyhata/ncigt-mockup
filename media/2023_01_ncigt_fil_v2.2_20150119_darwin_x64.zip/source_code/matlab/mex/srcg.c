/*

This is a MEX example to call the FIL CG SPACE RIP reconstruction code. 

I = srcg( W, k, Y, [ tau, maxits ] );

To compile, in Matlab call

  mex -I../../../include -L../../../lib -lpmri srcg.c

*/

#include <math.h>
#include "mex.h"
#include "stdio.h"

#include "igt_fil.h"
#include "grappa.h"


/* Input Arguments */
#define	W_IN	prhs[0]
#define	I_IN	prhs[1]
#define	Y_IN	prhs[2]
#define t_IN    prhs[3]
#define its_IN  prhs[4]

/* Output Arguments */
#define	K_OUT	plhs[0]

short  V=0;               /* 0 for verbose off */


void mexFunction( int nlhs, mxArray *plhs[], 
		  int nrhs, const mxArray*prhs[] )
     
{
  int n,m,cnt;
  COMPLEX *W,*I,*rho;
  float *PhaseLines;
  int Nlines;
  dataheader hdr;

  double  *tmpR,*tmpI;
  int szI, szY, szW;
  const int *dimI, *dimY, *dimW;
  int *sz;
  int flag = 0;

  double tau = 0;
  int its = 20;

  if (nrhs < 3) { 
    mexPrintf("At least 3 input arguments are required. (W:coil sensitivity,k:acquired data,Y:list of acquired phase encode lines)"); 
    return;
  } else if (nlhs > 1) {
    mexPrintf("Too many output arguments."); 
    return;
  } 

  tmpR = mxGetPr(W_IN);
  szW = mxGetNumberOfDimensions(W_IN);
  dimW = mxGetDimensions(W_IN);

  if ( !mxIsDouble(W_IN) || (szW != 3) ||
       !mxIsComplex(W_IN) ) {
    mexPrintf( "error with 1st input: Need to declare a complex M-by-N-by-L"
               " array for the coil sensitivity data.\n" );
    return;
  } else {
    hdr.Nvertical = (int) dimW[0];
    hdr.xres      = (int) dimW[1];
    hdr.Ncoils    = (int) dimW[2];

    tmpR = mxGetPr(W_IN);
    tmpI = mxGetPi(W_IN);

    W = (COMPLEX *) malloc( hdr.Nvertical * 
                               hdr.xres * 
                               hdr.Ncoils * sizeof(COMPLEX) );
    for (cnt=0;cnt<hdr.Nvertical * hdr.xres * hdr.Ncoils; cnt++) {
      W[cnt].re = (double) tmpR[cnt];
      W[cnt].im = (double) tmpI[cnt];
    } 
  }

  tmpR = mxGetPr(Y_IN);
  szY = mxGetNumberOfDimensions(Y_IN);
  dimY = mxGetDimensions(Y_IN);
  if ( !mxIsDouble(Y_IN) || (dimY[1] != 1) ||
       mxIsComplex(Y_IN) ) {
    mexPrintf( "error with 3rd input: Need to declare a real M-by-1"
               " array for the output data size\n" );
    return;
  } else {
    hdr.yres = (int) dimY[0];
    mexPrintf("input Y lines:\n");
    PhaseLines = (float*) malloc( (int)hdr.yres * sizeof(float) );
    for (cnt=0;cnt<hdr.yres;cnt++) {
      /* convert Matlab style indexing to C style (0 based) */
      PhaseLines[cnt] = (float) tmpR[cnt]-1;
      mexPrintf(" %3.0f",PhaseLines[cnt]); 
    }
    mexPrintf("\n");
  }


  tmpR = mxGetPr(I_IN);
  tmpI = mxGetPi(I_IN);
  szI  = mxGetNumberOfDimensions(I_IN);
  dimI = mxGetDimensions(I_IN);
  if ( !mxIsDouble(Y_IN) || (dimI[0] != hdr.yres) ||
       (dimI[1] != hdr.xres) || (dimI[2] != hdr.Ncoils) ) {
    mexPrintf( "error with 2nd input: Need to declare a complex M-by-N-L"
               " array for the input data.\n" );
    mexPrintf( "\t (in:[ %d %d %d ]) != (expected:[ %d %d %d ]) \n",
               dimI[0],dimI[1],dimI[2],
               hdr.yres,hdr.xres,hdr.Ncoils );
    return;
  } else {
    I = (COMPLEX *) malloc( hdr.yres * 
                               hdr.xres * 
                               hdr.Ncoils * sizeof(COMPLEX) );
    for (cnt=0;cnt<hdr.yres * hdr.xres * hdr.Ncoils; cnt++) {
      I[cnt].re = (double) tmpR[cnt];
      I[cnt].im = (double) tmpI[cnt];
    } 
  }

  /* copy over the lambda values */
  if (nrhs >= 4) { 
    
    szY = mxGetNumberOfDimensions(t_IN);
    dimY = mxGetDimensions(t_IN);
    if ( !mxIsDouble(t_IN) || (dimY[0] != 1) || (dimY[1] != 1) ||
         mxIsComplex(t_IN) || (szY > 2) ) {
      mexPrintf( "error with 4th input: Need to declare a real scalar"
                 " value for tau.\n" );
      return;
    }
    tmpR = mxGetPr(t_IN);
    tau = tmpR[0];
    
  } else {
    tau = 1e-3;
  }

  /* copy over the lambda values */
  if (nrhs >= 5) { 
    tmpR = mxGetPr(its_IN);
    its = (int) tmpR[0];
  } else {
    its = 20;
  }

  rho = (COMPLEX *) malloc( hdr.xres * hdr.Nvertical * sizeof(COMPLEX) );
  memset(rho,0, hdr.xres * hdr.Nvertical * sizeof(COMPLEX) );

  sprip_cgsr_recon( PhaseLines, /* list of phase encodes */
                    hdr.yres,   /* number of phase encodes used */
                    hdr.Nvertical, /* number of reconstructed samples along 
                                      phase encode direction */
                    hdr.xres,   /* number of samples along readout direction */
                    hdr.Ncoils, /* number of coils */
                    W,          /* coil sensitivity estimate in spatial
                                   domain of size ( N, M, L ) */
                    I,          /* acquired data in k-space domain of
                                   size ( P, M, L, nimgs ) */ 
                    tau,        /* array of regularization parameter.  values
                                   (if *lams == NULL, use the default) */
                    its,        /* the maximum number of iterations */
                    rho,        /* the reconstructed image(s). */
                    0
                    );

  sz = (int *) malloc( 3*sizeof(int) );

  sz[0] = hdr.Nvertical; 
  sz[1] = hdr.xres; 
  sz[2] = 1;                    /* number of images */

  K_OUT = mxCreateNumericArray( 3, sz, 
                                mxDOUBLE_CLASS,
                                mxCOMPLEX); 

  tmpR = mxGetPr(K_OUT);
  tmpI = mxGetPi(K_OUT);

  its = hdr.Nvertical * hdr.xres;
  for (cnt=0; cnt < its; cnt++) {
    tmpR[cnt] = rho[cnt].re;
    tmpI[cnt] = rho[cnt].im;
  }

  free(sz);
  free(W);
  free(I);
  free(rho);
  free(PhaseLines);

  return;
  
}
/*

Copyright 2009, National Center for Image Guided Therapy (NCIGT)

Written by W. Scott Hoge (shoge.harvard.edu) 

All rights reserved. Licensed according to the terms of a BSD-style 
licence covering the Fast Imaging Library 
(see http://www.ncigt.org/pages/Downloads "Imaging Toolbox")


*/
