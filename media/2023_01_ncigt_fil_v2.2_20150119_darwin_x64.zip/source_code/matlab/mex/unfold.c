/*

This is a MEX example to call the FIL UNFOLD temporal artifact suppression
code.

To compile, in Matlab call

  mex -I../../../include -L../../../lib -ligt_fil unfold.c

Usage:

[k,ny]=unfold( k_in );

k_in: k-space data, ky-kx-t or ky-kx-z-t or kx-ky-z-l-t
k:    filtered k-space data
ny:   the notch filter for Nyquist-rate alias suppression

*/

#include <math.h>
#include "mex.h"
#include "stdio.h"
#include "string.h"

#include "igt_fil.h"

/* Input Arguments */
#define	K_IN	 prhs[0]
#define FREQ_IN  prhs[1]
#define WIDTH_IN prhs[2]

/* Output Arguments */
#define	K_OUT	plhs[0]
#define NY_OUT  plhs[1]

short  V=0;               /* 0 for verbose off */


void mexFunction( int nlhs, mxArray *plhs[], 
		  int nrhs, const mxArray*prhs[] )
     
{
  int n,m,cnt,cntZ;
  COMPLEX *data_in,*full;
  SCAN_INFO hdr;
  char *str;
  char mode = 'h';

  fil_fft_mngr mngr;

  double  *tmpR,*tmpI,scl;
  int szK,prd;
  const int *dimK;
  int sz[6];

  float   *filter_dc;           /* UNFOLD filter, removes DC region (10%) */
  float   *filter_ny;           /* UNFOLD filter, removes Ny region (10%) */
  float   *filter_dckept;       /* UNFOLD filter, keeps DC region only (10%) */
  float   *filter_dcny;         /* UNFOLD filter, (filter_dc*filter_ny) */
  float   *fptr;
  short   *near_dc;             /* Frequencies around DC */
  short    filt_w;              /* Width of DC region, in near_dc */

  /* sanity: check that the number of inputs/outputs conform */
  if (nrhs < 1) { 
    mexPrintf("At least 1 input argument is required."); 
    return;
  } else if (nlhs > 2) {
    mexPrintf("Too many output arguments."); 
    return;
  } 
  /* pre: copy the data from Matlab arrays into C data structures */
  tmpR = mxGetPr(K_IN);
  tmpI = mxGetPi(K_IN);
  szK = mxGetNumberOfDimensions(K_IN);
  dimK = mxGetDimensions(K_IN);

  if ( !mxIsDouble(K_IN) || !mxIsComplex(K_IN) ) {
    mexPrintf( "1st input: Need to declare a complex "
               " array for the input k-space data\n" );
    return;
  } else {
    /* header variables that need to be populated */
    hdr.recon_filt = 0.1;         /* Width of UNFOLD filters, in frac of bw */
    /* default values */
    hdr.Nz_proc = 1;
    hdr.ncoils = 1;

    hdr.Ny_proc = dimK[0];
    hdr.Nx = dimK[1];
    if (szK == 2) {
      hdr.Ny_proc = 1;          /* number of temporal frames to process */
      hdr.Nf = dimK[1];
    } else if (szK == 3) {
      hdr.Nf = dimK[2];         /* number of temporal frames to process */
    } else if (szK == 4 ) {
      hdr.Nz_proc = dimK[2];
      hdr.Nf = dimK[3];         /* number of temporal frames to process */
    } else { /* (szK == 5 ) */
      hdr.Nz_proc = dimK[2];
      hdr.Nf = dimK[3];         /* number of temporal frames to process */
      hdr.ncoils = dimK[4];
    }  
    hdr.Nf_proc = set_nfproc(hdr.Nf, 0);

    /*
    printf("sz = ");
    for (cnt=0;cnt<szK;cnt++) {
      printf("%d ",dimK[cnt]);
    }
    */
    prd = hdr.Nf * hdr.Nz_proc * hdr.Ny_proc * hdr.Nx * hdr.ncoils;

    data_in = (COMPLEX *) malloc( prd * sizeof(COMPLEX) );

    /* mexPrintf("prd = %d\n",prd); */

    for (cnt=0;cnt<prd;cnt++) {
      data_in[cnt].re = tmpR[cnt];
      data_in[cnt].im = tmpI[cnt];
    }

  }
  /*
    sz[0] = hdr.Nx; sz[1] = hdr.Ny_proc; sz[2] = hdr.Nz_proc;
    sz[3] = hdr.ncoils; sz[4] = hdr.Nf;
    write_nd_data( "k_in.nd", data_in, "dblc", 5, sz );
  */
  
  if (nrhs > 1) {
    tmpR = mxGetPr(FREQ_IN);
    tmpI = mxGetPi(FREQ_IN);
    szK = mxGetNumberOfDimensions(FREQ_IN);
    dimK = mxGetDimensions(FREQ_IN);
    
    if ( !mxIsChar(FREQ_IN) ) {
      mexPrintf( "2nd input: Need to declare a char string "
                 " to select temporal filter: 'high', 'lowp', or 'midp' \n" );
      return;
    } else {
      str = mxArrayToString( FREQ_IN );
      mode = str[0];
    }
  }

  if (nrhs > 2) {
    tmpR = mxGetPr(WIDTH_IN);
    szK = mxGetNumberOfDimensions(WIDTH_IN);
    dimK = mxGetDimensions(WIDTH_IN);

    if ( !mxIsDouble(WIDTH_IN) || mxIsComplex(WIDTH_IN) ) {
      mexPrintf( "3rd input: Need to declare a real scalar "
                 " to define the passband/stopband width.\n" );
      return;
    } else {
      if ( ( tmpR[0] > 0 ) && (tmpR[0]<1) ) {
        /* Set width of UNFOLD filters, in frac of bw */
        hdr.recon_filt = tmpR[0];
      } else {
        mexPrintf("bandwidth input out-of-range. Using default value, %f, instead\n",hdr.recon_filt);
      }
    }
  }

  /* process: perform the data processing (i.e. call FIL functions) */

  filter_dc = (float *) malloc(hdr.Nf_proc*sizeof(float));
  filter_ny = (float *) malloc(hdr.Nf_proc*sizeof(float));
  filter_dckept = (float *) malloc(hdr.Nf_proc*sizeof(float));
  filter_dcny = (float *) malloc(hdr.Nf_proc*sizeof(float));
  near_dc = (short *) malloc(hdr.Nf_proc*sizeof(short));

  /* Create plans for a 1D FFT along the time (or frequency) axis */
  fft_mngr_init( &mngr );

  /* Set-up the unfold filters */
  setup_unfold( &hdr, hdr.Nf_proc, filter_dc, filter_ny, filter_dckept,
		filter_dcny,
                near_dc, &filt_w );


  full = (COMPLEX *) malloc( hdr.Nf_proc * hdr.Nz_proc * hdr.Ny_proc * hdr.Nx 
                             * hdr.ncoils * sizeof(COMPLEX) );

  synth_frames( hdr.ncoils, hdr.Nf, hdr.Nz_proc, hdr.Ny_proc, hdr.Nx,
                data_in, hdr.Nf_proc, full );

  /* FFT from time to temporal frequency domain, with plan ptf (forward) */
  fft_t( hdr.ncoils, hdr.Nf_proc, hdr.Nz_proc, hdr.Ny_proc, hdr.Nx,
         'f', &mngr, 0, full, full );

  if (mode == 'l') {
    /* Keep only the DC along temp. freq. domain */
    unfold_filter( hdr.ncoils, hdr.Nf_proc, hdr.Nz_proc, hdr.Ny_proc,
                   hdr.Nx, filter_dckept, full );
  } else if (mode == 'm') {
    /* Filter out DC and Nyquist region (temp. freq. domain) */
    unfold_filter( hdr.ncoils, hdr.Nf_proc, hdr.Nz_proc, hdr.Ny_proc,
                   hdr.Nx, filter_dcny, full );
  } else { /* (mode == 'h') */
    /* Filter out Nyquist region (temp. freq. domain) */
    unfold_filter( hdr.ncoils, hdr.Nf_proc, hdr.Nz_proc, hdr.Ny_proc,
                   hdr.Nx, filter_ny, full );
  }

  fft_t( hdr.ncoils, hdr.Nf_proc, hdr.Nz_proc, hdr.Ny_proc, hdr.Nx,
         'b', &mngr, 0, full, full );

  /* post: copy the output data from C data structures into Matlab arrays */
  sz[0] = hdr.Nx;
  sz[1] = hdr.Ny_proc;
  sz[2] = hdr.Nz_proc;
  sz[3] = hdr.Nf_proc;
  /*
    write_nd_data( "unf_out.nd", full, "dblc", 4, sz );
  */
  if (nlhs>0) {

    sz[0] = hdr.Ny_proc;
    sz[1] = hdr.Nx;

    szK = mxGetNumberOfDimensions(K_IN);
    if (szK == 2) {
      scl = 2;
      sz[1] = hdr.Nf;
    } else if (szK == 3) {
      scl = 3;
      sz[2] = hdr.Nf;
    } else if (szK == 4) {
      scl = 4;
      sz[2] = hdr.Nz_proc;
      sz[3] = hdr.Nf;
    } else if (szK == 5) {
      scl = 5;
      sz[2] = hdr.Nz_proc;
      sz[3] = hdr.Nf;
      sz[4] = hdr.ncoils;
    }
    K_OUT = mxCreateNumericArray( scl, sz, 
                                  mxDOUBLE_CLASS,
                                  mxCOMPLEX); 
    tmpR = mxGetPr(K_OUT);
    tmpI = mxGetPi(K_OUT);
    
    prd = hdr.Nz_proc * hdr.Ny_proc * hdr.Nx ;

    for (cntZ=0;cntZ<hdr.ncoils;cntZ++) {
      for (cnt=0;cnt<prd*hdr.Nf; cnt++) {
        tmpR[ cnt + cntZ*hdr.Nf*prd ] = 
          full[ cnt + cntZ*hdr.Nf_proc*prd ].re;
        tmpI[ cnt + cntZ*hdr.Nf*prd ] = 
          full[ cnt + cntZ*hdr.Nf_proc*prd ].im;
      }
    }

  }

  if (nlhs>1) {
    sz[1] = 1;
    sz[0] = hdr.Nf_proc;
    NY_OUT = mxCreateNumericArray( 2, sz, 
                                   mxDOUBLE_CLASS,
                                   mxREAL); 
    tmpR = mxGetPr(NY_OUT);
    tmpI = mxGetPi(NY_OUT);
    
    switch (mode) {
    case 'l':
      fptr = filter_dckept;
      break;
    case 'm':
      fptr = filter_dcny;
      break;
    case 'h':
      fptr = filter_ny;
      break;
    }

    for (cnt=0;cnt<hdr.Nf_proc; cnt++) {
      tmpR[cnt] = fptr[cnt];
    } 

  }
  /* ** END post: ** */

  free(filter_dc);
  free(filter_ny);
  free(filter_dckept);
  free(filter_dcny);
  free(near_dc);
  free(full);
  free(data_in);

  return;
  
}
/*

Copyright 2009, National Center for Image Guided Therapy (NCIGT)

Written by W. Scott Hoge (shoge -at- bwh.harvard.edu) 

All rights reserved. Licensed according to the terms of a BSD-style 
licence covering the Fast Imaging Library 
(see http://www.ncigt.org/pages/Downloads "Imaging Toolbox")


*/
