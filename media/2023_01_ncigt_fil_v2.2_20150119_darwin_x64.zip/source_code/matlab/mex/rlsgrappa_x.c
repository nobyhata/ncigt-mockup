/*

This is a MEX example to call the FIL GRAPPA reconstruction code.  

To compile, in Matlab call

  mex -I../../../include -L../../../lib -lpmri_util grappa.c

Usage:

[Fg,Ig]=grappa( size(W), k, Y(:) [, lambda ] );

size(W): the size of the output data matrix, Fg
k:  input data, in hybrid space, (ky,x,l)
Y:  a list of sampled phase-encode lines
lambda: the RLS forgetting factor

Fg: the reconstructed k-space
Ig: the root-sum-of-squares image derived from Fg

*/

#include <math.h>
#include "mex.h"
#include "stdio.h"

#include "igt_fil.h"
#include "grappa.h"

/* Input Arguments */
#define	W_IN	prhs[0]
#define	K_IN	prhs[1]
#define	Y_IN	prhs[2]
#define	L_IN	prhs[3]
/* #define kernel_IN prhs[3] */

/* Output Arguments */
#define	K_OUT	plhs[0]
#define	I_OUT	plhs[1]


short  V=0;               /* 0 for verbose off */


void mexFunction( int nlhs, mxArray *plhs[], 
		  int nrhs, const mxArray*prhs[] )
     
{
  int n,m,cnt,cnt1;
  COMPLEX *I,*O;
  int *PhaseLines;
  int Nlines;
  int *OutPhaseLines;
  dataheader hdr;
  int YKS, XKS;
  float radius;
  int ndk;
  int *dks_in;
  float lambda = 0.98;

  fil_fft_mngr mngr;

  double  *tmpR,*tmpI,scl;
  int szI, szY, szW,nel;
  const int *dimI, *dimY, *dimW;
  int sz[3];
  int flag = 0;

  if (nrhs < 3) { 
    mexPrintf("At least 3 input arguments are required."); 
    return;
  } else if (nlhs > 2) {
    mexPrintf("Too many output arguments."); 
    return;
  } 

  tmpR = mxGetPr(W_IN);
  szW = mxGetNumberOfDimensions(W_IN);
  dimW = mxGetDimensions(W_IN);

  if ( !mxIsDouble(W_IN) || (dimW[0] != 1) || (dimW[1] != 3) ||
       mxIsComplex(W_IN) ) {
    mexPrintf( "1st input: Need to declare a real 1-by-3"
               " array for the output data size\n" );
    return;
  } else {
    hdr.Nvertical = (int) tmpR[0];
    hdr.xres      = (int) tmpR[1];
    hdr.Ncoils    = (int) tmpR[2];
  }

  tmpR = mxGetPr(Y_IN);
  szY = mxGetNumberOfDimensions(Y_IN);
  dimY = mxGetDimensions(Y_IN);
  if ( !mxIsDouble(Y_IN) || (dimY[1] != 1) ||
       mxIsComplex(Y_IN) ) {
    mexPrintf( "3rd input: Need to declare a real M-by-1"
               " array for the output data size" );
    return;
  } else {
    hdr.yres = (int) dimY[0];
    mexPrintf("input Y lines:\n");
    PhaseLines = (int*) malloc( (int)hdr.yres * sizeof(int) );
    for (cnt=0;cnt<hdr.yres;cnt++) {
      /* convert indices from matlab (1 based) to C (0 based) */
      PhaseLines[cnt] = tmpR[cnt] - 1; 
      mexPrintf(" %d",PhaseLines[cnt]); 
    }
    mexPrintf("\n");
  }


  tmpR = mxGetPr(K_IN);
  tmpI = mxGetPi(K_IN);
  szI  = mxGetNumberOfDimensions(K_IN);
  dimI = mxGetDimensions(K_IN);
  if ( !mxIsDouble(Y_IN) || (dimI[0] != hdr.yres) ||
       (dimI[1] != hdr.xres) || (dimI[2] != hdr.Ncoils) ) {
    mexPrintf( "2nd input: Need to declare a complex M-by-N-L"
               " array for the input data.\n" );
    mexPrintf( "\t (in:[ %d %d %d ]) != (expected:[ %d %d %d ]) \n",
               dimI[0],dimI[1],dimI[2],
               hdr.yres,hdr.xres,hdr.Ncoils );
    return;
  } else {
    I = (COMPLEX *) malloc( hdr.yres * 
                            hdr.xres * 
                            hdr.Ncoils * sizeof(COMPLEX) );
    for (cnt=0;cnt<hdr.yres * hdr.xres * hdr.Ncoils; cnt++) {
      I[cnt].re = (double) tmpR[cnt];
      I[cnt].im = (double) tmpI[cnt];
    } 
  }

  if (nrhs > 3) { 
    tmpR = mxGetPr(L_IN);
    szI  = mxGetNumberOfDimensions(L_IN);
    dimI = mxGetDimensions(L_IN);
    if ( !mxIsDouble(L_IN) || (dimI[0] != 1) || (dimI[1] !=1) ) {
      mexPrintf( "4th input: Need to declare a scalar value for the"
                 " RLS forgetting factor.\n" );
      mexPrintf( " size(arg4): [ %d %d ]\n",dimI[0],dimI[1]);
      return;
    } else {
      lambda = (float) tmpR[0];
    }
    
  }

  O = (COMPLEX *) calloc( hdr.xres*hdr.Nvertical*hdr.Ncoils, sizeof(COMPLEX) );

  rlsgrappa( I, PhaseLines, &hdr, O, &Nlines, &OutPhaseLines,
             2,              /* use a 2-ky-point kernel by default */
             (float) 1.0,    /* reconstruct all points along readout dim */
             0, NULL,        /* tell the library to compute all dk gaps */
             lambda );

  fft_mngr_init( &mngr );

  ffty( hdr.Ncoils, 1, 1, hdr.xres, hdr.Nvertical, 
        'f', &mngr, 0, O );


  if (nlhs>0) {
    sz[0] = hdr.Nvertical; 
    sz[1] = hdr.xres; 
    sz[2] = hdr.Ncoils; 
    
    K_OUT = mxCreateNumericArray( 3, sz, 
                                  mxDOUBLE_CLASS,
                                  mxCOMPLEX); 
    tmpR = mxGetPr(K_OUT);
    tmpI = mxGetPi(K_OUT);
    
    for (cnt=0;cnt<hdr.Nvertical * hdr.xres * hdr.Ncoils; cnt++) {
      tmpR[cnt] = O[cnt].re;
      tmpI[cnt] = O[cnt].im;
    } 
  }

  if (nlhs>1) {

    fft_mngr_init( &mngr );

    for (cnt1=0;cnt1<hdr.Ncoils; cnt1++) {
        fil_fft_shift( ( O + cnt1*hdr.Nvertical*hdr.xres ), hdr.xres, hdr.Nvertical );

        fil_2dfft( &mngr, hdr.Nvertical, hdr.xres, ( O + cnt1*hdr.Nvertical*hdr.xres ), 'b' ); 
    }
    fft_mngr_quit( &mngr );

    /* Because of the 2dfft, scale the data here to match with Matlab */
    scl = hdr.xres*hdr.Nvertical;
    for (cnt1=0; cnt1 < hdr.Ncoils*hdr.Nvertical*hdr.xres; cnt1++) {
      O[cnt1].re = O[cnt1].re / scl;
      O[cnt1].im = O[cnt1].im / scl;
    }
    

    sz[0] = hdr.Nvertical; 
    sz[1] = hdr.xres; 
    /* 
       sz[2] = hdr.Ncoils;
       write_nd_data("Ig2.nd",O,"dblc",3,sz);
    */

    I_OUT = mxCreateNumericArray( 2, sz, 
                                  mxDOUBLE_CLASS,
                                  mxCOMPLEX); 
    tmpR = mxGetPr(I_OUT);
    tmpI = mxGetPi(I_OUT);

    nel = (int) hdr.Nvertical * hdr.xres;
    for (cnt=0;cnt<nel; cnt++) {
      scl = 0;
      for (cnt1=0;cnt1<hdr.Ncoils;cnt1++) {

        scl = scl + ( O[cnt + cnt1*nel ].re * O[cnt + cnt1*nel ].re +
                      O[cnt + cnt1*nel ].im * O[cnt + cnt1*nel ].im );
      }
      tmpR[cnt] = sqrt(scl);
      tmpI[cnt] = 0;
    } 

  }
  free(O);
  free(I);
  free(PhaseLines);

  return;
  
}
/*

Copyright 2009, National Center for Image Guided Therapy (NCIGT)

Written by W. Scott Hoge (shoge.harvard.edu) 

All rights reserved. Licensed according to the terms of a BSD-style 
licence covering the Fast Imaging Library 
(see http://www.ncigt.org/pages/Downloads "Imaging Toolbox")


*/
