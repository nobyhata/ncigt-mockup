% [F,I,N] = grappa( sz, k, Y, [ kernel, dks, N ] );
%
% sz - a 1x3 vector holding to final reconstructed k-space size,
%      e.g. sz = [ n m l ],
% k - acquired k-space data, size: p-by-n-by-l
% Y - column vector of phase encode line indices
%
% optional:
%   kernel  - a 3-char string that defines the grappa kernel size
%             default: '2x5'
%   dks     - an array declaring the (delta k) gaps to reconstruct.
%             defatul: all, as determined by Y.  
%             example: "[ 2, 3 ]" will only reconstruct gaps of size
%                      (delta k) == 2 and (delta k) == 3
%   N       - precalculated GRAPPA recon parameters
%

%
% Copyright 2009, National Center for Image Guided Therapy (NCIGT)
% 
% Written by W. Scott Hoge (shoge.harvard.edu) 
% 
% All rights reserved. Licensed according to the terms of a BSD-style 
% licence covering the Fast Imaging Library 
% (see http://www.ncigt.org/pages/Downloads "Imaging Toolbox")
% 
% 
% 