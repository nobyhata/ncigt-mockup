/*

This is a MEX example to call the FIL SENSE reconstruction code. 

I = sense( W, s, accel, [ thresh ] );

To compile, in Matlab call

  mex -I../../../include -L../../../lib -ligt_fil -lpthread sense.c

*/

#include <math.h>
#include "mex.h"
#include "stdio.h"

#include "igt_fil.h"

#ifdef EXECTIME
#include "sys/time.h"
#endif


/* Input Arguments */
#define	W_IN	prhs[0]
#define	S_IN	prhs[1]
#define	r_IN	prhs[2]
#define t_IN    prhs[3]

/* Output Arguments */
#define	K_OUT	plhs[0]
#define	U_OUT	plhs[1]

short  V=1;               /* 0 for verbose off */



void mexFunction( int nlhs, mxArray *plhs[], 
		  int nrhs, const mxArray*prhs[] )
     
{
  int n,m,cnt,cnt2;
  COMPLEX *W=NULL,*S=NULL,*rho=NULL;
  int ncoil_in;
  short Nx, Ny, Nz, Nf, yres, ncoils;

  double  *tmpR,*tmpI;
  int szS, szW, szY;
  const int *dimS, *dimW, *dimY;
  int *sz;

  float thresh = 1.2e7;
  DATATYPE *Uarray = NULL;

  XCOORD *alias = NULL;

  int accel=0;

#ifdef EXECTIME
  struct timeval tv;
  struct timezone tz;
  double prevtime;
  double tmptime;
#endif

  if (nrhs < 3) { 
    mexPrintf("At least 3 input arguments are required. (W:coil sensitivity, s:zero-padded spatial domain (aliased) data, accel:acceleration factor)"); 
    return;
  } else if (nlhs > 2) {
    mexPrintf("Too many output arguments."); 
    return;
  } 

  tmpR = mxGetPr(W_IN);
  szW  = mxGetNumberOfDimensions(W_IN);
  dimW = mxGetDimensions(W_IN);

  if ( !mxIsDouble(W_IN) || (szW != 3) ||
       !mxIsComplex(W_IN) ) {
    mexPrintf( "error with 1st input: Need to declare a complex Nx-by-Ny-by-L"
               " array for the coil sensitivity data.\n" );
    return;
  } else {
    Nx      = (int) dimW[0];
    Ny      = (int) dimW[1];
    ncoils  = (int) dimW[2];
    Nz      = 1;

    tmpR = mxGetPr(W_IN);
    tmpI = mxGetPi(W_IN);

    W = (COMPLEX *) malloc( Nx*Ny*ncoils*sizeof(COMPLEX) );
    for (cnt=0;cnt<Nx*Ny*ncoils; cnt++) {
      W[cnt].re = (DATATYPE) tmpR[cnt];
      W[cnt].im = (DATATYPE) tmpI[cnt];
    } 
#ifdef DEBUG
    mexPrintf("Successfully read coil sensitivities. size=[%d %d %d]\n",
              Nx,Ny,ncoils);
#endif
  }

  tmpR = mxGetPr(S_IN);
  tmpI = mxGetPi(S_IN);
  szS  = mxGetNumberOfDimensions(S_IN);
  dimS = mxGetDimensions(S_IN);
  if (szS == 4) {
    Nf      = (int) dimS[2];
    ncoil_in  = (int) dimS[3];
  } else {
    Nf      = 1;
    ncoil_in  = (int) dimS[2];
  }

  if ( !mxIsDouble(S_IN) || (dimS[0] != Nx) || !mxIsComplex(S_IN) ||
       (dimS[1] != Ny) || (ncoil_in != ncoils) ) {
    mexPrintf( "error with 2nd input: Need to declare a complex Nx-by-Ny-by-L"
               " or Nx-by-Ny-by-Nf-by-L array for the input data.\n" );
    mexPrintf( "\t (in:[ %d %d %d %d ] cmplx:%d) != "
               "(expected:[ %d %d %d %d] cmplx:1) \n",
               dimS[0],dimS[1],dimS[2],Nf, mxIsComplex(S_IN),
               Nx,Ny,ncoils,Nf );
    
    return;
  } else {
    S = (COMPLEX *) malloc( Nx*Ny*Nf*ncoils*sizeof(COMPLEX) );
    for (cnt=0;cnt< Ny*Nx*Nf*ncoils; cnt++) {
      S[cnt].re = (DATATYPE) tmpR[cnt];
      S[cnt].im = (DATATYPE) tmpI[cnt];
    } 
#ifdef DEBUG
    mexPrintf("Successfully read spatial domain data. size=[%d %d %d %d]\n",
              Nx,Ny,Nf,ncoils);
#endif
  }

  tmpR = mxGetPr(r_IN);
  accel = (int) tmpR[0]; 
  mexPrintf("accel = %d\n",accel);

  if (nrhs > 3) { 
    tmpR = mxGetPr(t_IN);
    thresh = (float) tmpR[0];
    mexPrintf("threshold = %f\n",thresh);
  }

  Uarray = (DATATYPE *) malloc( 2*(Nz * Ny * Nx * ncoils) * sizeof(DATATYPE) );
  memset(Uarray,0,2*Nx*Ny*Nz*ncoils);

  alias  = (XCOORD *) malloc(accel*sizeof(XCOORD));

  mexPrintf("alias: ");
  for ( cnt=0; cnt<accel; cnt++ ){
    alias[cnt].y = (float) cnt*Ny/accel;
    alias[cnt].z = 0;		
    mexPrintf(" %f ",alias[cnt].y);
  }
  mexPrintf("\n");


  rho = (COMPLEX *) malloc( Nx*Ny*Nf * sizeof(COMPLEX) );
  memset(rho,0, Nx*Ny*Nf * sizeof(COMPLEX) );

#ifdef EXECTIME
  gettimeofday(&tv,&tz);
  prevtime = tv.tv_sec*1000+tv.tv_usec/1000;
#endif


  vdsense_prep( Nx, Ny, Nz, ncoils,
                thresh, accel, alias, W, Uarray );

#ifdef EXECTIME
  gettimeofday(&tv,&tz);
  tmptime = tv.tv_sec*1000+tv.tv_usec/1000;
  printf("\t\tvdsense_prep time: %f msec\n",tmptime-prevtime);
  prevtime=tmptime;
#endif

  vdsense_apply( Nx, Ny, Nz, Nf, ncoils, 
                 S, Uarray, rho );

#ifdef EXECTIME
  gettimeofday(&tv,&tz);
  tmptime = tv.tv_sec*1000+tv.tv_usec/1000;
  printf("\t\tvdsense_apply time: %f msec\n",tmptime-prevtime);
  prevtime=tmptime;
#endif


  sz = (int *) malloc( 4*sizeof(int) );

  sz[0] = Nx;
  sz[1] = Ny;
  sz[2] = Nf;
#ifdef DEBUG
  write_nd_data( "rho_mex.nd", rho, "dblc", 3, sz );
#endif


  if (nlhs>0) {
    K_OUT = mxCreateNumericArray( 3, sz, 
                                  mxDOUBLE_CLASS,
                                  mxCOMPLEX);

    tmpR = mxGetPr(K_OUT);
    tmpI = mxGetPi(K_OUT);
    for (cnt=0; cnt < (Nx*Ny*Nf); cnt++) {
      tmpR[cnt] = (double) rho[cnt].re;
      tmpI[cnt] = (double) rho[cnt].im;
    }
  }

  sz[0] = ncoils;
  sz[1] = Nx;
  sz[2] = Ny;
  sz[3] = Nz;
#ifdef DEBUG
  write_nd_data( "Uarray_mex.nd", Uarray, "fltc", 4, sz );
#endif

  if (nlhs>1) {
    
    U_OUT = mxCreateNumericArray( 4, sz, 
                                  mxDOUBLE_CLASS,
                                  mxCOMPLEX);

    tmpR = mxGetPr(U_OUT);
    tmpI = mxGetPi(U_OUT);
    for (cnt=0,cnt2=0; cnt2 < (Nx*Ny*Nz*ncoils); cnt2++) {
      tmpR[cnt2] = (double) Uarray[cnt];
      cnt++;
      tmpI[cnt2] = (double) Uarray[cnt];
      cnt++;
    }
  }

  free(sz);
  if (W!=NULL) { free(W); }
  if (S!=NULL) { free(S); }
  if (rho!=NULL) { free(rho); }
  free(alias);
  free(Uarray);

  return;
  
}
/*

Copyright 2009, National Center for Image Guided Therapy (NCIGT)

Written by W. Scott Hoge (shoge.harvard.edu) 

All rights reserved. Licensed according to the terms of a BSD-style 
licence covering the Fast Imaging Library 
(see http://www.ncigt.org/pages/Downloads "Imaging Toolbox")


*/
