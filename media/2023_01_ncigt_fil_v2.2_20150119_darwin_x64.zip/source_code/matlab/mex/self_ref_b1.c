/*

This is a MEX example to call the FIL coil sensitivity estimation routine
based on the view sharing approach, SHRUG.

W = self_ref_b1( k );

The input, k, is assumed to be zero-padded (stretched) and in the order
Nx-Ny-Nz-Ncoil-Nt

To compile, in Matlab call

  mex -I../../../include -L../../../lib -ligt_fil self_ref_b1.c

*/

#include <math.h>
#include "mex.h"
#include "stdio.h"
#include "string.h"
#include "stdlib.h"

#include "igt_fil.h"


/* Input Arguments */
#define	K_IN	 prhs[0]
#define THRSH_IN prhs[1]

/* Output Arguments */
#define	W_OUT    plhs[0]

short  V=0;               /* 0 for verbose off */



void mexFunction( int nlhs, mxArray *plhs[], 
		  int nrhs, const mxArray*prhs[] )
     
{
  int n,m,cnt,cnt2,cnt3;
  COMPLEX *W,*K, *bufsp;
  KCOORD *kline_o, *kline_e;

  short Nx,Ny,Nz,ncoils,Nf;
  float b1snr_thr = 0.09;


  double  *tmpR,*tmpI;
  int szK, szY, szW, prd;
  const int *dimK, *dimY, *dimW;
  int sz[4];

  fil_fft_mngr mngr;

  float *filt_b1;
  float *samp_dens;

  if (nrhs < 1) { 
    mexPrintf("At least 1 input argument is required. (k:measured k-space)\n");
    return;
  } else if (nlhs > 1) {
    mexPrintf("Too many output arguments."); 
    return;
  } 


  if (nrhs > 1 ) {
    tmpR = mxGetPr(THRSH_IN);
    tmpI = mxGetPi(THRSH_IN);
    szK  = mxGetNumberOfDimensions(THRSH_IN);
    dimK = mxGetDimensions(THRSH_IN);
    if ( !mxIsDouble(K_IN) || (szK != 2) || dimK[0] != 1 || dimK[1] != 1 ) {
      mexPrintf( "error with 2nd input: Need to declare a scalar value "
                 " for the B1 SNR threshold.\n" );
      mexPrintf( "\t (in:[ %d %d ]) \n",
                 dimK[0],dimK[1]);
      return;
    } else {
      b1snr_thr = tmpR[0];
    }
  }
  
  tmpR = mxGetPr(K_IN);
  tmpI = mxGetPi(K_IN);
  szK  = mxGetNumberOfDimensions(K_IN);
  dimK = mxGetDimensions(K_IN);
  if ( !mxIsComplex(K_IN) ) { 
    mexPrintf( "error with 1st input: Need to declare a complex Nx-Ny-Nz-Nt-Ncoils"
               " array for the input data.\n" );
    mexPrintf( "\t (in:[ %d %d %d %d %d ]) \n",
               dimK[0],dimK[1],dimK[2],dimK[3],dimK[4] );
    return;
  } else {
    Ny = (int) dimK[0];
    Nx = (int) dimK[1];
    Nz = (int) dimK[2];
    ncoils  = (int) dimK[3];
    if (szK>4)
      Nf = (int) dimK[4];
    else
      Nf = 1;

    mexPrintf( "\t (in:[ %d %d %d %d %d ]) \n",
               dimK[0],dimK[1],dimK[2],dimK[3],dimK[4] );

    prd = Nx*Ny*Nz*Nf*ncoils;

    K = (COMPLEX *) malloc( prd * sizeof(COMPLEX) );
    for (cnt=0;cnt<prd; cnt++) {
      K[cnt].re = (double) tmpR[cnt];
      K[cnt].im = (double) tmpI[cnt];
    } 
  }

  /*
    sz[0] = hdr.yres;  sz[1] = hdr.xres;  sz[2] = hdr.Ncoils;
    write_nd_data("k_in.nd",K,"dblc",3,sz);
  */

  W =  (COMPLEX *) malloc( Nx * Ny * Nz * ncoils * sizeof(COMPLEX) );

  fft_mngr_init( &mngr );

  self_ref_b1_basic( K, 0.09, Ny, Nx, Nz, ncoils, Nf, &mngr, W );

  fft_mngr_quit( &mngr );

  /*
    sz[0] = hdr.Nx;  sz[1] = hdr.Ny_proc;  sz[2] = hdr.ncoils;
    write_nd_data("w_out.nd",W,"dblc",3,sz);
  */

  if (nlhs>0) {

    sz[0] = (int) Ny;
    sz[1] = (int) Nx; 
    sz[2] = (int) Nz;
    sz[3] = (int) ncoils;
  
    W_OUT = mxCreateNumericArray( 4, sz, 
                                  mxDOUBLE_CLASS,
                                  mxCOMPLEX); 
    
    tmpR = mxGetPr(W_OUT);
    tmpI = mxGetPi(W_OUT);
    
    for (cnt=0; cnt < Nx*Ny*ncoils; cnt++) {
      tmpR[cnt] = W[cnt].re;
      tmpI[cnt] = W[cnt].im;
    }
  }

  free(W);
  free(K);
  
  return;
  
}
/*

Copyright 2009, National Center for Image Guided Therapy (NCIGT)

Written by W. Scott Hoge (shoge.harvard.edu) 

All rights reserved. Licensed according to the terms of a BSD-style 
licence covering the Fast Imaging Library 
(see http://www.ncigt.org/pages/Downloads "Imaging Toolbox")


*/
