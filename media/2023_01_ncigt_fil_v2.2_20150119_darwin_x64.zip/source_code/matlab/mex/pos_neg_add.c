/*

This is a MEX example to call the FIL image phase alignment code.  

To compile, in Matlab call

  mex -I../../../include -L../../../lib -ligt_fil pos_neg_add.c

Usage:

C = pos_neg_add( P, N );

P: images associated with the data acquired on positive EPI readout gradients
N: images associated with the data acquired on negative EPI readout gradients

C: the output images, formed by phase-aligning N with P and summing.

*/

#include <math.h>
#include "mex.h"
#include "stdio.h"

#include "igt_fil.h"

/* Input Arguments */
#define	P_IN	prhs[0]
#define	N_IN	prhs[1]

/* Output Arguments */
#define	C_OUT	plhs[0]
#define	P_OUT	plhs[1]
#define	N_OUT	plhs[2]

#define TNUM 8

short  V=0;               /* 0 for verbose off */

void mexFunction( int nlhs, mxArray *plhs[], 
		  int nrhs, const mxArray*prhs[] )
     
{
  COMPLEX *P,*N,*C;
  int sz[3];
  int cnt, Nx, Ny, dim3, dim3n;

  double  *tmpR,*tmpI,scl;
  int      szP,szN;
  const int *dimP, *dimN;

  if (nrhs != 2) { 
    mexPrintf("2 (and only 2) input arguments are required."); 
    return;
  } 

  tmpR = mxGetPr(P_IN);
  tmpI = mxGetPi(P_IN);
  szP  = mxGetNumberOfDimensions(P_IN);
  dimP = mxGetDimensions(P_IN);
  if ( !mxIsDouble(P_IN) || !mxIsComplex(P_IN) || (szP < 2) ) { 
    mexPrintf( "1st input: Need to declare a complex array of at least 2 dimensions for the first input.\n" ); 
    mexPrintf( "\t (in:[ %d %d ... ]) \n",
               dimP[0],dimP[1] );
    return;
  } else {
    dim3 = 1;
    Nx = dimP[0]; Ny = dimP[1];
    for (cnt=2;cnt<szP;cnt++) {
      dim3 *= dimP[cnt];
    }
    P = (COMPLEX *) malloc( Nx * Ny * dim3 * sizeof(COMPLEX) );
    for (cnt=0;cnt< Nx*Ny*dim3; cnt++) {
      P[cnt].re = (double) tmpR[cnt];
      P[cnt].im = (double) tmpI[cnt];
    } 
  }

  tmpR = mxGetPr(N_IN);
  tmpI = mxGetPi(N_IN);
  szN  = mxGetNumberOfDimensions(N_IN);
  dimN = mxGetDimensions(N_IN);
  if ( !mxIsDouble(N_IN) || !mxIsComplex(N_IN) || (szN < 2) ) { 
    mexPrintf( "2nd input: Need to declare a complex array of at least 2 dimensions for the second input.\n" ); 
    mexPrintf( "\t (in:[ %d %d ... ]) \n",
               dimN[0],dimN[1] );
    return;
  } else {
    dim3n = 1;
    for (cnt=2;cnt<szN;cnt++) {
      dim3n *= dimN[cnt];
    }
    if ( (Nx != dimN[0]) || (Ny != dimN[1]) || (dim3 != dim3n) ) {
      mexPrintf( "Error: the two inputs need to be the same size\n");
      mexPrintf( "\t (in1:[ %d %d %d ]) (in2:[ %d %d %d ]) \n",
                 dimP[0],dimP[1],dim3,
                 dimN[0],dimN[1],dim3n );
      return;
    }

    N = (COMPLEX *) malloc( Nx * Ny * dim3 * sizeof(COMPLEX) );
    for (cnt=0;cnt< Nx*Ny*dim3; cnt++) {
      N[cnt].re = (double) tmpR[cnt];
      N[cnt].im = (double) tmpI[cnt];
    } 
  }

  sz[0] = Nx; sz[1] = Ny; sz[2] = dim3;
  align_image_phase( P, N, 3, sz, NULL, NULL, TNUM, 0 );

  C = (COMPLEX *) malloc( Nx * Ny * dim3 * sizeof(COMPLEX) );
  
  for (cnt=0; cnt<Nx*Ny*dim3; cnt++) {
    C[cnt].re = P[cnt].re + N[cnt].re;
    C[cnt].im = P[cnt].im + N[cnt].im;
  }


  if (nlhs>0) {

    C_OUT = mxCreateNumericArray( szP, dimP, 
                                  mxDOUBLE_CLASS,
                                  mxCOMPLEX); 
    tmpR = mxGetPr(C_OUT);
    tmpI = mxGetPi(C_OUT);
    
    for (cnt=0;cnt<Nx*Ny*dim3; cnt++) {
      tmpR[cnt] = C[cnt].re;
      tmpI[cnt] = C[cnt].im;
    } 
    free(C);
  }

  if (nlhs>1) {

    P_OUT = mxCreateNumericArray( szP, dimP, 
                                  mxDOUBLE_CLASS,
                                  mxCOMPLEX); 
    tmpR = mxGetPr(P_OUT);
    tmpI = mxGetPi(P_OUT);
    
    for (cnt=0;cnt<Nx*Ny*dim3; cnt++) {
      tmpR[cnt] = P[cnt].re;
      tmpI[cnt] = P[cnt].im;
    } 
  }
  if (nlhs>2) {

    N_OUT = mxCreateNumericArray( szN, dimN, 
                                  mxDOUBLE_CLASS,
                                  mxCOMPLEX); 
    tmpR = mxGetPr(N_OUT);
    tmpI = mxGetPi(N_OUT);
    
    for (cnt=0;cnt<Nx*Ny*dim3; cnt++) {
      tmpR[cnt] = N[cnt].re;
      tmpI[cnt] = N[cnt].im;
    } 
  }

  free(P); 
  free(N);

}

/*

Copyright 2009, National Center for Image Guided Therapy (NCIGT)

Written by W. Scott Hoge (shoge.harvard.edu) 

All rights reserved. Licensed according to the terms of a BSD-style 
licence covering the Fast Imaging Library 
(see http://www.ncigt.org/pages/Downloads "Imaging Toolbox")


*/
