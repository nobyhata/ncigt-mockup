/*

This is a MEX example to call the FIL Nyquist ghost correction routine
based on GESTE.

Send two raw images in, get one or two reconstructed image back.

[ Ia, Ib, N ] = geste( A, B, I );

The coefficients, N, can  be used to construct other frames using GRAPPA


To compile, in Matlab call

  mex -I../../../include -L../../../lib -ligt_fil geyser.c

 */

#include <math.h>
#include "mex.h"
#include "stdio.h"

#include "igt_fil.h"

#include "geste.h"

/* Input Arguments */
#define	A_IN	prhs[0]
#define	B_IN	prhs[1]
#define I_IN	prhs[2]
#define N_IN    prhs[3]

/* Output Arguments */
#define	I_OUT	plhs[0]
#define	I2_OUT	plhs[1]
#define	N_OUT	plhs[2]

/* #define DEBUG_GESTE  */

short  V=0;               /* 0 for verbose off */

#define TNUM  8                 /* number of process threads to use */

void mexFunction( int nlhs, mxArray *plhs[], 
		  int nrhs, const mxArray*prhs[] )
     
{

  double  *tmpR,*tmpI;
  int szK, cnt;
  const int *dimK;
  int sz[4];

  char strout[20];

  DATA_OBJ even_frame; /**< raw input EPI data frame.  Even lines have
                           positive readout data */
  DATA_OBJ odd_frame;  /**< raw input EPI data frame.  Odd lines have
                           positive readout data */
  DATA_OBJ *raw_frame = NULL;  /**< raw input EPI data frame, the frame to reconstruct.  
                                  Could be equal to either even_frame or odd_frame */ 
  DATA_OBJ  img;   /**< reconstructed image, from raw_frame data */
  DATA_OBJ  img2;  /**< reconstructed image, from raw_frame data */
  GESTE_MEM mem;   /**< memory buffer object.  */

  DATA_OBJ combo, gparm_arr;
  COMPLEX  *C, *tmpc;  
  float *phase_list = NULL;

  int npattern, nslices, ncoils; 

  GRAPPA_OBJ  **gobj_array;
  const char *fieldnames[] = {"dk","pattern","coef"};
  int dk_field, pattern_field, coef_field;
  mxArray *field_value;
  int pcnt,cnt1,cnt2,iindx,oindx;
  dataheader hdr;

#ifdef DEBUG_GESTE
  char fname[20];
#endif

  int nEl;
  /* do we need verify that frame1 and frame2 are the same size? */

  if (nrhs < 2) { 
    mexPrintf("At least 3 input arguments are required. (k:measured k-space, Y: associated list of acquired phase encode lines, sz: size of output coil maps)"); 
    return;
  } else if (nlhs > 3) {
    mexPrintf("Too many output arguments."); 
    return;
  } 

  /**********************************************************************/
  /* initialize the data memory */

  tmpR = mxGetPr(A_IN);
  tmpI = mxGetPi(A_IN);
  szK  = mxGetNumberOfDimensions(A_IN);
  dimK = mxGetDimensions(A_IN);
  if ( !mxIsDouble(A_IN) || (szK < 3) ) {
    mexPrintf( "error with 1st input: Need to declare a complex M-by-N-by-...-by-L"
               " array for the input data.\n" );
    mexPrintf( "\t (in:[ %d %d %d %d ]) \n",
               dimK[0],dimK[1],dimK[2],dimK[3] );
    return;
  } else {
    even_frame.ndim = 4;
    even_frame.sz[0] = dimK[0];
    even_frame.sz[1] = dimK[1];
    even_frame.sz[2] = 1;
    for (cnt=2;cnt<(szK-1);cnt++) {
      even_frame.sz[cnt] *= dimK[cnt];
    }
    even_frame.sz[3] = dimK[cnt];
    nEl = even_frame.sz[0]*even_frame.sz[1]*even_frame.sz[2]*even_frame.sz[3];
    
    even_frame.data = malloc( nEl * sizeof(COMPLEX) );
    tmpc = (COMPLEX *) even_frame.data;
    for (cnt=0;cnt<nEl; cnt++) {
      tmpc[cnt].re = (double) tmpR[cnt];
      tmpc[cnt].im = (double) tmpI[cnt];
    }
    even_frame.init = 1;
    strcpy( even_frame.type, "dblc" );
    even_frame.metadata = NULL;
    even_frame.metalength = 0;
  }


  tmpR = mxGetPr(B_IN);
  tmpI = mxGetPi(B_IN);
  szK  = mxGetNumberOfDimensions(B_IN);
  dimK = mxGetDimensions(B_IN);
  if ( !mxIsDouble(B_IN) || (szK < 3) ) {
    mexPrintf( "error with 2nd input: Need to declare a complex M-by-N-by-...-by-L"
               " array for the input data.\n" );
    mexPrintf( "\t (in:[ %d %d %d %d ]) \n",
               dimK[0],dimK[1],dimK[2],dimK[3] );
    return;
  } else {
    odd_frame.ndim = 4;
    odd_frame.sz[0] = dimK[0];
    odd_frame.sz[1] = dimK[1];
    odd_frame.sz[2] = 1;
    for (cnt=2;cnt<(szK-1);cnt++) {
      odd_frame.sz[cnt] *= dimK[cnt];
    }
    odd_frame.sz[3] = dimK[cnt];
    nEl = odd_frame.sz[0]*odd_frame.sz[1]*odd_frame.sz[2]*odd_frame.sz[3];
    
    odd_frame.data = malloc( nEl * sizeof(COMPLEX) );
    tmpc = (COMPLEX *) odd_frame.data;
    for (cnt=0; cnt<nEl; cnt++) {
      tmpc[cnt].re = (double) tmpR[cnt];
      tmpc[cnt].im = (double) tmpI[cnt];
    }
    odd_frame.init = 1;
    strcpy( odd_frame.type, "dblc" );
    odd_frame.metadata = NULL;
    odd_frame.metalength = 0;
  }

#ifdef DEBUG_GESTE
  sprintf(strout,"[ ");
#endif
  for (cnt=0;cnt<odd_frame.ndim;cnt++) {
    if ( odd_frame.sz[cnt] != even_frame.sz[cnt] ){
      mexPrintf("Error: input matrix size mismatch - A: [ %s %d ... ] vs B: [ %s %d ... ]\n", strout, even_frame.sz[cnt], strout, odd_frame.sz[cnt]);
      return;

    }
#ifdef DEBUG_GESTE
    sprintf(strout,"%s %d ",strout,odd_frame.sz[cnt]);
#endif
  }
#ifdef DEBUG_GESTE
  sprintf(strout,"%s ]",strout);
  mexPrintf("sz: %s\n",strout);
#endif

  nEl = even_frame.sz[0]*even_frame.sz[1]*even_frame.sz[2]*even_frame.sz[3];

  C      = (COMPLEX *) calloc( nEl, sizeof(COMPLEX) );
  combo.data = (char *) C;
  strcpy( combo.type, "dblc" );  
  combo.ndim  = 4;
  combo.sz[0] = even_frame.sz[0];
  combo.sz[1] = even_frame.sz[1];
  combo.sz[2] = even_frame.sz[2];
  combo.sz[3] = even_frame.sz[3];
  combo.init  = 1;


  geste_init( &mem, &even_frame );


  geste_interleave_frames( &even_frame, &odd_frame, &combo, 0, &mem );
#ifdef DEBUG_GESTE
  write_nd_data("C.nd",C,"dblc",combo.ndim,combo.sz);
#endif

  nslices = combo.sz[2];
  ncoils  = combo.sz[3];

  geste_calibrate__all_slices( &combo, phase_list, &mem );

  img.data = (char *) calloc( nEl, sizeof(COMPLEX) );
  strcpy( img.type, "dblc" );  
  img.ndim  = 4;
  img.sz[0] = even_frame.sz[0];
  img.sz[1] = even_frame.sz[1];
  img.sz[2] = even_frame.sz[2];
  img.sz[3] = even_frame.sz[3];
  img.init  = 1;

  if (nrhs>2) {
    tmpR = mxGetPr(I_IN);
    tmpI = mxGetPi(I_IN);
    szK  = mxGetNumberOfDimensions(I_IN);
    dimK = mxGetDimensions(I_IN);
    if ( !mxIsDouble(I_IN) || (szK != 4) ) {
      mexPrintf( "error with 3nd input: Need to declare a complex M-by-N-by-Z-by-L"
                 " array for the input data.\n" );
      mexPrintf( "\t (in:[ %d %d %d %d ]) \n",
                 dimK[0],dimK[1],dimK[2],dimK[3] );
      return;
    } else {
      raw_frame = (DATA_OBJ *) malloc( sizeof(DATA_OBJ) );

      raw_frame->ndim = 4;
      raw_frame->sz[0] = dimK[0];
      raw_frame->sz[1] = dimK[1];
      raw_frame->sz[2] = 1;
      for (cnt=2;cnt<(szK-1);cnt++) {
        raw_frame->sz[cnt] *= dimK[cnt];
      }
      raw_frame->sz[3] = dimK[cnt];
      nEl = raw_frame->sz[0]*raw_frame->sz[1]*raw_frame->sz[2]*raw_frame->sz[3];

      raw_frame->data = malloc( nEl * sizeof(COMPLEX) );
      tmpc = (COMPLEX *) raw_frame->data;
      for (cnt=0; cnt<nEl; cnt++) {
        tmpc[cnt].re = (double) tmpR[cnt];
        tmpc[cnt].im = (double) tmpI[cnt];
      }
      raw_frame->init = 1;
      strcpy( raw_frame->type, "dblc" );
    }
  } else {
    raw_frame = &odd_frame;
  }


  if (nlhs>0) {

  geste_recon__all_slices( raw_frame, 
                           phase_list, 
                           &img,
                           &mem,
                           0
                           );


#ifdef DEBUG_GESTE
  write_nd_data("I.nd",(void*)img.data,"dblc",combo.ndim,combo.sz);
  mexPrintf("\n");
#endif

    I_OUT = mxCreateNumericArray( img.ndim, img.sz, mxDOUBLE_CLASS, mxCOMPLEX); 
    tmpR = mxGetPr(I_OUT);
    tmpI = mxGetPi(I_OUT);
    tmpc = (COMPLEX*) img.data;
    nEl = 1; 
    for ( cnt=0; cnt< img.ndim; cnt++) {
      nEl *= img.sz[cnt];
    }    
    for ( cnt=0; cnt< nEl; cnt++) {
      tmpR[cnt] = tmpc[cnt].re;
      tmpI[cnt] = tmpc[cnt].im;
    } 

  }


  if (nlhs>1) {

    nEl = even_frame.sz[0]*even_frame.sz[1]*even_frame.sz[2]*even_frame.sz[3];

    img2.data = (char *) calloc( nEl, sizeof(COMPLEX) );
    strcpy( img2.type, "dblc" );  
    img2.ndim  = 4;
    img2.sz[0] = even_frame.sz[0];
    img2.sz[1] = even_frame.sz[1];
    img2.sz[2] = even_frame.sz[2];
    img2.sz[3] = even_frame.sz[3];
    img2.init  = 1;
    
    geste_recon__all_slices( &even_frame, 
                             phase_list, 
                             &img2,
                             &mem,
                             0
                             );


#ifdef DEBUG_GESTE
    write_nd_data("I2.nd",(void*)img2.data,"dblc",combo.ndim,combo.sz);
    mexPrintf("\n");
#endif

    /* correct for any shift along in kspace the readout direction
       between the two images */ 
    align_image_phase( (COMPLEX*)img.data, (COMPLEX*)img2.data, img.ndim, img.sz, NULL, NULL, TNUM, 0 );

    I2_OUT = mxCreateNumericArray( img.ndim, img.sz, mxDOUBLE_CLASS, mxCOMPLEX); 
    tmpR = mxGetPr(I2_OUT);
    tmpI = mxGetPi(I2_OUT);
    tmpc = (COMPLEX*) img2.data;
    nEl = 1; 
    for ( cnt=0; cnt< img.ndim; cnt++) {
      nEl *= img.sz[cnt];
    }    
    for ( cnt=0; cnt< nEl; cnt++) {
      tmpR[cnt] = tmpc[cnt].re;
      tmpI[cnt] = tmpc[cnt].im;
    } 

    free(img2.data);
  }

  if (nlhs>2) {
    npattern = 1;
    N_OUT = mxCreateStructMatrix( npattern, nslices, 3, fieldnames );

    dk_field      = mxGetFieldNumber( N_OUT, "dk" );
    pattern_field = mxGetFieldNumber( N_OUT, "pattern" );
    coef_field    = mxGetFieldNumber( N_OUT, "coef" );

    for (pcnt=0; pcnt<nslices; pcnt++) {
    gobj_array = mem.gparm[pcnt]->parray;
    for(cnt2=0;cnt2<mem.gparm[pcnt]->ndk;cnt2++){
      iindx = mem.gparm[pcnt]->dks[cnt2]; /* size of delta-k gap for these coefficients  */
      
      oindx = (mem.gparm[pcnt]->YKS-1)*(iindx-1); /* number of patterns used for this gap size */
      for(cnt1=0;cnt1<oindx;cnt1++){
        /* set the dk value for this set of coefficients */
        field_value = mxCreateDoubleMatrix(1,1,mxREAL);
        tmpR = mxGetPr(field_value);
        tmpR[0] = iindx;
        mxSetFieldByNumber(N_OUT,pcnt,dk_field,field_value);

        /* set the pattern for this set of coefficients */
        mxSetFieldByNumber(N_OUT,pcnt,pattern_field,mxCreateString(gobj_array[cnt2][cnt1].pattern));

        /* copy the coefficients over to the output buffer */
        field_value = mxCreateDoubleMatrix( mem.gparm[pcnt]->XKS*mem.gparm[pcnt]->YKS*ncoils, ncoils, mxCOMPLEX);
        tmpR = mxGetPr(field_value);
        tmpI = mxGetPi(field_value);
        for (cnt=0;cnt<mem.gparm[pcnt]->XKS*mem.gparm[pcnt]->YKS*ncoils*ncoils; cnt++) {
          tmpR[cnt] = gobj_array[cnt2][cnt1].N[cnt].re;
          tmpI[cnt] = gobj_array[cnt2][cnt1].N[cnt].im;
        }
        mxSetFieldByNumber(N_OUT,pcnt,coef_field,field_value);

      }
    }
    }
  }

  geste_quit( &mem );

  free(C);
  free(img.data);
  free(even_frame.data);
  free(odd_frame.data);
  if ( (nrhs>2) && (raw_frame != NULL) ) {
    free(raw_frame);
  }

  return;
}
/*

Copyright 2010, National Center for Image Guided Therapy (NCIGT)

Written by W. Scott Hoge (shoge.harvard.edu) 

All rights reserved. Licensed according to the terms of a BSD-style 
licence covering the Fast Imaging Library 
(see http://www.ncigt.org/pages/Downloads "Imaging Toolbox")

*/
