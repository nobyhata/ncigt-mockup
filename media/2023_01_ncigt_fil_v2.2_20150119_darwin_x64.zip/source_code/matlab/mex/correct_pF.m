% Usage:  [ I, W ] = correct_pF( k, [sz, ftype] );
%
% Inputs: 
%  k     - input kspace data, of size [ N P ]
%          N : length along readout direction
%          P : number of phase encodes
%
% This function assumes that the zero-frequency center of k-space
% will appear in the higher indices of the input data matrix
%
% (optional inputs):
%  sz    - length of image along phase encode direction to expand to 
%  ftype - filter type.  ftype=0 : a stair-step weighting function 
%                                  (better SNR)
%                        ftype=1 : a ramp weighting function 
%                                  (better of off-center k-space data)
%
% Outputs:
%  I     - the reconstructed image
%  W     - the weighting envelope applied to the zero-padded kspace data
%

% Copyright 2009, National Center for Image Guided Therapy (NCIGT)
% 
% Written by W. Scott Hoge (shoge.harvard.edu) 
% 
% All rights reserved. Licensed according to the terms of a BSD-style 
% licence covering the Fast Imaging Library 
% (see http://www.ncigt.org/pages/Downloads "Imaging Toolbox")
% 
% 
% 