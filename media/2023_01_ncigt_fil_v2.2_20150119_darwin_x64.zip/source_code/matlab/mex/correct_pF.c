/*

This is a MEX example to call the FIL partial-Fourier correction routines

k0 = correct_pF( k, [sz, ftype] );

Note: this example only demonstrates simple 2D data sets.  The FIL
functions are designed for 4D data.


To compile, in Matlab call

  mex -I../../../include -L../../../lib -ligt_fil correct_pF.c

*/

#include <math.h>
#include "mex.h"
#include "stdio.h"

#include "igt_fil.h"


/* Input Arguments */
#define	K_IN	prhs[0]
#define SZ_IN   prhs[1]
#define FTYPE_IN   prhs[2]

/* Output Arguments */
#define	K_OUT	plhs[0]
#define	w_OUT	plhs[1]

short  V=0;               /* 0 for verbose off */


void mexFunction( int nlhs, mxArray *plhs[], 
		  int nrhs, const mxArray*prhs[] )
     
{
  int n,m,cnt,cnt2,cnt3,indx;
  COMPLEX *K,*K_out,*phase_ref;

  SCAN_INFO hdr;
  KCOORD *kline;
  float *samp_dens, *filt_pF, *weight_pF, *testp;
  float tmp;

  /* Matlab2C variables */
  double  *tmpR,*tmpI;
  int szK, szY, szW;
  const int *dimK, *dimY, *dimW;
  int sz[4];
  int filt_type=0;

  fil_fft_mngr mngr;


  if (nrhs < 2) { 
    mexPrintf("At least 2 input arguments are required. (k:measured k-space, output size)\n");
    return;
  } else if (nlhs > 2) {
    mexPrintf("Too many output arguments."); 
    return;
  } 

  tmpR = mxGetPr(K_IN);
  tmpI = mxGetPi(K_IN);
  szK  = mxGetNumberOfDimensions(K_IN);
  dimK = mxGetDimensions(K_IN);
  if ( !mxIsDouble(K_IN) || (szK != 2) ) {
    mexPrintf( "error with 1st input: Need to declare a complex M-by-N-by-L"
               " array for the input data.\n" );
    mexPrintf( "\t (in:[ %d %d %d ]) != (expected:[ %d ?? ?? ]) \n",
               dimK[0],dimK[1],dimK[2],
               hdr.N_acq );
    return;
  } else {
    hdr.N_acq = (int) dimK[1];
    hdr.Nx = (int) dimK[0];
    hdr.Ny = (int) hdr.Nx;
    hdr.Ny_proc = (int) hdr.Nx;

    if (V)
      mexPrintf(" N_acq=%d  Nx=%d  Ny=%d \n",hdr.N_acq,hdr.Nx,hdr.Ny);

    /* next two are needed by setup_pF */
    hdr.fill_fac = 1.0; 
    hdr.Nz_proc = 1;

    
    K = (COMPLEX *) malloc( hdr.N_acq * 
                            hdr.Nx * 
                            hdr.Nz_proc *
                            sizeof(COMPLEX) );

    for (cnt=0;cnt<hdr.N_acq * hdr.Nx * hdr.Nz_proc; cnt++) {
      K[cnt].re = (DATATYPE) tmpR[cnt];
      K[cnt].im = (DATATYPE) tmpI[cnt];
    } 
  }

  if (nrhs > 1) { 
    tmpR = mxGetPr(SZ_IN);
    szW = mxGetNumberOfDimensions(SZ_IN);
    dimW = mxGetDimensions(SZ_IN);
    
    if ( !mxIsDouble(SZ_IN) || (szW != 2) || ((int)tmpR[1]==0) ) {
      mexPrintf( "error with 2nd input: Need to declare a scalar"
                 " value for the final size of the expanded matrix size.\n" );
      return;
    } else {
      hdr.Ny = (int) tmpR[1];
      hdr.Ny_proc = (int) tmpR[1];
    }
  } else {
    hdr.Ny = hdr.Nx;
    hdr.Ny_proc = hdr.Nx;
  }
  if (hdr.Ny < hdr.N_acq) {
    mexPrintf( "error with 2nd input: the number of acquired points (%d)"
               " must be less than the requested expansion (%d).\n",
               hdr.N_acq, hdr.Ny);
    return;
  }

  /* mexPrintf("Ny = %d\n",hdr.Ny); */

  if (nrhs > 2) { 
    tmpR = mxGetPr(FTYPE_IN);
    szW = mxGetNumberOfDimensions(FTYPE_IN);
    dimW = mxGetDimensions(FTYPE_IN);
    
    if ( !mxIsDouble(FTYPE_IN) || (szW != 2) ) {
      mexPrintf( "error with 3rd input: Need to declare a 1-by-2"
                 " array for the final size of the output data matrix.\n" );
      return;
    } else {
      filt_type = (int)( tmpR[0] );
      if (filt_type < 0)
        filt_type = 0;
      if (filt_type > 1)
        filt_type = 1;
    }
  } 
  if (V)
    mexPrintf("Ny = %d  filt_type = %d\n",hdr.Ny,filt_type);
  

  /*
  sz[0] = hdr.Nx; sz[1] = hdr.N_acq; sz[2] = hdr.Nz_proc;
  write_nd_data("k_in.nd",K,"fltc",3,sz);
  */

  kline = (KCOORD *) malloc(hdr.N_acq*sizeof(KCOORD));
  memset( kline, 0, hdr.N_acq*sizeof(KCOORD));

  for (cnt=0;cnt<hdr.N_acq;cnt++) {
    kline[cnt].ky = cnt;
  }

  samp_dens = (float *) malloc(hdr.Ny*sizeof(float));

  calc_samp_dens( kline, kline, 
                  hdr.N_acq,
                  hdr.Nz_proc,
                  hdr.fill_fac,
                  hdr.Ny,
                  samp_dens );


  filt_pF   = (float *) malloc(hdr.Ny*sizeof(float));
  weight_pF = (float *) malloc(hdr.Ny*sizeof(float));

  setup_pF( &hdr, samp_dens, filt_pF, weight_pF, filt_type );

  if (V)
    mexPrintf("pF factor = %f\n",hdr.pF);

  K_out =  (COMPLEX *) malloc( hdr.Ny * 
                               hdr.Nx * 
                               sizeof(COMPLEX) );

  kstretch( hdr.Nx, hdr.Ny_proc, hdr.Nz_proc, hdr.N_acq, 1, 0, 0,
            kline, kline, K, K_out );

  /* weight k-space data to compensate for pF nature */
  for (cnt=0;cnt<hdr.Ny;cnt++) {
    for (cnt3=0;cnt3<hdr.Nz_proc;cnt3++) {
      for (cnt2=0;cnt2<hdr.Nx;cnt2++) {
        indx = cnt3*hdr.Nx*hdr.Ny + cnt*hdr.Nx + cnt2 ;
        K_out[ indx ].re *= weight_pF[cnt];
        K_out[ indx ].im *= weight_pF[cnt];
      }
    }  
  }

  /*
  sz[0] =hdr.Nx; sz[1] = hdr.Ny; sz[2] = hdr.Nz_proc;
  write_nd_data("k_zp.nd",K_out,"fltc",2,sz);
  */

  phase_ref = (COMPLEX *) malloc( hdr.Nx * hdr.Ny * sizeof(COMPLEX) );
  memset(phase_ref,0,hdr.Nx * hdr.Ny * sizeof(COMPLEX) );


  homodyne_kcentral( 1, /* hdr.ncoils */
                     1, /* hdr.Nf */
                     hdr.N_acq,
                     hdr.Nx,
                     filt_pF,
                     kline,
                     kline,
                     0,         /* fr1 */
                     hdr.fill_fac,
                     hdr.Ny,
                     K_out,
                     hdr.Nz_proc,
                     hdr.Ny_proc,
                     phase_ref
                     );  
  
  fft_mngr_init( &mngr );
  
  /*
  sz[0] =hdr.Nx; sz[1] = hdr.Ny;
  write_nd_data("image1.nd",K_out,"fltc",2,sz);
  */

  fftx( 1, 1, hdr.Ny, hdr.Nx, 'b', &mngr, 1, phase_ref );
  ffty( 1, 1, 1, hdr.Ny, hdr.Nx, 'b', &mngr, 1, phase_ref );
  fftx( 1, 1, hdr.Ny, hdr.Nx, 'b', &mngr, 1, K_out );
  ffty( 1, 1, 1, hdr.Ny, hdr.Nx, 'b', &mngr, 1, K_out );
  
  /*
  sz[0] =hdr.Nx; sz[1] = hdr.Ny;
  write_nd_data("phzref.nd",phase_ref,"fltc",2,sz); 
  */
 
  
  apply_pF( hdr.Nx, hdr.Ny, hdr.Nz_proc, 1, 
            phase_ref,          /* image data */
            K_out               /* image data */
            );

  /*

  fil_fft_shift( K_out, hdr.Nx, hdr.Ny );

    sz[0] =hdr.Nx; sz[1] = hdr.Ny;
    write_nd_data("pf_corr.nd",K_out,"fltc",2,sz);
  */

  fft_mngr_quit( &mngr );
  
  if (nlhs>0) {

    sz[0] = (int) hdr.Nx; 
    sz[1] = (int) hdr.Ny_proc; 
    sz[2] = (int) hdr.Nz_proc;
  
    K_OUT = mxCreateNumericArray( 3, sz, 
                                  mxDOUBLE_CLASS,
                                  mxCOMPLEX); 
    
    tmpR = mxGetPr(K_OUT);
    tmpI = mxGetPi(K_OUT);
    
    for (cnt=0; cnt < hdr.Ny*hdr.Nx; cnt++) {
      tmpR[cnt] = (double) K_out[cnt].re;
      tmpI[cnt] = (double) K_out[cnt].im;
    }
  }

  if (nlhs>1) {

    sz[0] = (int) hdr.Ny_proc; 
    sz[1] = 1;
  
    w_OUT = mxCreateNumericArray( 2, sz, 
                                  mxDOUBLE_CLASS,
                                  mxREAL); 
    
    tmpR = mxGetPr(w_OUT);
    for (cnt=0;cnt<hdr.Ny_proc;cnt++) { 
      /* mexPrintf("%3.1f ",weight_pF[cnt]); */
      tmpR[cnt] = (double) weight_pF[cnt];
    }
    /* mexPrintf("\n"); */
  }

  /*
  free(K_out);
  free(K);
  free(kline);
  free(samp_dens);
  free(filt_pF);
  free(weight_pF);
  free(phase_ref);
  */

  return;
  
}
/*

Copyright 2009, National Center for Image Guided Therapy (NCIGT)

Written by W. Scott Hoge (shoge.harvard.edu) 

All rights reserved. Licensed according to the terms of a BSD-style 
licence covering the Fast Imaging Library 
(see http://www.ncigt.org/pages/Downloads "Imaging Toolbox")


*/
