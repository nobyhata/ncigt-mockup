/*

This is a MEX example to call the FIL image rescaling functions

I2 = interpima( I, phz );


To compile, in Matlab call

  mex -I../../../include -L../../../lib -ligt_fil interpima.c

*/

#include <math.h>
#include "mex.h"
#include "stdio.h"
#include "stdlib.h"
#include "math.h"

#include "igt_fil.h"

void    interplin_ima(short Nx, short Ny, short Ny_int, short
        N_out, float off_phdir, COMPLEX *data, float *data_int);
void    interpsinc_ima(short Nx, short Ny, short Ny_int, short
        N_out, float off_phdir, COMPLEX *data, float *data_int);

/* Input Arguments */
#define	I_IN	  prhs[0]
#define	PHZOFF_IN prhs[1]
#define	TYPE_IN	  prhs[2]


/* Output Arguments */
#define	I_OUT	plhs[0]

short  V=0;               /* 0 for verbose off */

#define SINC 1
#define LIN  0

void mexFunction( int nlhs, mxArray *plhs[], 
		  int nrhs, const mxArray*prhs[] )
     
{
  int n,m,cnt;
  COMPLEX *I;
  float *O;
  int Nx, Ny, N_out,mx;
  float off_phdir = 0;

  double  *tmpR,*tmpI;
  int szI;
  const int *dimI;
  int sz[4];

  int type=SINC;

  fil_fft_mngr mngr;

  if (nrhs < 1) { 
    mexPrintf("At least 1 input arguments are required. (Iin: input image)");
    return;
  } else if (nlhs > 1) {
    mexPrintf("Too many output arguments."); 
    return;
  } 

  if (nrhs > 1) {
    szI = mxGetNumberOfDimensions(PHZOFF_IN);
    dimI = mxGetDimensions(PHZOFF_IN);
    if ( !mxIsDouble(I_IN) || szI != 2 ) {
      mexPrintf( "error with 2nd input: Need to declare a scalar"
                 " input argument for image offset.\n" );
      return;
    } else {
      tmpR = mxGetPr(PHZOFF_IN);
      off_phdir = tmpR[0];
      if (off_phdir > 1) {
        off_phdir = 1;
        mexPrintf("image offset reset to 1.  Needs to be a fraction of the FOV.\n");
      }
      if (off_phdir < 0 ) {
        off_phdir = 0;
        mexPrintf("image offset reset to 0.  Needs to be a fraction of the FOV.\n");
      }
      mexPrintf("off_phzdir = %f\n",off_phdir);
    }
  }

  if (nrhs > 2) {
    szI = mxGetNumberOfDimensions(TYPE_IN);
    dimI = mxGetDimensions(TYPE_IN);
    if ( !mxIsDouble(I_IN) || szI != 2 ) {
      mexPrintf( "error with 3rd input: Need to declare a scalar"
                 " input argument for interpolation type.\n" );
      return;
    } else {
      tmpR = mxGetPr(TYPE_IN);
      type = tmpR[0];
    }
    if (type == SINC) 
      mexPrintf("Using sinc interpolation\n");
    else 
      mexPrintf("Using linear interpolation\n");
  }

  szI = mxGetNumberOfDimensions(I_IN);
  dimI = mxGetDimensions(I_IN);
  if ( !mxIsDouble(I_IN) || szI != 2 ) {
    mexPrintf( "error with 1st input: Need to declare a 2D"
               " array for the input image data\n" );
    return;
  } else {
    tmpR = mxGetPr(I_IN);
    if ( mxIsComplex(I_IN) )
      tmpI = mxGetPi(I_IN);
    
    Nx = dimI[0]; Ny = dimI[1];

    I = (COMPLEX *) malloc( Nx * Ny * sizeof(COMPLEX) );
    for (cnt=0;cnt<Nx*Ny; cnt++) {
      I[cnt].re = (double) tmpR[cnt];
      if ( mxIsComplex(I_IN) )
        I[cnt].im = (double) tmpI[cnt];
      else
        I[cnt].im = 0;
    } 
    /* mexPrintf("copied input data to I\n"); */
  }
  mx = (Ny>Nx) ? Ny : Nx ;

  /* find the next largest power-of-two */
  N_out = pow( 2, (int)ceil( log(mx)/log(2) ) );

  printf("Nx:%d Ny:%d mx:%d N_out:%d\n",Nx,Ny,mx,N_out);
  
  /*
    sz[0] = Nx;  sz[1] = Ny;
    write_nd_data("I_in.nd",I,"dblc",2,sz);
  */

  O =  (float *) malloc( N_out * N_out * sizeof(float) );

  if (type == SINC) 
    interpsinc_ima( Nx, Ny, N_out, N_out, off_phdir, I, O );
  else
    interplin_ima( Nx, Ny, N_out, N_out, off_phdir, I, O );

  /*
    sz[0] = hdr.Nvertical;  sz[1] = hdr.xres;  sz[2] = hdr.Ncoils;
    write_nd_data("w_out.nd",W,"dblc",3,sz);
  */
  
  if (nlhs>0) {

    sz[0] = (int) N_out;
    sz[1] = (int) N_out;
  
    I_OUT = mxCreateNumericArray( 2, sz, 
                                  mxDOUBLE_CLASS,
                                  mxREAL); 
    
    tmpR = mxGetPr(I_OUT);
    
    for (cnt=0; cnt < N_out*N_out; cnt++) {
      tmpR[cnt] = (double) O[cnt];
    }
  }


  free(I);
  free(O);


  return;
  
}
/*

Copyright 2009, National Center for Image Guided Therapy (NCIGT)

Written by W. Scott Hoge (shoge.harvard.edu) 

All rights reserved. Licensed according to the terms of a BSD-style 
licence covering the Fast Imaging Library 
(see http://www.ncigt.org/pages/Downloads "Imaging Toolbox")


*/
