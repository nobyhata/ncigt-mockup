/*

This is a MEX example to call the FIL virtual body coil (VBC) code.

To compile, in Matlab call

  mex -I../../../include -L../../../lib -ligt_fil vbc2.c

Usage:

[ b0, vbc_coef ] = vbc( k, [ vbc_coef ] );

b0:       the virtual body coil image
vbc_coef: the coil combination coefficients

k :       input k-space

*/

#include <math.h>
#include "mex.h"
#include "stdio.h"

#include "igt_fil.h"

/* Input Arguments */
#define	K_IN	prhs[0]
#define	VBC_IN	prhs[1]

/* Output Arguments */
#define	K_OUT	plhs[0]
#define	VBC_OUT	plhs[1]

short  V=0;               /* 0 for verbose off */

short  show_vbc_msg = 0;

void vbc_msg( char *msg ) {
  if (show_vbc_msg)
    mexPrintf("%s",msg);
}

void mexFunction( int nlhs, mxArray *plhs[],
		  int nrhs, const mxArray*prhs[] )

{
  int n,m,cnt,cnt1,cnt2,oindx,iindx,pcnt;
  DATA_OBJ I, O, VBC;
  COMPLEX *tmpc;
  int nEl;

  double  *tmpR,*tmpI;
  const int *dimI;
  int szI;

  if (nrhs < 1) {
    mexPrintf("At least 1 input arguments is required.");
    return;
  } else if (nlhs > 2) {
    mexPrintf("Too many output arguments.");
    return;
  }

  tmpR = mxGetPr(K_IN);
  tmpI = mxGetPi(K_IN);
  szI  = mxGetNumberOfDimensions(K_IN);
  dimI = mxGetDimensions(K_IN);
  if ( (szI<3) ) {
    mexPrintf( "1st input: Need to declare a complex "
               " array of at least 3 dimensions for the input data.\n" );
    mexPrintf( "\t (in: ndim = %d < 3)\n", szI );
    return;
  } else {
    init_data_obj( &I );
    
    nEl = 1;
    for (cnt = 0; cnt<szI; cnt++) {
      if (cnt < 8) {
        I.sz[cnt] = dimI[cnt];  /* DATA_OBJ are limited to 8 dimensions, currently */
        nEl *= dimI[cnt];
      }
    }
    I.ndim = cnt;
    I.data = malloc( nEl * sizeof(COMPLEX) );
    I.init = nEl;

    if ( mxIsComplex(K_IN) )
      strcpy( I.type, "dblc" );
    else
      strcpy( I.type, "dblr" );
    
    tmpc = (COMPLEX *) I.data;
    for (cnt=0; cnt < nEl; cnt++) {
      tmpc[cnt].re = (double) tmpR[cnt];
      tmpc[cnt].im = (double) tmpI[cnt];
    }
  }

  init_data_obj( &O );
  init_data_obj( &VBC );

  if (nrhs > 1) {
    /* copy over the VBC data array */
    tmpR = mxGetPr(VBC_IN);
    tmpI = mxGetPi(VBC_IN);
    szI  = mxGetNumberOfDimensions(VBC_IN);
    dimI = mxGetDimensions(VBC_IN);

    nEl = 1;
    for (cnt = 0; cnt<szI; cnt++) {
      if (cnt < 8) {
        VBC.sz[cnt] = dimI[cnt];  /* DATA_OBJ are limited to 8 dimensions, currently */
        nEl *= dimI[cnt];
      }
    }
    VBC.ndim = cnt;
    VBC.data = malloc( nEl * sizeof(COMPLEX) );
    VBC.init = nEl;

    if ( mxIsComplex(VBC_IN) )
      strcpy( VBC.type, "dblc" );
    else
      strcpy( VBC.type, "dblr" );

    tmpc = (COMPLEX *) VBC.data;
    for (cnt=0; cnt < nEl; cnt++) {
      tmpc[cnt].re = (double) tmpR[cnt];
      if ( mxIsComplex(VBC_IN) )
        tmpc[cnt].im = (double) tmpI[cnt];
    }
    
    apply_vbc_coefs( &I, &O, &VBC );
  } else {
    compute_virtual_body_coil( &I, &O, &VBC );
  }

  if (nlhs>0) {

    K_OUT = mxCreateNumericArray( O.ndim, O.sz,
                                  mxDOUBLE_CLASS,
                                  mxCOMPLEX);
    nEl = 1;
    for (cnt = 0; cnt<O.ndim; cnt++) {
      if (cnt < 8) {
        nEl *= O.sz[cnt];
      }
    }
    /* printf("ndim = %d, nEl = %d\n", O.ndim, nEl ); */
    tmpR = mxGetPr(K_OUT);
    tmpI = mxGetPi(K_OUT);

    tmpc = (COMPLEX *) O.data;
    for (cnt=0; cnt< nEl; cnt++) {
      tmpR[cnt] = tmpc[cnt].re;
      tmpI[cnt] = tmpc[cnt].im;
    }

  }

  if (nlhs>1) {

    VBC_OUT = mxCreateNumericArray( VBC.ndim, VBC.sz,
                                    mxDOUBLE_CLASS,
                                    mxCOMPLEX);
    nEl = 1;
    for (cnt = 0; cnt<VBC.ndim; cnt++) {
      if (cnt < 8) {
        nEl *= VBC.sz[cnt];
      }
    }
    /* printf("ndim = %d, nEl = %d\n", O.ndim, nEl );  */
    tmpR = mxGetPr(VBC_OUT);
    tmpI = mxGetPi(VBC_OUT);

    tmpc = (COMPLEX *) VBC.data;
    for (cnt=0; cnt< nEl; cnt++) {
      tmpR[cnt] = tmpc[cnt].re;
      tmpI[cnt] = tmpc[cnt].im;
    }

  }

  free_data_obj(&O);
  free_data_obj(&I);
  free_data_obj(&VBC);

  return;

}
/*

Copyright 2011, National Center for Image Guided Therapy (NCIGT)

Written by W. Scott Hoge (shoge.harvard.edu)

All rights reserved. Licensed according to the terms of a BSD-style
licence covering the Fast Imaging Library
(see http://www.ncigt.org/pages/Downloads "Imaging Toolbox")


*/
