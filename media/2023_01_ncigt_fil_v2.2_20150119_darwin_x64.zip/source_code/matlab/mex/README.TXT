Calling NC-IGT Fast Imaging Library functions from MATLAB(tm)

Matlab allows one to call C functions via the MEX compiler

A few examples are given in this directory.

On Linux machines:

  In matlab, the command to compile MEX functions from .c source files is

  mex -I<fil-path>/include -L<fil-path>/lib -ligt_fil <c-file>

On Windows machines:

  In matlab, the command to compile MEX functions from .c source files is

  mex -I<fil-path>/include <c-file> <fil-path>/lib/igt_fil.lib


To build all mex files in one pass, one can use the 'buildall.m' script
included in the source_code/matlab/mex/  directory



