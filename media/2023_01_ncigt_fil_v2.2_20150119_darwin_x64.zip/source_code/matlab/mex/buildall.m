function buildall(locpath)
% a script to build all MEX files in this directory
%
% this function assumes that the build tree is structured as:
%  <ncigt fil path>/matlab/mex
%  <ncigt fil path>/lib
%  <ncigt fil path>/include
%
% If that is not true, then input the local path to the ncigt library
% e.g. buildall('/opt/packages/ncigt/');

if nargin==0,
  curpath = pwd;
  indx = findstr([ 'source_code' filesep 'matlab' ],pwd)-1;

else
  if exist(locpath) == 7,
    curpath = locpath;
    indx = max(findstr(filesep,locpath));
    if isempty(indx);
      locpath = [ locpath filesep ];
      indx = length(locpath);
    end;
  else,
    error(['input (' locpath ') is not a valid path.']); 
  end;
end;

incpath = [ curpath(1:indx) 'include' ];
libpath = [ curpath(1:indx) 'lib' ];

files = dir('*.c');

for cnt=1:length(files),
  cmd = [ ' mex -I' incpath ' -L' libpath ' ' files(cnt).name '  -ligt_fil' ];
  if (isunix), cmd = [ cmd ' -lpthread -lm ' ]; end;
  disp(cmd);
  eval(cmd);
end;
