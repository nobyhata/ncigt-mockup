/*

This is a MEX example to call the FIL LSQR-Hybrid SPACE RIP reconstruction
code for 3D imaging.

[ I, x, r ] = srlsqr3d( W, k, [Yy Yz], [ lams, maxits ] );

W - coil sensitivities (M x N x L)
k - acquired k-space data ( P x L )
Yz - phase-encode y locations of acquired k-space data ( P x 1 )
Yz - phase-encode z locations of acquired k-space data ( P x 1 )

optional arguments:
lams   - an array of lambda values to use
maxits - the maximum number of iterations to perform (default=20)

To compile, in Matlab call

  mex -I../../../include -L../../../lib -lpmri srlsqr.c

*/

#include <math.h>
#include "mex.h"
#include "stdio.h"

#include "igt_fil.h"
#include "grappa.h"


/* Input Arguments */
#define	W_IN	prhs[0]
#define	I_IN	prhs[1]
#define	Y_IN	prhs[2]
#define L_IN    prhs[3]
#define its_IN  prhs[4]

/* Output Arguments */
#define	K_OUT	plhs[0]
#define	X_OUT	plhs[1]
#define	R_OUT	plhs[2]

short  V=0;               /* 0 for verbose off */


void mexFunction( int nlhs, mxArray *plhs[], 
		  int nrhs, const mxArray*prhs[] )
     
{
  int n,m,cnt;
  COMPLEX *W,*I,*rho;
  int *PhaseLines;
  int *Yy,*Yz;
  int Nlines;
  int M,N,L,P;

  double  *tmpR,*tmpI;
  int szI, szY, szW;
  const int *dimI, *dimY, *dimW;
  int *sz;
  int flag = 0;

  float *lams;
  int numlams, its;

  double *xnorm,*R;

  int fullout = 1;              /* set to zero to return just one image.
                                   fullout=1 will return an image for each
                                   lambda value.
                                 */

  if (nrhs < 3) { 
    mexPrintf("At least 3 input arguments are required. (W:coil sensitivity, k:acquired data, Y:list of acquired phase encode lines)"); 
    return;
  } else if (nlhs > 3) {
    mexPrintf("Too many output arguments."); 
    return;
  } 

  tmpR = mxGetPr(W_IN);
  szW = mxGetNumberOfDimensions(W_IN);
  dimW = mxGetDimensions(W_IN);

  if ( !mxIsDouble(W_IN) || (szW != 3) ||
       !mxIsComplex(W_IN) ) {
    mexPrintf( "error with 1st input: Need to declare a complex M-by-N-by-L"
               " array for the coil sensitivity data.\n" );
    return;
  } else {
    M = (int) dimW[0];
    N = (int) dimW[1];
    L = (int) dimW[2];

    tmpR = mxGetPr(W_IN);
    tmpI = mxGetPi(W_IN);

    W = (COMPLEX *) malloc( M * N * L * sizeof(COMPLEX) );
    for ( cnt=0; cnt<M * N * L; cnt++ ) {
      W[cnt].re = (double) tmpR[cnt];
      W[cnt].im = (double) tmpI[cnt];
    } 
  }

  tmpR = mxGetPr(Y_IN);
  szY = mxGetNumberOfDimensions(Y_IN);
  dimY = mxGetDimensions(Y_IN);
  if ( !mxIsDouble(Y_IN) || (szY != 2 ) || (dimY[1] != 2) ||
       mxIsComplex(Y_IN) ) {
    mexPrintf( "error with 3rd input: Need to declare a real P-by-2"
               " array for the phase encode locations\n" );
    return;
  } else {
    P = (int) dimY[0];
    /* mexPrintf("input Y lines:\n"); */
    Yy = (int*) malloc( (int)P * sizeof(int) );
    Yz = (int*) malloc( (int)P * sizeof(int) );
    for (cnt=0;cnt<P;cnt++) {
      Yy[cnt] = (int) tmpR[cnt];
      Yz[cnt] = (int) tmpR[cnt + P ];
      /* mexPrintf(" %3.0f",PhaseLines[cnt]); */
    }
    mexPrintf("\n");
  }


  tmpR = mxGetPr(I_IN);
  tmpI = mxGetPi(I_IN);
  szI  = mxGetNumberOfDimensions(I_IN);
  dimI = mxGetDimensions(I_IN);
  if ( !mxIsDouble(I_IN) || (szI != 2) || (dimI[0] != P) ||
       (dimI[1] != L) ) {
    mexPrintf( "error with 2nd input: Need to declare a complex M-by-N-L"
               " array for the input data.\n" );
    mexPrintf( "\t (in:[ %d %d %d ]) != (expected:[ %d %d %d ]) \n",
               dimI[0],dimI[1],dimI[2],
               P,N,L );
    return;
  } else {
    I = (COMPLEX *) malloc( P * L * sizeof(COMPLEX) );
    for ( cnt=0; cnt < P * L; cnt++ ) {
      I[cnt].re = (double) tmpR[cnt];
      I[cnt].im = (double) tmpI[cnt];
    } 
  }

  /* copy over the lambda values */
  if (nrhs >= 4) { 

    szY = mxGetNumberOfDimensions(L_IN);
    dimY = mxGetDimensions(L_IN);
    if ( !mxIsDouble(L_IN) || (dimY[0] != 1) ||
         mxIsComplex(L_IN) ) {
      mexPrintf( "error with 4th input: Need to declare a real 1-by-p"
                 " array for the input lambda values.\n" );
      return;
    }
    numlams = dimY[1];
    lams = (float *) malloc( numlams * sizeof(float) );
    tmpR = mxGetPr(L_IN);
    for (cnt=0;cnt<numlams;cnt++) {
      lams[cnt] = (float) tmpR[cnt];
    }
    
  } else {
    numlams = 20;
    lams = (float *) malloc( numlams * sizeof(float) );
    for (cnt=0;cnt<numlams;cnt++) {
      /* lams = logspace(2,5,20) */
      lams[cnt] = pow( 10, (double) ( 4 + cnt*((double) 3 / (numlams-1) ) ) );
      mexPrintf(" %d pow(10,%f) = %e \n", cnt, 4 + cnt*((double)3/(numlams-1)), lams[cnt] );

    }
  }

  /* copy over the number of iterations */
  if (nrhs >= 5) { 
    tmpR = mxGetPr(its_IN);
    its = (int) tmpR[0];
  } else {
    its = 20;
  }

  if (fullout) {
    rho = NULL; 
  } else {
    rho = (COMPLEX *) malloc( N * M * sizeof(COMPLEX) );
    memset(rho,0, N * M * sizeof(COMPLEX) );
  }

  /*
    xnorm = (nlhs >=2) ? (double *) malloc( numlams * sizeof(double)) : NULL;
    R = (nlhs >=3) ? (double *) malloc( numlams * sizeof(double)) : NULL;
  */



  PhaseLines = (int *) malloc( P * sizeof(int) );
  sprip3d_conv_pts2y( P, Yy, Yz, M, N, PhaseLines );

  sprip3d_lsqr_init( P, M, N, L );

  sprip3d_lsqrsolv( PhaseLines, /* list of phase encodes */
                    P,          /* number of phase encodes used */
                    M,          /* number of rows of reconstructed samples */
                    N,          /* number of columns of reconstructed samples */
                    L,          /* number of coils */
                    W,          /* coil sensitivity estimate in spatial
                                   domain of size ( N, M, L ) */
                    I,          /* acquired data in k-space domain of
                                   size ( P, M, L, nimgs ) */ 
                    &rho,       /* the reconstructed image(s).  If given a
                                   pointer, then the algorithm will return one
                                   image of size M-by-N.  if (*rho==NULL), it
                                   will return an image for each of the
                                   regularization values.  To avoid memory
                                   leaks, clear the returned buffer after the
                                   most desirable image is copied. */
                    lams,       /* array of regularization parameter.  values
                                   (if *lams == NULL, use the default) */
                    numlams,    /* number of lambda values in the array
                                   (max=50). if zero, then default=20 is
                                   used */
                    its,         /* the maximum number of iterations */
                    NULL,
                    NULL,
                    0
                    );

  sz = (int *) malloc( 3*sizeof(int) );

  sz[0] = M; 
  sz[1] = N; 
  if (fullout) {
    sz[2] = numlams;
  } else {
    sz[2] = 1; 
  }

  K_OUT = mxCreateNumericArray( 3, sz, 
                                mxDOUBLE_CLASS,
                                mxCOMPLEX); 

  tmpR = mxGetPr(K_OUT);
  tmpI = mxGetPi(K_OUT);

  its = fullout ? M * N * numlams :
    M * N ;
  /* fprintf(stderr,"numEl = %d\n",its); */
  for (cnt=0; cnt < its; cnt++) {
    tmpR[cnt] = rho[cnt].re;
    tmpI[cnt] = rho[cnt].im;
  }

  if (nlhs>1) {
    X_OUT = mxCreateDoubleMatrix( numlams, 1, mxREAL ); 
    tmpR = mxGetPr(X_OUT);
    for (cnt=0; cnt < numlams; cnt++) {
      tmpR[cnt] = xnorm[cnt];
    }
  }

  if (nlhs>2) {
    R_OUT = mxCreateDoubleMatrix( numlams, 1, mxREAL ); 
    tmpR = mxGetPr(R_OUT);
    for (cnt=0; cnt < numlams; cnt++) {
      tmpR[cnt] = R[cnt];
    }
  }

  sprip3d_lsqr_post();
 
  free(sz);
  free(W);
  free(I);
  free(rho);
  free(PhaseLines);

  return;
  
}
/*

Copyright 2009, National Center for Image Guided Therapy (NCIGT)

Written by W. Scott Hoge (shoge.harvard.edu) 

All rights reserved. Licensed according to the terms of a BSD-style 
licence covering the Fast Imaging Library 
(see http://www.ncigt.org/pages/Downloads "Imaging Toolbox")


*/
