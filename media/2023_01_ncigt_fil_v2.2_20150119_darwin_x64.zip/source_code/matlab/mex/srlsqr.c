/*

This is a MEX example to call the FIL LSQR-Hybrid SPACE RIP reconstruction code.  

[ I, x, r ] = srlsqr( W, k, Y, [ lams, maxits ] );


To compile, in Matlab call

  mex -I../../../include -L../../../lib -lpmri srlsqr.c

*/

#include <math.h>
#include "mex.h"
#include "stdio.h"

#include "igt_fil.h"
#include "grappa.h"


/* Input Arguments */
#define	W_IN	prhs[0]
#define	I_IN	prhs[1]
#define	Y_IN	prhs[2]
#define L_IN    prhs[3]
#define its_IN  prhs[4]
#define D_IN    prhs[5]

/* Output Arguments */
#define	K_OUT	plhs[0]
#define	X_OUT	plhs[1]
#define	R_OUT	plhs[2]

short  V=0;               /* 0 for verbose off */


void mexFunction( int nlhs, mxArray *plhs[], 
		  int nrhs, const mxArray*prhs[] )
     
{
  int n,m,cnt;
  COMPLEX *W,*I,*rho;
  float *PhaseLines;
  int Nlines;
  dataheader hdr;

  double  *tmpR,*tmpI;
  int szI, szY, szW;
  const int *dimI, *dimY, *dimW;
  int *sz;
  int fsz[3];
  int flag = 0;

  float *lams;
  int numlams, its;
  COMPLEX *D;

  double *xnorm,*R;

  int fullout = 0;              /* set to zero to return just one image.
                                   fullout=1 will return an image for each
                                   lambda value.
                                 */
  if (nlhs > 1) { fullout = 1; }

  if (nrhs < 3) { 
    mexPrintf("At least 3 input arguments are required. (W:coil sensitivity,k:acquired data,Y:list of acquired phase encode lines)"); 
    return;
  } else if (nlhs > 3) {
    mexPrintf("Too many output arguments."); 
    return;
  } 


  tmpR = mxGetPr(W_IN);
  szW = mxGetNumberOfDimensions(W_IN);
  dimW = mxGetDimensions(W_IN);

  if ( !mxIsDouble(W_IN) || (szW != 3) ||
       !mxIsComplex(W_IN) ) {
    mexPrintf( "error with 1st input: Need to declare a complex M-by-N-by-L"
               " array for the coil sensitivity data.\n" );
    return;
  } else {
    hdr.Nvertical = (int) dimW[0];
    hdr.xres      = (int) dimW[1];
    hdr.Ncoils    = (int) dimW[2];

    tmpR = mxGetPr(W_IN);
    tmpI = mxGetPi(W_IN);

    W = (COMPLEX *) malloc( hdr.Nvertical * 
                               hdr.xres * 
                               hdr.Ncoils * sizeof(COMPLEX) );
    for (cnt=0;cnt<hdr.Nvertical * hdr.xres * hdr.Ncoils; cnt++) {
      W[cnt].re = (double) tmpR[cnt];
      W[cnt].im = (double) tmpI[cnt];
    } 
  }

  tmpR = mxGetPr(Y_IN);
  szY = mxGetNumberOfDimensions(Y_IN);
  dimY = mxGetDimensions(Y_IN);
  if ( !mxIsDouble(Y_IN) || (dimY[1] != 1) ||
       mxIsComplex(Y_IN) ) {
    mexPrintf( "error with 3rd input: Need to declare a real M-by-1"
               " array for the output data size\n" );
    return;
  } else {
    hdr.yres = (int) dimY[0];
    mexPrintf("input Y lines:\n");
    PhaseLines = (float*) malloc( (int)hdr.yres * sizeof(float) );
    for (cnt=0;cnt<hdr.yres;cnt++) {
      /* convert Matlab style indexing to C style (0 based) */
      PhaseLines[cnt] = (float) tmpR[cnt]-1;
      mexPrintf(" %3.0f",PhaseLines[cnt]); 
    }
    mexPrintf("\n");
  }


  tmpR = mxGetPr(I_IN);
  tmpI = mxGetPi(I_IN);
  szI  = mxGetNumberOfDimensions(I_IN);
  dimI = mxGetDimensions(I_IN);
  if ( !mxIsDouble(Y_IN) || (dimI[0] != hdr.yres) ||
       (dimI[1] != hdr.xres) || (dimI[2] != hdr.Ncoils) ) {
    mexPrintf( "error with 2nd input: Need to declare a complex M-by-N-L"
               " array for the input data.\n" );
    mexPrintf( "\t (in:[ %d %d %d ]) != (expected:[ %d %d %d ]) \n",
               dimI[0],dimI[1],dimI[2],
               hdr.yres,hdr.xres,hdr.Ncoils );
    return;
  } else {
    I = (COMPLEX *) malloc( hdr.yres * 
                               hdr.xres * 
                               hdr.Ncoils * sizeof(COMPLEX) );
    for (cnt=0;cnt<hdr.yres * hdr.xres * hdr.Ncoils; cnt++) {
      I[cnt].re = (double) tmpR[cnt];
      I[cnt].im = (double) tmpI[cnt];
    } 
  }

  /* copy over the lambda values */
  if (nrhs >= 4) { 

    szY = mxGetNumberOfDimensions(L_IN);
    dimY = mxGetDimensions(L_IN);
    if ( !mxIsDouble(L_IN) || (dimY[0] != 1) ||
         mxIsComplex(L_IN) ) {
      mexPrintf( "error with 4th input: Need to declare a real 1-by-p"
                 " array for the input lambda values.\n" );
      return;
    }
    numlams = dimY[1];
    lams = (float *) malloc( numlams * sizeof(float) );
    tmpR = mxGetPr(L_IN);
    for (cnt=0;cnt<numlams;cnt++) {
      lams[cnt] = (float) tmpR[cnt];
    }
    
  } else {
    lams = NULL;
    numlams = 20;
  }

  /* copy over the number of iterations */
  if (nrhs >= 5) { 
    tmpR = mxGetPr(its_IN);
    its = (int) tmpR[0];
    if (its>1000) {
      mexPrintf( "error with 5th input: number of iterations is exceeding large (%d > 1000).  double check your inputs\n",its );
      return;
    }
  } else {
    its = 20;
  }

  /* copy over the regularization operator matrix diagonal */
  if (nrhs >= 6) { 

    szY = mxGetNumberOfDimensions(D_IN);
    dimY = mxGetDimensions(D_IN);
    if ( !mxIsDouble(D_IN) || (dimY[0] != hdr.Nvertical) || (dimY[1] != 1) ) {
      mexPrintf( "error with 5th input: Need to declare an n-by-1"
                 " array for the regularzation matrix diagonal.\n" );
      return;
    }

    D = (COMPLEX *) malloc( hdr.Nvertical * sizeof(COMPLEX) );
    tmpR = mxGetPr(D_IN);
    tmpI = mxGetPi(D_IN);
    for (cnt=0;cnt<hdr.Nvertical;cnt++) {
      D[cnt].re = (double) tmpR[cnt];
      if (tmpI != 0)
        D[cnt].im = (double) tmpI[cnt];
      else
        D[cnt].im = 0;
    }
    
  } else {
    D = NULL;
  }

  if (fullout) {
    rho = NULL; 
  } else {
    rho = (COMPLEX *) malloc( hdr.xres * hdr.Nvertical * sizeof(COMPLEX) );
    memset(rho,0, hdr.xres * hdr.Nvertical * sizeof(COMPLEX) );
  }

  xnorm = (nlhs >=2) ? (double *) malloc( numlams * sizeof(double)) : NULL;
  R = (nlhs >=3) ? (double *) malloc( numlams * sizeof(double)) : NULL;

  sprip_lsqr_recon( PhaseLines, /* list of phase encodes */
                    hdr.yres,   /* number of phase encodes used */
                    hdr.Nvertical, /* number of reconstructed samples along 
                                      phase encode direction */
                    hdr.xres,   /* number of samples along readout direction */
                    hdr.Ncoils, /* number of coils */
                    W,          /* coil sensitivity estimate in spatial
                                   domain of size ( N, M, L ) */
                    I,          /* acquired data in k-space domain of
                                   size ( P, M, L, nimgs ) */ 
                    lams,       /* array of regularization parameter.  values
                                   (if *lams == NULL, use the default) */
                    numlams,    /* number of lambda values in the array
                                   (max=50). if zero, then default=20 is
                                   used */
                    D,
                    its,        /* the maximum number of iterations */
                    &rho,       /* the reconstructed image(s).  If given a
                                   pointer, then the algorithm will return one
                                   image of size M-by-N.  if (*rho==NULL), it
                                   will return an image for each of the
                                   regularization values.  To avoid memory
                                   leaks, clear the returned buffer after the
                                   most desirable image is copied. */
                    xnorm,
                    R,
                    0,          /* max number of threads to use. (set to '0' for default) */
                    NULL
                    );

  sz = (int *) malloc( 3*sizeof(int) );

  sz[0] = hdr.Nvertical; 
  sz[1] = hdr.xres; 
  if (fullout) {
    sz[2] = numlams;
  } else {
    sz[2] = 1; 
  }

  K_OUT = mxCreateNumericArray( 3, sz, 
                                mxDOUBLE_CLASS,
                                mxCOMPLEX); 

  tmpR = mxGetPr(K_OUT);
  tmpI = mxGetPi(K_OUT);

  its = fullout ? hdr.Nvertical * hdr.xres * numlams :
    hdr.Nvertical * hdr.xres ;
  /* fprintf(stderr,"numEl = %d\n",its); */
  for (cnt=0; cnt < its; cnt++) {
    tmpR[cnt] = rho[cnt].re;
    tmpI[cnt] = rho[cnt].im;
  }

  if (nlhs>1) {
    X_OUT = mxCreateDoubleMatrix( numlams, 1, mxREAL ); 
    tmpR = mxGetPr(X_OUT);
    for (cnt=0; cnt < numlams; cnt++) {
      tmpR[cnt] = xnorm[cnt];
    }
  }

  if (nlhs>2) {
    R_OUT = mxCreateDoubleMatrix( numlams, 1, mxREAL ); 
    tmpR = mxGetPr(R_OUT);
    for (cnt=0; cnt < numlams; cnt++) {
      tmpR[cnt] = R[cnt];
    }
  }
 
  free(sz);
  free(W);
  free(I);
  free(rho);
  free(PhaseLines);
  if (lams!=NULL) free(lams);
  

  return;
  
}
/*

Copyright 2009, National Center for Image Guided Therapy (NCIGT)

Written by W. Scott Hoge (shoge.harvard.edu) 

All rights reserved. Licensed according to the terms of a BSD-style 
licence covering the Fast Imaging Library 
(see http://www.ncigt.org/pages/Downloads "Imaging Toolbox")


*/
