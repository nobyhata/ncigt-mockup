% This is a MEX example to call the FIL Nyquist ghost correction routine
% based on GESTE.
% 
% Send two temporally encoded raw images in, A and B, to calibrate the
% GRAPPA reconstruction coefficients.  The coefficients are then used
% to remove the Nyquist ghosts in I
% 
% [ I, I2, N ] = geste( A, B, O );
% 
% A  - Input EPI data frame [ordered: kx-ky-kz-c]
% B  - Input EPI data frame, acquired with readout polarities opposite of
%      those for A [ordered: kx-ky-kz-c]
% O  - Optional data from a 3rd EPI data frame, to reconstruct
%
% I  - the ghost corrected reconstructed image, from either B or O
% I2 - the ghost corrected reconstructed image, from A
% N  - the grappa coefficients used in the reconstruction

% Copyright 2010, National Center for Image Guided Therapy (NCIGT)
% 
% Written by W. Scott Hoge (shoge.harvard.edu) 
% 
% All rights reserved. Licensed according to the terms of a BSD-style 
% licence covering the Fast Imaging Library 
% (see http://www.ncigt.org/pages/Downloads "Imaging Toolbox")
% 
% 
% 