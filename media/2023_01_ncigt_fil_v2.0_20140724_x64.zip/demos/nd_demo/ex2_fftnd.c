/*

  This file demonstrates the use of the ND file format.  The NCIGT
  library includes functions to read and write this data format in
  both Matlab and C, providing an easy way to pass data between the two
  formats.

  This demo performs the following in turn:
  * reads the input .nd file
  * copies (if necessary) the data to a COMPLEX array
  * performs a 2D inverse FFT on the input data
  * writes the result to a file, ex_out.nd

 */

#include <stdio.h>
#include <string.h>

#include "igt_fil.h"

#define I_OK 0

DATA_OBJ hamming_x;
DATA_OBJ hamming_y;
COMPLEX *hamming_buf;

fil_fft_mngr *mngr;            // a manager for the FFT operations

int zshim_init_hamming( int NX, int NY ) 
{
  double h1 = 0.54, h2 = 0.46;
  int cnt;
  double *hx, *hy;

  init_data_obj( &hamming_x );
  init_data_obj( &hamming_y );
  
  strcpy( hamming_x.type, "dblr");
  hamming_x.ndim  = 1;
  hamming_x.sz[0] = NX;
  hamming_x.data = (char *)calloc(NX,sizeof(double));
  hamming_x.init = (int) ( NX * sizeof(double) );

  strcpy( hamming_y.type, "dblr");
  hamming_y.ndim  = 1;
  hamming_y.sz[0] = NY;
  hamming_y.data = (char *)calloc(NY,sizeof(double));
  hamming_y.init = (int) ( NY * sizeof(double) );

  hx = (double *) hamming_x.data ;
  hy = (double *) hamming_y.data ;
  if ((hx == NULL) || (hy == NULL))
    {
      printf("Cannot allocate memory! \n");
      exit(0);
    }
  for (cnt = 0; cnt < NX; cnt++)
    hx[cnt] = h1 - h2 * cos((cnt + 1) * 2.0 * PI / NX);
  for (cnt = 0; cnt < NY; cnt++)
    hy[cnt] = h1 - h2 * cos((cnt + 1) * 2.0 * PI / NY);


  hamming_buf = (COMPLEX *) calloc( NX * NY, sizeof(COMPLEX) );

  return(I_OK);

}

int zshim_free_hamming()
{
  free_data_obj( &hamming_x );
  free_data_obj( &hamming_y );

  if (hamming_buf !=0)
    free(hamming_buf);

  return(I_OK);
}

int zshim_apply_hamming_window( DATA_OBJ *img, int NX, int NY, int NZ )
{

  // char fname[20];
  // int sz[4];
  short int *tmpi;

  int slc_cnt, cnt, x, y, n, m; // z
  int indx;

  double *hx = (double *) hamming_x.data;
  double *hy = (double *) hamming_y.data;

  // COMPLEX *hamming_buf2 = (COMPLEX *) malloc( NX*NY*sizeof(COMPLEX) );

  tmpi = (short int *) img->data;

  /* copy each slice over to the processing buffer */
  slc_cnt = 0;
  for ( n = 0; n < (img->sz[1] / NY); n++ ) {
    for ( m = 0; m < (img->sz[0] / NX); m++ ) {
      
      cnt = 0;
      for ( y = 0; y < NY; y++ ) {
        for ( x = 0; x < NX; x++ ) {
          indx = x + y * img->sz[0] + (m * NX) + (n * img->sz[0] * NY);

          hamming_buf[ cnt ].re = (double) tmpi[ indx ];
          hamming_buf[ cnt ].im = 0;
          cnt++;
        }
      }
      
      // sprintf(fname,"hbuf1_%02d.nd",slc_cnt);
      // sz[0] = NX; sz[1] = NY;
      // write_nd_data(fname,(void *)hamming_buf,"dblc",2,sz);

      fil_2dfft( mngr, NX, NY, hamming_buf, 'f' );
      fil_fft_shift( hamming_buf, NX, NY );

      /* apply the Hamming window envelope */
      for ( y=0; y<NY; y++ )
        for ( x=0; x<NX; x++ )
          {
            hamming_buf[y*NX + x].re = hx[x]*hy[y]*hamming_buf[y*NX + x].re;
            hamming_buf[y*NX + x].im = hx[x]*hy[y]*hamming_buf[y*NX + x].im;
          }

      fil_fft_shift( hamming_buf, NX, NY );
      fil_2dfft( mngr, NX, NY, hamming_buf, 'b' );

      // sprintf(fname,"hbuf_%02d.nd",slc_cnt);
      // sz[0] = NX; sz[1] = NY;
      // write_nd_data(fname,(void *)hamming_buf,"dblc",2,sz);
      
      double ddd;
      cnt = 0;
      for ( y = 0; y < NY; y++ ) {
        for ( x = 0; x < NX; x++ ) {
          indx = x + y * img->sz[0] + (m * NX) + (n * img->sz[0] * NY);
          ddd = ( sqrt( hamming_buf[ cnt ].re * hamming_buf[ cnt ].re +
                        hamming_buf[ cnt ].im * hamming_buf[ cnt ].im ) / NX / NY );
          tmpi[ indx ] = (short int) ( ddd + 0.5);
          cnt++;
        }
      }

      
      slc_cnt++;
      if ( slc_cnt == NZ ) {
        // bail out early if we have already completed all the slices
        m = 30000;
        n = 30000;
      }
    }
  }

  return(I_OK);
}



int main ( int argc, char* argv[]) {
  
  char *fname;                  // a pointer to the input file name

  float *data_in = NULL;        // a pointer to 
  int   *intd_in = NULL;
  
  /* parameters needed by the read_nd_data function */
  char *tmpp;                   // a temporary pointer
  int n, cnt, sz[4];            // variables to store the data size
                                // and number of dimensions
  char dtype[5] = {0,0,0,0,0};  // a char array to report the data type

  DATA_OBJ input;

  /* copy the first input argument into the filename pointer */
  fname = argv[1];

  printf("%s\n",fname);

  init_data_obj( &input );

  /* read in the nd data file */
  read_nd_data2( fname, &input );

  if ( strcmp(input.type,"intr") != 0 ) {
    fprintf(stderr,"input data needs to be 'intr'\n");
  }
  
  printf("read_nd_data2 read an %s %d-dimensional array of size ",input.type,input.ndim);
  for ( cnt=0; cnt<n; cnt++ ) { 
    printf(" %d",input.sz[cnt]);
  } 
  printf(".\n");

  printf("Performing filtering:\n");

  mngr = malloc( sizeof(fil_fft_mngr) );
  fft_mngr_init( mngr );       // initialize an FFT manager

  

  fft_mngr_quit( mngr );       // clear the FFT manager
  free( mngr );

  // output the data to a file.  This can then be read in Matlab
  // using 'readnd.m'
  write_nd_data( "ex2_out.nd", data, "dblc", 3, sz );


  return(0);
}

/* 

  Created Dec 2008, W. Scott Hoge (shoge at bwh dot harvard dot edu)
  
 */
