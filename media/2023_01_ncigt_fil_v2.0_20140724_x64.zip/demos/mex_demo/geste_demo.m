% a demo of the EPI-GESTE Nyquist ghost phase correction functions

if ~exist('geste')
  mexpath
end;

echo on

% load EPI data with first line acquired using a positive readout gradient
A = readnd('geste_A.dat');

% load EPI data with first line acquired using a negative readout gradient
B = readnd('geste_B.dat');

% process the two data sets using GESTE
[Ia,Ib,N] = geste(A,B);

% Ghost free images are shown in the figure. (left) first image, (right) second image
im([ Ia Ib ]);

% press [Enter] to continue ...
pause;

% GRAPPA coefficients computed by GESTE function can be reused
% with other EPI data frames...
%    constructing an image from even EPI data lines using GRAPPA,
F1=grappa([128 128 8],permute(A(:,1:2:end,:),[2 1 3]),vec(1:2:128),'0x0',2,N);
%    constructing an image from odd EPI data lines using GRAPPA,
F2=grappa([128 128 8],permute(A(:,2:2:end,:),[2 1 3]),vec(2:2:128),'0x0',2,N);

f1 = fftshift(ifft2(fftshift(F1))); 
f2 = fftshift(ifft2(fftshift(F2)));

%    now add the two GRAPPA images images together coherently\n');
Ia = pos_neg_add( permute(f1,[2 1 3]), permute(f2,[2 1 3]) )/2;

%    result is shown in the new figure.
im(Ia);

echo off
