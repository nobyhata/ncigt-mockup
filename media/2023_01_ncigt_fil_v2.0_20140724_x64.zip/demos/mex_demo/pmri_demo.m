if ~exist('readnd')
  addpath('../../source_code/matlab');
end;
if ~exist('geyser')
  addpath('../../source_code/matlab/mex');
end;

fprintf('loading the pMRI data data\n');
k = readnd('phantom.dat');

N = 256; % 128

k = k( (size(k,1)-N)/2+(1:N), (size(k,1)-N)/2+(1:N), : );

% form a variable density sampling pattern, 4x-2x-1x, with 3x total
% acceleration (suitable for self-referenced reconstructions)
fprintf('  computing a synthetic variable density sampling function\n');
Z = zeros(N,1);
Z( 2:4:end) = 1;
Z( (N/2) + (-(N/8-2):2:(N/8)) ) = 1;
Z( (N/2) + (-(N/32-2):(N/32)) ) = 1;
Y = find(Z);

% generate the coil sensitivity maps
fprintf('\n  computing coil sensitivity maps from the subsampled data\n');
W = geyser( k(Y,:,:), Y(:), [N N 8] );

% solve the system using LSQR-Hybrid space rip
fprintf(['\n  running LSQR-Hybrid (to compute multiple images with different ' ...
         'regularization)\n']);
[Isr,xn,rn] = srlsqr( W, ifft(fftshift(k(Y,:,:),2),[],2), Y(:) );
% pick the image just before the residual error starts to grow large
indx = min( find( rn > min(rn)+1e-4*(max(rn)-min(rn))) );


% solve the system using GRAPPA
fprintf(['\n  running GRAPPA on the subsampled data\n']);
[Fg,Ig2]  = grappa( size(W), k(Y,:,:), Y(:) );
% Ig2 here is the virtual body coil image.  One can compare with
% the classic reconstruction method using coil sensitivity maps instead via:
Ig  = sum( conj(W).*ifft2(fftshift(fftshift(Fg,1),2)), 3 );

% [Frlsg, Irlsg] = rlsgrappa_x( size(W), ifft(fftshift(k(Y,:,:),2),[],2), Y(:) );

% solve the system using a standard SENSE reconstruction
k2 = zeros(size(k));
k2( 1:4:end,:,: ) = k( 1:4:end,:,:) * 4;  % '*4' to compensate for the
                                          % sparse sampling
K2 = ifft2( fftshift(fftshift(k2,1),2) );
fprintf('\n   Computing the SENSE solution at uniform 4x acceleration\n');
Ics = sense( permute(W,[2 1 3]), permute(K2,[2 1 3]), 4 ).';

% solve the system using a variable density SENSE reconstruction
fprintf(['\n   Computing the Variable Denisty SENSE solution for the synthetic ' ...
         'subsampling function\n']);
k3 = prep_vds( Y(:), permute(k(Y,:,:),[2 1 3]), [N N 8] );
k3 = permute( k3, [2 1 3]);

K3 = ifft2( fftshift(fftshift(k3,1),2) );

Ivdcs = sense( permute(W,[2 1 3]), permute(K3,[2 1 3]), 4 ).';

fprintf('\n Results shown in the figures\n');
im([ Ig Isr(:,:,indx); Ics Ivdcs ]);
title('[ GRAPPA SPRIP; SENSE VDSENSE ]')

im([ Ig Ig2 ]);
title('[ (GRAPPA: SoS) (GRAPPA: Virtual Body Coil) ]')

% 
% Written by W. Scott Hoge (shoge -at - bwh.harvard.edu) 
% 
