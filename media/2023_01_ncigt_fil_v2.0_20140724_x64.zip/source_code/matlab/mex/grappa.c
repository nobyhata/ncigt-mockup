/*

This is a MEX example to call the FIL GRAPPA reconstruction code.

To compile, in Matlab call

  mex -I../../../include -L../../../lib -ligt_fil grappa.c

Usage:

[Fg,Ig,N] = grappa( size(W), k, Y(:), [ kernel, dks, N ] );

Fg: the reconstructed k-space
Ig: the root-sum-of-squares image derived from Fg

size(W) : the size of the output data array
k : the input (subsampled) k-space data
Y : the phase encode lines associated with the input k-space

optional args:
kernel : a text string that specifies the size of the grappa kernel ('2x5')
dks    : an array declaring the (delta k) gaps to reconstruct.
N      : a structured matrix containing GRAPPA reconstruction parameters
         and the target pattern they are associated with

*/

#include <math.h>
#include "mex.h"
#include "stdio.h"

#include "igt_fil.h"
#include "grappa.h"

/* Input Arguments */
#define	W_IN	prhs[0]
#define	K_IN	prhs[1]
#define	Y_IN	prhs[2]
#define KERNEL_IN  prhs[3]
#define DKS_IN  prhs[4]
#define N_IN    prhs[5]
#define RADIUS_IN prhs[6]
#define GROG_IN prhs[7]

/* Output Arguments */
#define	K_OUT	plhs[0]
#define	I_OUT	plhs[1]
#define	N_OUT	plhs[2]


short  V=0;               /* 0 for verbose off */

short  show_grappa_msg = 1;

void grappa_msg( char *msg ) {
  if (show_grappa_msg)
    mexPrintf("%s",msg);
}

void mexFunction( int nlhs, mxArray *plhs[],
		  int nrhs, const mxArray*prhs[] )

{
  int n,m,cnt,cnt1,cnt2,oindx,iindx,pcnt;
  COMPLEX *I,*O;
  COMPLEX *B;
  int *PhaseLines;
  int Nlines;
  int *OutPhaseLines;
  dataheader hdr;
  int YKS=2, XKS=5;
  char *str;
  float radius = 1.0;          /* reconstruct all point along readout dim */
  float radius_cal = 1.0;          /* reconstruct all point along readout dim */
  int grog_val = 0;
  int ndk = 0;
  int *dks_in = NULL;

  fil_fft_mngr mngr;

  double  *tmpR,*tmpI,scl;
  int szI, szY, szW,nel;
  const int *dimI, *dimY, *dimW;
  int sz[3];
  int flag = 0;

  GRAPPA_PARMS gparm;
  GRAPPA_OBJ  **gobj_array;
  const char *fieldnames[] = {"dk","pattern","coef","dir"};
  int dk_field, pattern_field, coef_field, dir_field, NgCols, NgRows;
  mxArray *field_value;

  int npat, nslices, ncoils;
  char tmpstr[20];

  DATA_OBJ grappa_export;
  GRAPPA_PARMS *gparm_array;

  memset( tmpstr, 0, 20 );
  memset( &gparm, 0, sizeof(GRAPPA_PARMS) );
  gparm.parray=NULL;

  if (nrhs < 3) {
    mexPrintf("At least 3 input arguments are required.");
    return;
  } else if (nlhs > 3) {
    mexPrintf("Too many output arguments.");
    return;
  }

  tmpR = mxGetPr(W_IN);
  szW = mxGetNumberOfDimensions(W_IN);
  dimW = mxGetDimensions(W_IN);

  if ( !mxIsDouble(W_IN) || (dimW[0] != 1) || (dimW[1] != 3) ||
       mxIsComplex(W_IN) ) {
    mexPrintf( "1st input: Need to declare a real 1-by-3"
               " array for the output data size\n" );
    return;
  } else {
    hdr.Nvertical = (int) tmpR[0];
    hdr.xres      = (int) tmpR[1];
    hdr.Ncoils    = (int) tmpR[2];
  }

  tmpR = mxGetPr(Y_IN);
  szY = mxGetNumberOfDimensions(Y_IN);
  dimY = mxGetDimensions(Y_IN);
  if ( !mxIsDouble(Y_IN) || (dimY[1] != 1) ||
       mxIsComplex(Y_IN) ) {
    mexPrintf( "3rd input: Need to declare a real M-by-1"
               " array for the output data size" );
    return;
  } else {
    hdr.yres = (int) dimY[0];
    grappa_msg("input Y lines:\n");
    PhaseLines = (int*) malloc( (int)hdr.yres * sizeof(int) );
    for (cnt=0;cnt<hdr.yres;cnt++) {
      /* convert indices from matlab (1 based) to C (0 based) */
      PhaseLines[cnt] = tmpR[cnt] - 1;
      if (tmpR[cnt] > hdr.Nvertical) {
        /* to prevent memory errors, in case the first input isnt large enough for all of the phase encode lines */
        hdr.Nvertical = (int)tmpR[cnt]; 
      }
      if (show_grappa_msg) { mexPrintf(" %d",PhaseLines[cnt]); }
    }
    grappa_msg("\n");
  }



  tmpR = mxGetPr(K_IN);
  tmpI = mxGetPi(K_IN);
  szI  = mxGetNumberOfDimensions(K_IN);
  dimI = mxGetDimensions(K_IN);
  if ( !mxIsDouble(K_IN) || !mxIsComplex(K_IN) || 
       (dimI[0] != hdr.yres) || (dimI[1] != hdr.xres) || (dimI[2] != hdr.Ncoils) ) {
    mexPrintf( "2nd input: Need to declare a complex M-by-N-L"
               " array for the input data.\n" );
    mexPrintf( "\t (in:[ %d %d %d ]) != (expected:[ %d %d %d ]) \n",
               dimI[0],dimI[1],dimI[2],
               hdr.yres,hdr.xres,hdr.Ncoils );
    return;
  } else {
    I = (COMPLEX *) malloc( hdr.yres *
                               hdr.xres *
                               hdr.Ncoils * sizeof(COMPLEX) );
    for (cnt=0;cnt<hdr.yres * hdr.xres * hdr.Ncoils; cnt++) {
      I[cnt].re = (double) tmpR[cnt];
      I[cnt].im = (double) tmpI[cnt];
    }
  }

  if (nrhs >= 4 ) {
    tmpR = mxGetPr(KERNEL_IN);
    szY = mxGetNumberOfDimensions(KERNEL_IN);
    dimY = mxGetDimensions(KERNEL_IN);
    if ( !mxIsChar(KERNEL_IN) ) {
      mexPrintf( "4th input: Need to declare a 3 char string"
                 " for kernel size, YxX" );
      return;
    } else {
      grappa_msg("input kernel size lines: ");
      str = mxArrayToString( KERNEL_IN );
      sscanf( str, "%dx%d", &YKS, &XKS );
      if (show_grappa_msg) { mexPrintf("%d x %d \n", YKS, XKS ); }
    }
  }

  if (nrhs >= 5 ) {
    tmpR = mxGetPr(DKS_IN);
    szY = mxGetNumberOfDimensions(DKS_IN);
    dimY = mxGetDimensions(DKS_IN);
    if ( !mxIsDouble(DKS_IN) || (dimY[1] != 1) ||
         mxIsComplex(DKS_IN) ) {
      mexPrintf( "5th input: Need to declare an real array"
                 " for dk gaps to reconstruct" );
      return;
    } else {
      grappa_msg("input dk's:");
      dks_in = (int *) malloc( dimY[0]*sizeof(int) );
      ndk = dimY[0];
      for (cnt=0;cnt<dimY[0];cnt++) {
        dks_in[cnt] = (int) tmpR[cnt];
        if (show_grappa_msg) { mexPrintf(" %d",dks_in[cnt]); }
      }
      grappa_msg("\n");
    }
  }

  if ( (nrhs >= 6 ) && ( !mxIsEmpty( N_IN ) ) ) {
    /***********************************************************************/
    
    if ( mxIsStruct( N_IN ) != 1 ){

      mexPrintf( "6th input: Input GRAPPA parameters need to be in a structure, with .dk .pattern and .coef fields\n" );
      return;
    }

    szI  = mxGetNumberOfDimensions(N_IN);
    dimI = mxGetDimensions(N_IN);

    npat = dimI[0]; nslices = dimI[1];


    dk_field      = mxGetFieldNumber( N_IN, "dk" );
    pattern_field = mxGetFieldNumber( N_IN, "pattern" );
    coef_field    = mxGetFieldNumber( N_IN, "coef" );

    gparm.dks = (int *) calloc( 10, sizeof(int) );
    cnt1 = 0;

    for (pcnt=0; pcnt<npat; pcnt++) {
      /* set the dk value for the current pattern */
      field_value = mxGetFieldByNumber(N_IN,pcnt,dk_field);
      tmpR = mxGetPr(field_value);

      if ( pcnt==0 ) {
        gparm.dks[0] = (int)( tmpR[0] );   /* initialize the dks array on first pass */
      }

      if ( (int)( tmpR[0] ) > gparm.dks[cnt1] ) {
        cnt1++;
        gparm.dks[cnt1] = (int)( tmpR[0] );
      } else if ( (int)(tmpR[0]) < gparm.dks[cnt1] ) {

        mexPrintf( "6th input: please sort the input dk variable by increasing dks values\n" );
        return;
      }

    }
    gparm.ndk = cnt1+1;           /* set the number of dk's in the input data */

    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
    /* determine the kernel size */
    pcnt = 0;
    field_value = mxGetFieldByNumber(N_IN,pcnt,pattern_field);
    mxGetString( field_value, tmpstr, 20 ); /* check ret value? */
    gparm.YKS = 0;
    for (cnt=0;cnt<20;cnt++) {
      if ( tmpstr[cnt] == '*' )
        gparm.YKS ++ ;
    }
    /* printf("YKS: %d\n",gparm.YKS); */

    field_value = mxGetFieldByNumber(N_IN,pcnt,coef_field);
    szI = mxGetNumberOfDimensions(field_value);
    dimI = mxGetDimensions(field_value);
    gparm.XKS = (int)( dimI[0] / dimI[1] / gparm.YKS );
    /* printf("XKS: %d\n",gparm.XKS); */

    if (show_grappa_msg) { mexPrintf("computed kernel size: %d x %d\n",gparm.YKS,gparm.XKS); }
    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */


    gobj_array = (GRAPPA_OBJ **) malloc( gparm.ndk * sizeof(GRAPPA_OBJ *));
    gparm.parray = gobj_array;


    if (show_grappa_msg) { mexPrintf("ndk: %d\n",gparm.ndk); }
    pcnt=0;
    for(cnt2=0;cnt2<gparm.ndk;cnt2++){
      iindx = gparm.dks[cnt2]; /* size of delta-k gap for these coefficients  */
      if (show_grappa_msg) { mexPrintf("dks[%d] = %d; patterns:",cnt2,iindx); }

      if (gparm.YKS==1)
        if (gparm.grog == 2) 
          oindx = 4; 
        else 
          oindx = 2;
      else
        oindx = (gparm.YKS-1)*(iindx-1); /* number of patterns used for this gap size */

      gobj_array[cnt2] = (GRAPPA_OBJ *) calloc(oindx,sizeof(GRAPPA_OBJ));

      for(cnt1=0;cnt1<oindx;cnt1++,pcnt++){
        field_value = mxGetFieldByNumber(N_IN,pcnt,pattern_field);
        mxGetString( field_value, tmpstr, 20 ); /* check ret value? */

        gobj_array[cnt2][cnt1].pattern = (char*)calloc(20,sizeof(char));
        strcpy( gobj_array[cnt2][cnt1].pattern, tmpstr );
        if (show_grappa_msg) { mexPrintf(" %s",gobj_array[cnt2][cnt1].pattern); }



        /* copy to coefficients over to the grappa object buffer */
        field_value = mxGetFieldByNumber(N_IN,pcnt,coef_field);

        /* ** confirm that input parameter size matches input data! ** */
        nel = gparm.XKS*gparm.YKS*hdr.Ncoils * hdr.Ncoils;
        gobj_array[cnt2][cnt1].N = (COMPLEX *) malloc( nel * sizeof(COMPLEX));
        tmpR = mxGetPr(field_value);
        tmpI = mxGetPi(field_value);
        for (cnt=0;cnt<nel; cnt++) {
          gobj_array[cnt2][cnt1].N[cnt].re = tmpR[cnt];
          gobj_array[cnt2][cnt1].N[cnt].im = tmpI[cnt];
        }

      }
      grappa_msg("\n");
    }
    /***********************************************************************/
  }

  if (nrhs >= 7 ) {
    tmpR = mxGetPr(RADIUS_IN);
    szY = mxGetNumberOfDimensions(RADIUS_IN);
    dimY = mxGetDimensions(RADIUS_IN);
    if ( !mxIsDouble(RADIUS_IN) || (dimY[1] != 1) ||
         mxIsComplex(RADIUS_IN) ) {
      mexPrintf( "7th input: Need to declare an scalar float value"
                 " for calibration radius" );
      return;
    } else {
      grappa_msg("input calibration radius:");
      radius_cal = (float) tmpR[0];
      if (show_grappa_msg){ printf(" %f\n",radius_cal); }
    }
  }


  if (nrhs >= 8 ) {
    tmpR = mxGetPr(GROG_IN);
    szY = mxGetNumberOfDimensions(GROG_IN);
    dimY = mxGetDimensions(GROG_IN);
    if ( !mxIsDouble(GROG_IN) || mxIsComplex(GROG_IN) ) {
      mexPrintf( "8th input: Need to declare one of {0,1,2}"
                 " for GROG setting." );
      return;
    } else {
      grappa_msg("input GROG setting:");
      grog_val = (int) tmpR[0];
      if (show_grappa_msg){ printf(" %d\n",grog_val); printf(" %f\n",(double) tmpR[0]); }
    }
  }


  O = (COMPLEX *) calloc( hdr.xres*hdr.Nvertical*hdr.Ncoils, sizeof(COMPLEX) );

  if (0) {
    grappa( I, PhaseLines, &hdr, O, &Nlines, &OutPhaseLines,
            YKS, XKS, (float) 1.0, ndk, dks_in );
  } else {
    /* copy the raw data over to the expanded coil buffer */
    for ( cnt=0; cnt < hdr.yres; cnt++ ) {
      for( cnt1=0; cnt1<hdr.Ncoils; cnt1++ ) {
        for( cnt2=0; cnt2<hdr.xres; cnt2++ ) {
          oindx = PhaseLines[cnt] + cnt2*((int)hdr.Nvertical) + cnt1 * (int)hdr.Nvertical * hdr.xres;
          iindx = cnt + cnt2*hdr.yres + cnt1 * hdr.yres * hdr.xres;
          O[ oindx ].re = I[ iindx ].re;
          O[ oindx ].im = I[ iindx ].im;
        }
      }
    }

    if (gparm.parray==NULL){

      /* tell the library which dk gaps to compute */
      gparm.ndk = ndk;  gparm.dks = dks_in;
      /* declare the kernel to use (default: 2x5) */
      gparm.YKS = YKS;  gparm.XKS = XKS; 
      gparm.grog = grog_val;

      grappa_msg(" calculating GRAPPA recon coef: \n");
      grappa_calc_recon_coef( O, PhaseLines, &hdr, &gparm, radius_cal );

      /*
        init_data_obj( &grappa_export );
        gparm_array = &gparm;
        export_grappa_coef( &gparm_array, &grappa_export, hdr.Ncoils, 1 );
        write_nd_data2( "gparms_mex.nd", &grappa_export );
      */

      /* report some info about the calculated parameters */
      gobj_array = gparm.parray;
      if (show_grappa_msg) { mexPrintf("ndk: %d\n",gparm.ndk); }
      pcnt=0;
      for(cnt2=0;cnt2<gparm.ndk;cnt2++){
        iindx = gparm.dks[cnt2]; /* size of delta-k gap for these coefficients  */
        if (show_grappa_msg) { mexPrintf("dks[%d] = %d; patterns: ",cnt2,iindx); }

        if (YKS==1)
          if (gparm.grog ==2)
            oindx = 4;
          else
            oindx = 2;
        else
          oindx = (gparm.YKS-1)*(iindx-1); /* number of patterns used for this gap size */
        for(cnt1=0;cnt1<oindx;cnt1++){
          if (show_grappa_msg){ mexPrintf("%s ",gobj_array[cnt2][cnt1].pattern); }
          pcnt++;
        }

        if (show_grappa_msg) { mexPrintf("\n"); }
      }
    }

    grappa_apply_recon_coef( O, PhaseLines, &hdr, &Nlines, &OutPhaseLines, radius, &gparm );

    if (nlhs<3) /* clear the grappa recon parameter memory, unless its a requested output */
      grappa_clear_parms( &gparm );
  }

  if (nlhs>0) {
    sz[0] = hdr.Nvertical;
    sz[1] = hdr.xres;
    sz[2] = hdr.Ncoils;

    K_OUT = mxCreateNumericArray( 3, sz,
                                  mxDOUBLE_CLASS,
                                  mxCOMPLEX);
    tmpR = mxGetPr(K_OUT);
    tmpI = mxGetPi(K_OUT);
    for (cnt=0;cnt<hdr.Nvertical * hdr.xres * hdr.Ncoils; cnt++) {
      tmpR[cnt] = O[cnt].re;
      tmpI[cnt] = O[cnt].im;
    }

  }

  if (nlhs>1) {

    fft_mngr_init( &mngr );

    for (cnt1=0;cnt1<hdr.Ncoils; cnt1++) {
        fil_fft_shift( ( O + cnt1*hdr.Nvertical*hdr.xres ), hdr.xres, hdr.Nvertical );

        fil_2dfft( &mngr, hdr.Nvertical, hdr.xres, ( O + cnt1*hdr.Nvertical*hdr.xres ), 'b' );
    }
    fft_mngr_quit( &mngr );

    /* Because of the 2dfft, scale the data here to match with Matlab */
    scl = hdr.xres*hdr.Nvertical;
    for (cnt1=0; cnt1 < hdr.Ncoils*hdr.Nvertical*hdr.xres; cnt1++) {
      O[cnt1].re = O[cnt1].re / scl;
      O[cnt1].im = O[cnt1].im / scl;
    }

    I_OUT = mxCreateNumericArray( 2, sz,
                                  mxDOUBLE_CLASS,
                                  mxCOMPLEX);
    tmpR = mxGetPr(I_OUT);
    tmpI = mxGetPi(I_OUT);

    if (0) {
      
      B = (COMPLEX *) calloc( hdr.xres*hdr.Nvertical, sizeof(COMPLEX) );

      sz[0] = hdr.xres, sz[1] = hdr.Nvertical, sz[2] = hdr.Ncoils;
      /* compute_virtual_body_coil( O, 3, sz, B ); */
      calc_vbc( O, 3, sz, B );

      /*
      sz[0] = hdr.Nvertical;
      sz[1] = hdr.xres;
      write_nd_data("Ig2.nd",B,"dblc",2,sz);
      */
      for (cnt=0;cnt<  hdr.Nvertical * hdr.xres; cnt++) {
        tmpR[cnt] = B[cnt].re;
        tmpI[cnt] = B[cnt].im;
      }
    } else {
      /*  *the old root sum of squares calculation* */
      
      nel = (int) hdr.Nvertical * hdr.xres;
      for (cnt=0;cnt<nel; cnt++) {
        scl = 0;
        for (cnt1=0;cnt1<hdr.Ncoils;cnt1++) {

          scl = scl + ( O[cnt + cnt1*nel ].re * O[cnt + cnt1*nel ].re +
                        O[cnt + cnt1*nel ].im * O[cnt + cnt1*nel ].im );
        }
        tmpR[cnt] = sqrt(scl);
        tmpI[cnt] = 0;
      }
    }

  }

  if (nlhs>2) {
    N_OUT = mxCreateStructMatrix( pcnt, 1, 3+(gparm.grog>0), fieldnames );

    dk_field      = mxGetFieldNumber( N_OUT, "dk" );
    pattern_field = mxGetFieldNumber( N_OUT, "pattern" );
    coef_field    = mxGetFieldNumber( N_OUT, "coef" );
    if (grog_val>0)
      dir_field     = mxGetFieldNumber( N_OUT, "dir" );

    gobj_array = gparm.parray;
    pcnt=0;
    for(cnt2=0;cnt2<gparm.ndk;cnt2++){
      iindx = gparm.dks[cnt2]; /* size of delta-k gap for these coefficients  */

      if (gparm.YKS==1)
        if (gparm.grog == 2)
          oindx = 4;
        else
          oindx = 2;
      else
        oindx = (gparm.YKS-1)*(iindx-1); /* number of patterns used for this gap size */

      for(cnt1=0;cnt1<oindx;cnt1++){
        /* set the dk value for this set of coefficients */
        field_value = mxCreateDoubleMatrix(1,1,mxREAL);
        tmpR = mxGetPr(field_value);
        tmpR[0] = iindx;
        mxSetFieldByNumber(N_OUT,pcnt,dk_field,field_value);

        /* set the pattern for this set of coefficients */
        mxSetFieldByNumber(N_OUT,pcnt,pattern_field,mxCreateString(gobj_array[cnt2][cnt1].pattern));

        if (gparm.grog > 0) {
          /* set the pattern for this set of coefficients */
          if( gobj_array[cnt2][cnt1].direction == 0 ) {
            mxSetFieldByNumber(N_OUT,pcnt,dir_field,mxCreateString("normal"));
          } else {
            mxSetFieldByNumber(N_OUT,pcnt,dir_field,mxCreateString("parallel"));
          }
        }

        /* copy to coefficients over to the output buffer */
        NgRows = gparm.XKS*gparm.YKS*hdr.Ncoils;
        if (gparm.grog > 0)  
          NgCols = NgRows;
        else
          NgCols = hdr.Ncoils;
        
        field_value = mxCreateDoubleMatrix( NgRows, NgCols, mxCOMPLEX);

        tmpR = mxGetPr(field_value);
        tmpI = mxGetPi(field_value);
        for (cnt=0;cnt<NgCols*NgRows; cnt++) {
          tmpR[cnt] = gobj_array[cnt2][cnt1].N[cnt].re;
          tmpI[cnt] = gobj_array[cnt2][cnt1].N[cnt].im;
        }
        mxSetFieldByNumber(N_OUT,pcnt,coef_field,field_value);

        pcnt++;
      }
    }
    grappa_clear_parms( &gparm );
  }

  free(O);
  free(I);
  free(PhaseLines);

  return;

}
/*

Copyright 2009, National Center for Image Guided Therapy (NCIGT)

Written by W. Scott Hoge (shoge.harvard.edu)

All rights reserved. Licensed according to the terms of a BSD-style
licence covering the Fast Imaging Library
(see http://www.ncigt.org/pages/Downloads "Imaging Toolbox")


*/
