mex -o correct_pF.mexglx -I/bigscr/shoge/mri/pi_u41/include -L/bigscr/shoge/mri/pi_u41/lib correct_pF.c -lm -lpthread -ligt_fil ; exit;
