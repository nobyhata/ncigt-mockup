%  a virtual body coil (VBC) computation, calling the FIL module of that name
%  
%  Usage:
%  
%  [ b0, vbc_coef ] = vbc2( r, [ vbc_coef ] );
%  
%  b0:       the virtual body coil image
%  vbc_coef: the coil combination coefficients
%  
%  r :       input multi-coil image
%