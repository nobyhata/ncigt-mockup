#ifdef __cplusplus
extern "C" {
#endif

#include "grappa.h"

void compute_nd_eig( DATA_OBJ *A, DATA_OBJ *V, DATA_OBJ *D, DATA_OBJ *VI );

int grog_grid_2Ddata( DATA_OBJ   *smpl_x, /**< a 1D (double / "dblr") array of sample point locations, along the x (horizontal) axis */
                      DATA_OBJ   *smpl_y, /**< a 1D (double / "dblr") array of sample point locations, along the y (vertical) axis */
                      DATA_OBJ   *kdata,  /**< a 1D (complex double / "dblc") array of sampled k-space data, at each {smpl_x,smpl_y} point in the previous two arrays */
                      DATA_OBJ   *src,    /**< a 1D (short int / "intr") array of indices, indicating which kdata point should be used for each output target listed in {new_x,new_y} */
                      DATA_OBJ   *new_x,  /**< a 1D (double / "dblr") array of destination grid locations, along x */
                      DATA_OBJ   *new_y,  /**< a 1D (double / "dblr") array of destination grid locations, along y */
                      DATA_OBJ   *kdata_out,  /**< a 1D (complex double / "dblc") array of computed k-space data, at the points specified by {new_x,new_y} */
                      GRAPPA_PARMS *gparms /**< a pointer to the GROG parameters */
                      );

int grog_generate_eigd( GRAPPA_PARMS **gparm, /**< input array of GRAPPA parameters, suitable for GROG
                                                 ( set gparm->grog = 1 or 2 prior to generating gparm coefficients ) */
                        int ncoil, /**< number of coils assocated with the input array */
                        int nslc  /**< number of slices assocated with the input array */
                        );

#ifdef __cplusplus
}
#endif
